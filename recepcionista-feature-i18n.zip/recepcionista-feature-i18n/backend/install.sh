#!/bin/bash

uv venv
source ./venv/bin/activate
uv pip install -r requirements.txt

from fastapi import APIRouter, Request, Response, Body, Header, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional
from twilio.rest import Client
from twilio.twiml.messaging_response import MessagingResponse
from twilio.request_validator import RequestValidator
import databutton as db
import json
import re
import base64
import hashlib
import hmac
from datetime import datetime

# Initialize router
router = APIRouter(prefix="/whatsapp", tags=["whatsapp"])

# Define models
class WhatsAppMessage(BaseModel):
    body: str
    from_number: str = Field(..., alias="From")
    to_number: str = Field(..., alias="To")
    profile_name: Optional[str] = Field(None, alias="ProfileName")
    message_sid: Optional[str] = Field(None, alias="MessageSid")

class WhatsAppMessageStatus(BaseModel):
    message_sid: str = Field(..., alias="MessageSid")
    message_status: str = Field(..., alias="MessageStatus")
    to_number: str = Field(..., alias="To")
    from_number: str = Field(..., alias="From")

class WhatsAppTemplate(BaseModel):
    name: str
    language_code: str = "es"
    parameters: List[Dict[str, str]] = []

class WhatsAppMessageRequest(BaseModel):
    to_number: str
    message: str = ""
    template: Optional[WhatsAppTemplate] = None

class WhatsAppMessageResponse(BaseModel):
    success: bool
    message_sid: Optional[str] = None
    error: Optional[str] = None

# Helper functions
def get_twilio_client():
    """Initialize and return Twilio client."""
    account_sid = db.secrets.get("TWILIO_ACCOUNT_SID")
    auth_token = db.secrets.get("TWILIO_AUTH_TOKEN")
    
    if not account_sid or not auth_token:
        raise HTTPException(
            status_code=500, 
            detail="Twilio credentials not configured. Please set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN in secrets."
        )
    
    return Client(account_sid, auth_token)

def get_whatsapp_number():
    """Get configured WhatsApp number from secrets."""
    whatsapp_number = db.secrets.get("TWILIO_WHATSAPP_NUMBER")
    
    if not whatsapp_number:
        raise HTTPException(
            status_code=500, 
            detail="WhatsApp number not configured. Please set TWILIO_WHATSAPP_NUMBER in secrets."
        )
    
    # Strip "whatsapp:" prefix if it's already there
    if whatsapp_number.startswith("whatsapp:"):
        whatsapp_number = whatsapp_number[9:]
    
    return whatsapp_number

def format_whatsapp_number(number: str) -> str:
    """Ensures phone number is in correct WhatsApp format."""
    # Strip all non-numeric characters
    cleaned = re.sub(r'\D', '', number)
    
    # Ensure it has country code
    if not cleaned.startswith('+'): 
        if not cleaned.startswith('1'):
            # Default to US/Canada if no country code
            cleaned = '1' + cleaned
        cleaned = '+' + cleaned
    
    return f"whatsapp:{cleaned}"

# Endpoints
def validate_twilio_request(request: Request, x_twilio_signature: str = Header(None)):
    """Validate the Twilio signature for webhook requests."""
    auth_token = db.secrets.get("TWILIO_AUTH_TOKEN")
    
    if not auth_token:
        # In development, we might skip validation if no auth token is set
        print("WARNING: TWILIO_AUTH_TOKEN not set. Webhook validation skipped.")
        return True
    
    # If we have an auth token, validate the request
    validator = RequestValidator(auth_token)
    url = str(request.url)
    
    # Get form params or JSON body
    form_data = dict(request.form()) if hasattr(request, 'form') else {}
    
    return validator.validate(url, form_data, x_twilio_signature)

@router.post("/webhook", status_code=200)
async def whatsapp_webhook(request: Request, x_twilio_signature: str = Header(None)):
    """Webhook for incoming WhatsApp messages."""
    # Get the entire request body as bytes to validate signature
    form_data = await request.form()
    form_dict = dict(form_data)
    
    # Log incoming message for debugging
    print(f"Received WhatsApp webhook: {form_dict}")
    
    # Validate Twilio signature
    is_valid = validate_twilio_request(request, x_twilio_signature)
    if not is_valid:
        raise HTTPException(status_code=403, detail="Invalid Twilio signature")
    
    # For message is coming from WhatsApp
    if "Body" in form_dict and "From" in form_dict:
        resp = MessagingResponse()
        body = form_dict.get("Body", "")
        from_number = form_dict.get("From", "")
        message_sid = form_dict.get("MessageSid", "")
        profile_name = form_dict.get("ProfileName", "")
        
        # Create a timestamp
        timestamp = datetime.now().isoformat()
        
        # For now, just respond with an echo
        # In a real implementation, we would process the message and generate a response
        resp.message(f"Recibido: {body}. Gracias por tu mensaje. Te responderemos pronto.")
        
        # Store the message in database for later processing
        try:
            # Format a sanitized key for storage
            storage_key = re.sub(r'[^a-zA-Z0-9._-]', '', f"whatsapp_messages_{from_number}_{message_sid}")
            
            # Prepare message data
            message_data = {
                "body": body,
                "from_number": from_number,
                "to_number": form_dict.get("To", ""),
                "message_sid": message_sid,
                "profile_name": profile_name,
                "timestamp": timestamp,
                "status": "received"
            }
            
            # Store in database
            print(f"Storing message: {message_data}")
            db.storage.json.put(storage_key, message_data)
        except Exception as e:
            print(f"Error storing message: {str(e)}")
        
        return Response(content=str(resp), media_type="application/xml")
    
    return {"status": "received"}

@router.post("/status", status_code=200)
async def whatsapp_status_callback(request: Request, x_twilio_signature: str = Header(None)):
    """Webhook for WhatsApp message status updates."""
    form_data = await request.form()
    form_dict = dict(form_data)
    
    # Log status update
    print(f"Received WhatsApp status update: {form_dict}")
    
    # Validate Twilio signature
    is_valid = validate_twilio_request(request, x_twilio_signature)
    if not is_valid:
        raise HTTPException(status_code=403, detail="Invalid Twilio signature")
    
    # Process status update
    message_sid = form_dict.get("MessageSid")
    message_status = form_dict.get("MessageStatus")
    to_number = form_dict.get("To")
    from_number = form_dict.get("From")
    
    if message_sid and message_status:
        # Update message status in database
        try:
            # Format a sanitized key for storage
            storage_key = re.sub(r'[^a-zA-Z0-9._-]', '', f"whatsapp_status_{message_sid}")
            
            timestamp = datetime.now().isoformat()
            status_data = {
                "message_sid": message_sid,
                "status": message_status,
                "to_number": to_number,
                "from_number": from_number,
                "timestamp": timestamp
            }
            print(f"Updating message status: {status_data}")
            db.storage.json.put(storage_key, status_data)
            
            # Also try to update the original message if it exists
            original_key = re.sub(r'[^a-zA-Z0-9._-]', '', f"whatsapp_messages_{from_number}_{message_sid}")
            try:
                original_message = db.storage.json.get(original_key)
                if original_message:
                    original_message["status"] = message_status
                    original_message["status_updated_at"] = timestamp
                    db.storage.json.put(original_key, original_message)
            except Exception:
                # Original message might not exist, which is fine
                pass
                
        except Exception as e:
            print(f"Error updating message status: {str(e)}")
    
    return {"status": "received"}

@router.post("/send", response_model=WhatsAppMessageResponse)
async def send_twilio_whatsapp_message(message_request: WhatsAppMessageRequest):
    """Send a WhatsApp message."""
    try:
        client = get_twilio_client()
        whatsapp_number = get_whatsapp_number()
        
        from_number = format_whatsapp_number(whatsapp_number)
        to_number = format_whatsapp_number(message_request.to_number)
        
        # Handle template messages
        if message_request.template:
            # This would require approved message templates with Twilio/WhatsApp
            # For now, just use regular messages
            template_name = message_request.template.name
            components = []
            
            if message_request.template.parameters:
                components.append({
                    "type": "body",
                    "parameters": message_request.template.parameters
                })
            
            # In a real implementation, we would use the Twilio Content API for templates
            # For now, we'll just send a text message
            message = client.messages.create(
                from_=from_number,
                body=f"Template: {template_name} - {message_request.message}",
                to=to_number
            )
        else:
            # Send regular text message
            message = client.messages.create(
                from_=from_number,
                body=message_request.message,
                to=to_number
            )
        
        return WhatsAppMessageResponse(
            success=True,
            message_sid=message.sid
        )
        
    except Exception as e:
        return WhatsAppMessageResponse(
            success=False,
            error=str(e)
        )

@router.get("/status")
async def check_twilio_whatsapp_status():
    """Check the status of the WhatsApp integration."""
    try:
        # Verify we can initialize the client
        account_sid = db.secrets.get("TWILIO_ACCOUNT_SID")
        auth_token = db.secrets.get("TWILIO_AUTH_TOKEN")
        whatsapp_number = db.secrets.get("TWILIO_WHATSAPP_NUMBER")
        
        if not account_sid or not auth_token or not whatsapp_number:
            return {
                "status": "error",
                "message": "WhatsApp API not configured. Please set up your Twilio credentials."
            }
        
        # Try to initialize the client
        client = Client(account_sid, auth_token)
        
        # Make a simple API call to verify credentials
        try:
            # Get account info to verify credentials
            account = client.api.v2010.accounts(account_sid).fetch()
            
            # Format WhatsApp number for display
            display_number = whatsapp_number
            if display_number.startswith("whatsapp:"):
                display_number = display_number[9:]
            
            return {
                "status": "operational",
                "provider": "Twilio",
                "whatsapp_number": display_number,
                "account_name": account.friendly_name
            }
        except Exception as api_error:
            print(f"Error validating Twilio API: {str(api_error)}")
            return {
                "status": "error",
                "message": f"Error validating Twilio credentials: {str(api_error)}"
            }
        
    except Exception as e:
        print(f"Error checking WhatsApp status: {str(e)}")
        return {
            "status": "error",
            "message": str(e)
        }

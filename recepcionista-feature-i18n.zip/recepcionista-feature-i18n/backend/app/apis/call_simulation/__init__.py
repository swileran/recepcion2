from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Dict, List, Optional, Union
import databutton as db
import json
import re
from app.auth import AuthorizedUser

router = APIRouter(prefix="/call-simulation")

# Models
class SimulationRequest(BaseModel):
    user_input: str
    scenario: Optional[str] = None
    context: Optional[Dict] = None

class SimulationResponse(BaseModel):
    ai_response: str
    suggested_next_inputs: List[str]
    audio_base64: Optional[str] = None
    actions: Optional[Dict] = None  # For appointment scheduling, FAQ answers, etc.
    conversation_summary: Optional[str] = None
    improvement_suggestions: Optional[List[Dict[str, str]]] = None  # Suggestions to improve agent responses
    performance_metrics: Optional[Dict[str, float]] = None  # Metrics to track performance

class SimulationScenario(BaseModel):
    id: str
    name: str
    description: str
    initial_context: Dict
    suggested_first_input: str

class SimulationScenariosResponse(BaseModel):
    scenarios: List[SimulationScenario]

# Predefined test scenarios
TEST_SCENARIOS = [
    # Greeting and General Inquiries
    SimulationScenario(
        id="basic_greeting",
        name="Saludo Básico",
        description="Simula una llamada donde el cliente simplemente saluda y pregunta información general.",
        initial_context={"scenario_type": "general_info"},
        suggested_first_input="Hola, buenos días. Llamo para saber más sobre su negocio."
    ),
    SimulationScenario(
        id="new_customer_questions",
        name="Nuevo Cliente con Preguntas",
        description="Simula una llamada con un cliente potencial que tiene muchas preguntas antes de decidirse a usar el servicio.",
        initial_context={"scenario_type": "new_customer"},
        suggested_first_input="Hola, nunca he estado en su negocio y quisiera saber más antes de hacer una cita."
    ),
    
    # Appointment Booking Scenarios
    SimulationScenario(
        id="appointment_booking_basic",
        name="Reservar una Cita (Básico)",
        description="Simula una llamada donde el cliente quiere reservar una cita sin especificar detalles.",
        initial_context={"scenario_type": "appointment_booking", "client_clarity": "low"},
        suggested_first_input="Hola, me gustaría hacer una reserva."
    ),
    SimulationScenario(
        id="appointment_booking_detailed",
        name="Reservar una Cita (Detallada)",
        description="Simula una llamada donde el cliente proporciona todos los detalles necesarios para una cita.",
        initial_context={"scenario_type": "appointment_booking", "client_clarity": "high"},
        suggested_first_input="Hola, quisiera reservar para un corte de cabello mañana a las 3 de la tarde, mi nombre es Juan Pérez."
    ),
    SimulationScenario(
        id="specific_service_booking",
        name="Reservar un Servicio Específico",
        description="Simula una llamada donde el cliente quiere reservar un servicio específico pero necesita ayuda con fecha y hora.",
        initial_context={"scenario_type": "appointment_booking", "service_specific": True, "client_clarity": "medium"},
        suggested_first_input="Hola, quisiera reservar para un tratamiento facial. ¿Cuándo tienen disponibilidad?"
    ),
    SimulationScenario(
        id="appointment_urgent",
        name="Reserva Urgente para Hoy",
        description="Simula una llamada donde el cliente necesita una cita urgente para el mismo día.",
        initial_context={"scenario_type": "appointment_booking", "urgency": "high"},
        suggested_first_input="Hola, necesito un servicio para hoy mismo. ¿Tienen algún espacio disponible?"
    ),
    SimulationScenario(
        id="appointment_for_family",
        name="Reserva para Múltiples Personas",
        description="Simula una llamada donde el cliente quiere reservar servicios para varias personas.",
        initial_context={"scenario_type": "appointment_booking", "multiple_clients": True},
        suggested_first_input="Hola, quisiera hacer una reserva para mi esposa y para mí este fin de semana."
    ),
    SimulationScenario(
        id="appointment_reschedule",
        name="Cambiar una Cita",
        description="Simula una llamada donde el cliente quiere modificar una cita existente.",
        initial_context={"scenario_type": "appointment_modification", "has_existing_appointment": True},
        suggested_first_input="Hola, tengo una cita para mañana pero necesito cambiarla para otro día."
    ),
    SimulationScenario(
        id="appointment_cancellation",
        name="Cancelar una Cita",
        description="Simula una llamada donde el cliente quiere cancelar una cita programada.",
        initial_context={"scenario_type": "appointment_cancellation", "has_existing_appointment": True},
        suggested_first_input="Hola, necesito cancelar mi cita para mañana a las 2pm."
    ),
    
    # FAQ Scenarios
    SimulationScenario(
        id="faq_hours",
        name="Consulta de Horarios",
        description="Simula una llamada donde el cliente pregunta por los horarios de atención.",
        initial_context={"scenario_type": "faq", "topic": "hours"},
        suggested_first_input="Hola, ¿me podrías decir cuáles son sus horarios de atención?"
    ),
    SimulationScenario(
        id="faq_services",
        name="Consulta de Servicios",
        description="Simula una llamada donde el cliente pregunta sobre los servicios ofrecidos.",
        initial_context={"scenario_type": "faq", "topic": "services"},
        suggested_first_input="Hola, ¿qué servicios ofrecen?"
    ),
    SimulationScenario(
        id="faq_prices",
        name="Consulta de Precios",
        description="Simula una llamada donde el cliente pregunta específicamente sobre los precios.",
        initial_context={"scenario_type": "faq", "topic": "prices"},
        suggested_first_input="Hola, ¿cuánto cuesta un corte de cabello?"
    ),
    SimulationScenario(
        id="faq_location",
        name="Consulta de Ubicación",
        description="Simula una llamada donde el cliente pregunta por la dirección o ubicación del negocio.",
        initial_context={"scenario_type": "faq", "topic": "location"},
        suggested_first_input="Hola, ¿me pueden indicar dónde están ubicados exactamente?"
    ),
    SimulationScenario(
        id="faq_parking",
        name="Consulta de Estacionamiento",
        description="Simula una llamada donde el cliente pregunta sobre opciones de estacionamiento.",
        initial_context={"scenario_type": "faq", "topic": "parking"},
        suggested_first_input="Hola, ¿tienen estacionamiento disponible para clientes?"
    ),
    
    # Complex Scenarios
    SimulationScenario(
        id="complex_inquiry",
        name="Consulta Compleja",
        description="Simula una llamada donde el cliente hace varias preguntas y solicitudes en la misma llamada.",
        initial_context={"scenario_type": "complex"},
        suggested_first_input="Hola, tengo algunas dudas sobre sus servicios y también quiero saber si puedo hacer una reserva para mañana."
    ),
    SimulationScenario(
        id="special_requests",
        name="Solicitudes Especiales",
        description="Simula una llamada donde el cliente tiene requisitos o solicitudes especiales.",
        initial_context={"scenario_type": "complex", "special_requests": True},
        suggested_first_input="Hola, quisiera hacer una cita pero necesito saber si pueden acomodar algunas necesidades especiales que tengo."
    ),
    
    # Customer Experience Scenarios
    SimulationScenario(
        id="dissatisfied_customer",
        name="Cliente Insatisfecho",
        description="Simula una llamada con un cliente que tuvo una mala experiencia y quiere expresar su inconformidad.",
        initial_context={"scenario_type": "complaint", "severity": "medium"},
        suggested_first_input="Hola, estoy llamando porque no quedé satisfecho con el servicio que recibí ayer."
    ),
    SimulationScenario(
        id="very_angry_customer",
        name="Cliente Muy Enojado",
        description="Simula una llamada con un cliente extremadamente insatisfecho y enojado.",
        initial_context={"scenario_type": "complaint", "severity": "high"},
        suggested_first_input="¡Estoy muy molesto por el terrible servicio que recibí! Quiero hablar con el gerente inmediatamente."
    ),
    SimulationScenario(
        id="follow_up_after_service",
        name="Seguimiento Después del Servicio",
        description="Simula una llamada donde el cliente llama para comentar sobre el servicio recibido recientemente.",
        initial_context={"scenario_type": "follow_up"},
        suggested_first_input="Hola, estuve en su negocio ayer y quería comentarles sobre mi experiencia."
    )
]

def get_profile_by_user_id(user_id: str):
    """
    Get user profile from Firestore by user ID
    """
    try:
        # In a real implementation, this would fetch from Firestore
        # For now, we'll use a simplified approach with db.storage
        profile_key = f"profile_{user_id}"
        profile = db.storage.json.get(profile_key, None)
        if not profile:
            raise ValueError(f"Profile not found for user {user_id}")
        return profile
    except Exception as e:
        print(f"Error fetching profile: {str(e)}")
        return None

@router.get("/scenarios", response_model=SimulationScenariosResponse)
def get_simulation_scenarios():
    """
    Get available call simulation scenarios
    """
    return SimulationScenariosResponse(scenarios=TEST_SCENARIOS)

@router.post("/simulate", response_model=SimulationResponse)
def simulate_call(request: SimulationRequest, user: AuthorizedUser):
    """
    Simulate a call with the AI receptionist based on the user's input and context
    """
    try:
        # Get the user's profile to access their voice agent configuration
        profile = get_profile_by_user_id(user.sub)
        if not profile or not profile.get("voiceAgent"):
            raise HTTPException(
                status_code=400, 
                detail="Debes configurar tu asistente de voz antes de simular llamadas"
            )
        
        voice_agent = profile.get("voiceAgent", {})
        greeting_message = voice_agent.get("greetingMessage", "")
        farewell_message = voice_agent.get("farewellMessage", "")
        confirmation_message = voice_agent.get("confirmationMessage", "")
        faqs = voice_agent.get("faqs", [])
        
        # Process the user input based on the scenario and context
        user_input = request.user_input.lower()
        scenario = request.scenario or "basic_greeting"
        context = request.context or {}
        
        # The response we'll build
        ai_response = ""
        suggested_next_inputs = []
        actions = {}
        
        # Initialize or continue the conversation
        if "conversation" not in context:
            # First message in conversation
            ai_response = greeting_message
            context["conversation"] = [{
                "role": "assistant",
                "content": greeting_message
            }]
        else:
            # Add user input to conversation history
            context["conversation"].append({
                "role": "user",
                "content": user_input
            })
            
            # Detect Spanish colloquialisms and idioms in user input
            colloquial_greeting = any(phrase in user_input for phrase in ["qué tal", "qué onda", "qué pasa", "cómo va", "buenas"])
            urgency_indicators = any(word in user_input for word in ["urgente", "emergencia", "hoy mismo", "ahora", "inmediatamente", "pronto"])
            frustration_indicators = any(word in user_input for word in ["molesto", "enojado", "furioso", "harto", "cansado", "fastidioso", "irritante"])

            # Process based on the recognized intent and scenario
            if scenario.startswith("appointment") or any(word in user_input for word in ["cita", "reserva", "agendar", "reservar", "cambiar", "modificar", "cancelar", "turno", "hora"]):
                # Handle appointment booking
                if "fecha" in user_input or "día" in user_input or "mañana" in user_input or "hora" in user_input:
                    # User is trying to specify a date/time
                    ai_response = "Entiendo que deseas agendar una cita. "
                    
                    # Extract potential date/time information with enhanced Spanish patterns
                    date_pattern = r"(mañana|pasado mañana|hoy|esta tarde|esta noche|lunes|martes|miércoles|jueves|viernes|sábado|domingo|próxima semana|este fin de semana|este finde)"
                    time_pattern = r"(\d{1,2})(?::\d{2})?\s*(?:am|pm|AM|PM|de la mañana|de la tarde|de la noche)?"
                    
                    # Detect specific services mentioned
                    service_keywords = ["corte", "peinado", "coloración", "tinte", "mechas", "manicure", "pedicure", 
                                        "facial", "masaje", "depilación", "tratamiento", "lavado", "maquillaje", "uñas", 
                                        "pestañas", "cejas", "barba", "spa", "estética", "belleza", "reparación", "servicio"]
                    mentioned_services = [keyword for keyword in service_keywords if keyword in user_input]
                    
                    dates = re.findall(date_pattern, user_input)
                    times = re.findall(time_pattern, user_input)
                    
                    # Extract number of people (for group appointments)
                    people_pattern = r"(para\s+\d+\s+personas|para\s+mi\s+[a-zá-úñ\s]+\s+[yei]\s+[a-zá-úñ\s]+|para\s+nosotros|para\s+mi\s+familia)"
                    people_matches = re.findall(people_pattern, user_input, re.IGNORECASE)
                    multiple_people = len(people_matches) > 0
                    
                    if dates and times:
                        date = dates[0]
                        time = times[0]
                        service_text = ""
                        if mentioned_services:
                            service = mentioned_services[0]  # Use the first mentioned service
                            service_text = f" para {service}"
                            actions["appointment"] = {
                                "date": date,
                                "time": time,
                                "service": service,
                                "multiple_people": multiple_people,
                                "status": "pending_confirmation"
                            }
                        else:
                            actions["appointment"] = {
                                "date": date,
                                "time": time,
                                "multiple_people": multiple_people,
                                "status": "pending_confirmation"
                            }
                            
                        # Adjust response based on multiple people indicator
                        if multiple_people:
                            ai_response += f"¿Quieren agendar una cita{service_text} para {date} a las {time}? "
                        else:
                            ai_response += f"¿Quieres agendar una cita{service_text} para {date} a las {time}? "
                        ai_response += "¿Podrías proporcionarme tu nombre y número de teléfono para confirmar?"
                        suggested_next_inputs = [
                            "Sí, mi nombre es Juan Pérez y mi teléfono es 555-123-4567",
                            "No, prefiero otro horario"
                        ]
                    else:
                        # Check if urgency is detected
                        if urgency_indicators:
                            ai_response += "Entiendo que necesitas una cita con urgencia. ¿Te gustaría ver nuestra disponibilidad para hoy o mañana?"
                            suggested_next_inputs = [
                                "Sí, ¿qué horarios tienen disponibles hoy?",
                                "Mejor para mañana, ¿qué horarios tienen?"
                            ]
                        # Check if services were mentioned without date/time
                        elif mentioned_services:
                            service = mentioned_services[0]
                            ai_response += f"Entiendo que quieres agendar para {service}. ¿Para qué día y hora te gustaría?"
                            suggested_next_inputs = [
                                "Me gustaría para el viernes por la tarde",
                                "¿Qué disponibilidad tienen esta semana?"
                            ]
                        else:
                            ai_response += "¿Para qué día y hora te gustaría agendar tu cita? ¿Y qué servicio te interesa?"
                            suggested_next_inputs = [
                                "Me gustaría para el lunes a las 2pm",
                                "¿Qué disponibilidad tienen para mañana?"
                            ]
                elif "nombre" in user_input and ("teléfono" in user_input or "telefono" in user_input):
                    # User is providing contact info
                    ai_response = confirmation_message
                    actions["appointment"] = {
                        "status": "confirmed",
                        "confirmation_message": confirmation_message
                    }
                    suggested_next_inputs = [
                        "Gracias, ¡hasta luego!",
                        "Tengo otra pregunta"
                    ]
                else:
                    ai_response = "Claro, puedo ayudarte a agendar una cita. ¿Para qué día y hora te gustaría?"
                    suggested_next_inputs = [
                        "Me gustaría para el lunes a las 2pm",
                        "¿Qué servicios ofrecen?"
                    ]
            
            elif scenario.startswith("faq") or any(word in user_input for word in ["pregunta", "info", "duda", "horario", "precio", "costo", "ubicación", "ubicacion", "dirección", "direccion", "servicio", "ofrecen", "donde", "dónde"]):
                # Try to match with configured FAQs
                matched_faq = None
                
                for faq in faqs:
                    question = faq.get("question", "").lower()
                    keywords = question.split()
                    
                    # Check if any keywords from the FAQ question are in the user input
                    if any(keyword in user_input for keyword in keywords if len(keyword) > 3):
                        matched_faq = faq
                        break
                
                if matched_faq:
                    ai_response = matched_faq.get("answer", "")
                    actions["faq_matched"] = {
                        "question": matched_faq.get("question"),
                        "answer": matched_faq.get("answer")
                    }
                else:
                    # No matching FAQ found, provide a generic response
                    if "horario" in user_input or "horas" in user_input or "abierto" in user_input:
                        ai_response = "Lo siento, no tengo esa información específica sobre los horarios. ¿Te gustaría que te conecte con alguien del equipo para que te proporcione esa información?"
                    elif "precio" in user_input or "costo" in user_input or "tarifa" in user_input:
                        ai_response = "Lo siento, no tengo información detallada sobre los precios. ¿Te gustaría agendar una consulta para hablar sobre los servicios y precios?"
                    elif "ubicación" in user_input or "ubicacion" in user_input or "dirección" in user_input or "direccion" in user_input:
                        ai_response = "Lo siento, no tengo la información exacta de la ubicación. ¿Deseas que te conecte con alguien del equipo?"
                    else:
                        ai_response = "No tengo esa información específica. ¿Hay algo más en lo que pueda ayudarte?"
                
                suggested_next_inputs = [
                    "Gracias, también me gustaría reservar una cita",
                    "¿Qué servicios ofrecen?",
                    "Gracias, es todo por ahora"
                ]
                        
            elif scenario == "dissatisfied_customer" or any(word in user_input for word in ["insatisfecho", "descontento", "molesto", "queja", "reclamar", "mal servicio", "mala experiencia", "problema"]):
                # Handle dissatisfied customer
                ai_response = "Lamento mucho escuchar que no has tenido una buena experiencia. En nuestro negocio nos importa mucho la satisfacción de nuestros clientes. ¿Podrías contarme más sobre lo que ocurrió para poder ayudarte mejor?"
                actions["customer_complaint"] = {
                    "status": "acknowledged",
                    "severity": "medium"  # Default, would be determined by sentiment analysis in a real system
                }
                suggested_next_inputs = [
                    "El servicio no fue como lo esperaba porque...",
                    "Tuve que esperar demasiado tiempo",
                    "Quisiera hablar con el gerente"
                ]
            
            # Handle Spanish colloquial farewells
            elif any(word in user_input for word in ["gracias", "adios", "adiós", "chau", "hasta luego", "nos vemos", "bye", "hasta pronto", "me voy"]):
                # User is ending the conversation
                ai_response = farewell_message
                actions["conversation_ended"] = True
                suggested_next_inputs = [
                    "<Iniciar nueva conversación>"
                ]
            
            else:
                # Generic response for unrecognized inputs
                ai_response = "Disculpa, no estoy segura de entender tu solicitud. ¿Puedo ayudarte a agendar una cita o responder alguna pregunta sobre nuestros servicios?"
                suggested_next_inputs = [
                    "Quisiera agendar una cita",
                    "¿Cuáles son sus horarios de atención?",
                    "¿Qué servicios ofrecen?"
                ]
            
            # Add AI response to conversation history
            context["conversation"].append({
                "role": "assistant",
                "content": ai_response
            })
        
        # Default suggested inputs if none were set
        if not suggested_next_inputs:
            suggested_next_inputs = [
                "Quisiera agendar una cita",
                "¿Cuáles son sus horarios de atención?",
                "Gracias, hasta luego"
            ]
        
        # Create a summary of the conversation so far
        conversation_summary = ""
        if context.get("conversation"):
            conversation = context.get("conversation")
            conversation_turns = len(conversation) // 2  # Count complete turns (user + assistant)
            conversation_summary = f"Conversación de {conversation_turns} intercambios"
            
            if actions.get("appointment", {}).get("status") == "confirmed":
                conversation_summary += ". Se ha confirmado una cita."
            elif actions.get("appointment", {}).get("status") == "pending_confirmation":
                conversation_summary += ". Cita pendiente de confirmación."
            elif actions.get("faq_matched"):
                conversation_summary += f". Se ha respondido a una pregunta sobre {actions.get('faq_matched', {}).get('question', 'un tema')}."
            elif actions.get("customer_complaint"):
                conversation_summary += ". Se ha registrado una queja de cliente."
            elif actions.get("conversation_ended"):
                conversation_summary += ". Conversación finalizada satisfactoriamente."
        
        # Generate improvement suggestions based on the conversation
        improvement_suggestions = []
        performance_metrics = {
            "clarity": 0.0,
            "helpfulness": 0.0,
            "efficiency": 0.0,
            "personalization": 0.0,
            "overall": 0.0
        }
        
        # Analyze greeting message
        if greeting_message and len(greeting_message.strip()) < 50:
            improvement_suggestions.append({
                "category": "greetings",
                "suggestion": "Tu mensaje de bienvenida es muy corto. Considera añadir más información sobre tu negocio para crear una mejor primera impresión.",
                "priority": "media"
            })
            performance_metrics["clarity"] = 0.6
        else:
            performance_metrics["clarity"] = 0.9
        
        # Analyze FAQ responses
        if faqs and len(faqs) < 3:
            improvement_suggestions.append({
                "category": "faqs",
                "suggestion": "Tienes pocas preguntas frecuentes configuradas. Añade más para manejar consultas comunes automáticamente.",
                "priority": "alta"
            })
            performance_metrics["helpfulness"] = 0.5
        elif not faqs:
            improvement_suggestions.append({
                "category": "faqs",
                "suggestion": "No tienes preguntas frecuentes configuradas. Estas son esenciales para que tu asistente responda eficazmente.",
                "priority": "alta"
            })
            performance_metrics["helpfulness"] = 0.3
        else:
            performance_metrics["helpfulness"] = 0.8
        
        # Analyze appointment handling
        if scenario.startswith("appointment") and not confirmation_message:
            improvement_suggestions.append({
                "category": "citas",
                "suggestion": "No has configurado un mensaje de confirmación de citas. Esto es importante para finalizar el proceso de reserva.",
                "priority": "alta"
            })
            performance_metrics["efficiency"] = 0.4
        elif scenario.startswith("appointment") and len(confirmation_message) < 50:
            improvement_suggestions.append({
                "category": "citas",
                "suggestion": "Tu mensaje de confirmación de citas es muy breve. Añade más detalles sobre el proceso de confirmación y próximos pasos.",
                "priority": "media"
            })
            performance_metrics["efficiency"] = 0.7
        else:
            performance_metrics["efficiency"] = 0.9
        
        # Analyze conversation flow efficiency
        if context.get("conversation") and len(context.get("conversation")) > 6:
            turns_to_resolution = len(context.get("conversation")) // 2
            if actions.get("appointment", {}).get("status") == "confirmed" and turns_to_resolution > 3:
                improvement_suggestions.append({
                    "category": "eficiencia",
                    "suggestion": "Se requirieron muchos intercambios para confirmar una cita. Considera simplificar el proceso con mensajes más claros y directos.",
                    "priority": "media"
                })
                performance_metrics["efficiency"] = max(0.5, performance_metrics["efficiency"] - 0.3)
            elif not actions and turns_to_resolution > 2:
                improvement_suggestions.append({
                    "category": "eficiencia",
                    "suggestion": "La conversación no llegó a una resolución clara después de varios intercambios. Asegúrate de que tu asistente guíe mejor hacia una acción específica.",
                    "priority": "media"
                })
                performance_metrics["efficiency"] = max(0.4, performance_metrics["efficiency"] - 0.4)
        
        # Add voice configuration suggestion if not set
        if not voice_agent.get("voice_id"):
            improvement_suggestions.append({
                "category": "voz",
                "suggestion": "No has configurado una voz para tu asistente. Configura esto para una experiencia más completa.",
                "priority": "alta"
            })
        
        # Add farewell message suggestion if not set or too short
        if not farewell_message:
            improvement_suggestions.append({
                "category": "despedida",
                "suggestion": "No has configurado un mensaje de despedida. Añade uno para cerrar las conversaciones profesionalmente.",
                "priority": "media"
            })
        elif len(farewell_message.strip()) < 30:
            improvement_suggestions.append({
                "category": "despedida",
                "suggestion": "Tu mensaje de despedida es muy breve. Considera añadir un agradecimiento y una invitación a volver.",
                "priority": "baja"
            })
        
        # Analyze personalization level
        if colloquial_greeting and voice_agent.get("greetingMessage", "").lower().find("buen") >= 0:
            # The agent responds to colloquial greetings with appropriate warmth
            performance_metrics["personalization"] = 0.9
        elif voice_agent.get("greetingMessage", "") and "negocio" in voice_agent.get("greetingMessage", "").lower():
            # Agent mentions the business name in greeting
            performance_metrics["personalization"] = 0.7
        else:
            performance_metrics["personalization"] = 0.5
            
            # Add improvement suggestion for personalization
            if colloquial_greeting and performance_metrics["personalization"] < 0.7:
                improvement_suggestions.append({
                    "category": "personalización",
                    "suggestion": "Tu asistente podría responder de forma más cálida a saludos coloquiales. Considera adaptar el tono según cómo salude el cliente.",
                    "priority": "media"
                })
        
        # Calculate overall performance metric
        performance_metrics["overall"] = (performance_metrics["clarity"] + 
                                       performance_metrics["helpfulness"] + 
                                       performance_metrics["efficiency"] + 
                                       performance_metrics["personalization"]) / 4
        
        # Add scenario-specific suggestions
        if scenario == "dissatisfied_customer" and "customer_complaint" in actions:
            improvement_suggestions.append({
                "category": "quejas",
                "suggestion": "Buen manejo de la queja del cliente. Asegúrate de tener un proceso para escalamiento y seguimiento de quejas en situaciones reales.",
                "priority": "informativa"
            })
            
        # Add suggestions for very angry customers
        if scenario == "very_angry_customer" and "customer_complaint" in actions:
            improvement_suggestions.append({
                "category": "clientes_difíciles",
                "suggestion": "Con clientes muy enojados, es importante mantener la calma y mostrar empatía. Considera agregar mensajes específicos para desescalar situaciones tensas.",
                "priority": "alta"
            })
            
        # Add suggestions for handling urgent requests
        if urgency_indicators and not (actions.get("appointment", {}).get("status") == "confirmed"):
            improvement_suggestions.append({
                "category": "urgencias",
                "suggestion": "Tu asistente podría manejar mejor las solicitudes urgentes. Considera agregar mensajes específicos para casos que requieren atención inmediata.",
                "priority": "media"
            })
            
        # Add suggestions for appointment confirmations
        if actions.get("appointment", {}).get("status") == "confirmed" and len(confirmation_message) > 0 and not "contacto" in confirmation_message.lower():
            improvement_suggestions.append({
                "category": "confirmaciones",
                "suggestion": "Tu mensaje de confirmación podría incluir información de contacto en caso de que el cliente necesite hacer cambios.",
                "priority": "baja"
            })
        
        if scenario == "complex_inquiry" and not actions:
            improvement_suggestions.append({
                "category": "consultas_complejas",
                "suggestion": "Las consultas complejas no fueron manejadas eficazmente. Considera añadir más mensajes específicos para diferentes tipos de consultas.",
                "priority": "alta"
            })
        
        # Limit to top 3 most important suggestions
        priority_order = {"alta": 0, "media": 1, "baja": 2, "informativa": 3}
        improvement_suggestions.sort(key=lambda x: priority_order.get(x.get("priority", ""), 4))
        improvement_suggestions = improvement_suggestions[:3]
        
        # Return the response without audio for now (audio will be implemented separately)
        return SimulationResponse(
            ai_response=ai_response,
            suggested_next_inputs=suggested_next_inputs,
            actions=actions,
            conversation_summary=conversation_summary,
            improvement_suggestions=improvement_suggestions,
            performance_metrics=performance_metrics
        )
            
    except HTTPException as e:
        # Re-raise HTTP exceptions
        raise e
    except Exception as e:
        error_msg = f"Error simulating call: {str(e)}"
        print(error_msg)
        raise HTTPException(status_code=500, detail=error_msg)

from pydantic import BaseModel, Field
from fastapi import APIRouter, Request, Response, Depends, HTTPException, Header
from typing import Optional, List, Dict, Any
import databutton as db
import json
import hmac
import hashlib
import re
import requests
from datetime import datetime

router = APIRouter()

# Models
class MetaWhatsAppConfig(BaseModel):
    phone_number_id: str
    business_account_id: str
    access_token: str
    verification_token: str

class WhatsAppMessage(BaseModel):
    to: str
    message: str

class WhatsAppMessageResponse(BaseModel):
    success: bool
    message_id: Optional[str] = None
    error: Optional[str] = None

class WebhookPayload(BaseModel):
    object: str
    entry: List[Dict[str, Any]]

class SetupGuideStep(BaseModel):
    title: str
    content: str

class SetupGuide(BaseModel):
    steps: List[SetupGuideStep]

# Store sanitization helper
def sanitize_key(key: str) -> str:
    """Sanitize storage key to only allow alphanumeric and ._- symbols"""
    return re.sub(r'[^a-zA-Z0-9._-]', '', key)

# Helper to get configuration
def get_meta_whatsapp_config() -> Dict[str, str]:
    """Get the Meta WhatsApp configuration from storage."""
    try:
        config = db.storage.json.get("meta_whatsapp_config", default={})
        return config
    except Exception as e:
        print(f"Error retrieving Meta WhatsApp config: {e}")
        return {}

# Configuration endpoint
@router.post("/meta-whatsapp/config")
def save_meta_whatsapp_config(config: MetaWhatsAppConfig):
    try:
        # Store the configuration
        config_dict = {
            "phone_number_id": config.phone_number_id,
            "business_account_id": config.business_account_id,
            "verification_token": config.verification_token,
            "access_token": config.access_token,
        }
        
        db.storage.json.put("meta_whatsapp_config", config_dict)
        
        return {"success": True}
    except Exception as e:
        print(f"Error saving Meta WhatsApp config: {e}")
        return {"success": False, "error": str(e)}

@router.post("/meta-whatsapp/send", response_model=WhatsAppMessageResponse)
def send_whatsapp_message(message: WhatsAppMessage):
    """Send a WhatsApp message using Meta's WhatsApp Business Cloud API."""
    try:
        # Get stored configuration
        config = get_meta_whatsapp_config()
        if not config:
            return WhatsAppMessageResponse(
                success=False,
                error="Meta WhatsApp not configured. Please set up your configuration."
            )
        
        phone_number_id = config.get("phone_number_id")
        access_token = config.get("access_token")
        
        if not phone_number_id or not access_token:
            return WhatsAppMessageResponse(
                success=False,
                error="Incomplete Meta WhatsApp configuration."
            )
        
        # Format the phone number if needed
        to_number = message.to
        # Strip all non-numeric characters except the plus sign
        to_number = re.sub(r'[^\d+]', '', to_number)
        
        # Ensure it has a plus sign
        if not to_number.startswith("+"):
            to_number = "+" + to_number
        
        # Prepare the API request
        url = f"https://graph.facebook.com/v18.0/{phone_number_id}/messages"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        # Prepare request body
        body = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to_number,
            "type": "text",
            "text": {"body": message.message}
        }
        
        # Send the request
        response = requests.post(url, headers=headers, json=body)
        response_data = response.json()
        
        if response.status_code == 200:
            # Process and return the response
            message_id = response_data.get("messages", [{}])[0].get("id")
            
            # Store the message in our database for tracking
            timestamp = datetime.now().isoformat()
            storage_key = re.sub(r'[^a-zA-Z0-9._-]', '', f"meta_whatsapp_message_{to_number}_{message_id}")
            
            message_data = {
                "to": to_number,
                "message": message.message,
                "message_id": message_id,
                "status": "sent",
                "timestamp": timestamp
            }
            
            db.storage.json.put(storage_key, message_data)
            
            return WhatsAppMessageResponse(
                success=True,
                message_id=message_id
            )
        else:
            error_msg = response_data.get("error", {}).get("message", "Unknown error")
            return WhatsAppMessageResponse(
                success=False,
                error=f"API Error: {error_msg}"
            )
            
    except Exception as e:
        print(f"Error sending WhatsApp message: {e}")
        return WhatsAppMessageResponse(
            success=False,
            error=str(e)
        )

@router.get("/meta-whatsapp/status")
def check_whatsapp_status():
    """Check the status of the Meta WhatsApp integration."""
    try:
        config = get_meta_whatsapp_config()
        
        if not config:
            return {
                "status": "unconfigured",
                "message": "WhatsApp Cloud API not configured. Please set up your Meta configuration."
            }
        
        phone_number_id = config.get("phone_number_id")
        access_token = config.get("access_token")
        business_account_id = config.get("business_account_id")
        
        if not phone_number_id or not access_token or not business_account_id:
            return {
                "status": "incomplete",
                "message": "WhatsApp Cloud API configuration is incomplete."
            }
        
        # Validate configuration by making an API call
        url = f"https://graph.facebook.com/v18.0/{phone_number_id}"
        headers = {"Authorization": f"Bearer {access_token}"}
        
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            phone_data = response.json()
            return {
                "status": "operational",
                "provider": "Meta WhatsApp Cloud API",
                "phone_number": phone_data.get("display_phone_number", "Unknown")
            }
        else:
            error_data = response.json()
            error_msg = error_data.get("error", {}).get("message", "Unknown error")
            return {
                "status": "error",
                "message": f"Error validating Meta WhatsApp configuration: {error_msg}"
            }
    
    except Exception as e:
        print(f"Error checking Meta WhatsApp status: {e}")
        return {
            "status": "error",
            "message": str(e)
        }

@router.get("/meta-whatsapp/verify-webhook")
def verify_webhook(
    mode: str = Header(None, alias="hub.mode"),
    token: str = Header(None, alias="hub.verify_token"),
    challenge: str = Header(None, alias="hub.challenge")
):
    """Verify the webhook subscription for Meta WhatsApp Cloud API."""
    print(f"Received verification request: mode={mode}, token={token}, challenge={challenge}")
    
    if not mode or not token:
        return {"error": "Missing required parameters"}
    
    if mode != "subscribe":
        return {"error": "Invalid mode"}
    
    # Get the verification token from our config
    config = get_meta_whatsapp_config()
    verification_token = config.get("verification_token") if config else None
    
    if not verification_token or token != verification_token:
        return {"error": "Invalid verification token"}
    
    # Return the challenge to complete verification
    return {"hub.challenge": challenge}

@router.post("/meta-whatsapp/webhook")
async def webhook_handler(request: Request):
    """Handle incoming webhook events from Meta WhatsApp Cloud API."""
    try:
        # Get the raw request body
        body_bytes = await request.body()
        body_str = body_bytes.decode("utf-8")
        
        # Parse the JSON payload
        payload = json.loads(body_str)
        print(f"Received webhook: {payload}")
        
        # Process the webhook event
        if payload.get("object") == "whatsapp_business_account":
            entries = payload.get("entry", [])
            
            for entry in entries:
                # Process each change in the webhook
                changes = entry.get("changes", [])
                for change in changes:
                    value = change.get("value", {})
                    
                    # Handle messages
                    if "messages" in value:
                        messages = value.get("messages", [])
                        for message in messages:
                            # Process the incoming message
                            message_id = message.get("id")
                            timestamp = message.get("timestamp") # Unix timestamp
                            from_number = message.get("from")
                            message_type = message.get("type")
                            
                            # Extract message content based on type
                            message_body = ""
                            if message_type == "text":
                                message_body = message.get("text", {}).get("body", "")
                            
                            # Store the incoming message
                            storage_key = re.sub(
                                r'[^a-zA-Z0-9._-]', '', 
                                f"meta_whatsapp_incoming_{from_number}_{message_id}"
                            )
                            
                            message_data = {
                                "message_id": message_id,
                                "from": from_number,
                                "timestamp": datetime.fromtimestamp(timestamp).isoformat() if timestamp else datetime.now().isoformat(),
                                "type": message_type,
                                "body": message_body,
                                "status": "received"
                            }
                            
                            db.storage.json.put(storage_key, message_data)
                    
                    # Handle status updates
                    if "statuses" in value:
                        statuses = value.get("statuses", [])
                        for status in statuses:
                            message_id = status.get("id")
                            status_value = status.get("status")  # sent, delivered, read, etc.
                            recipient_id = status.get("recipient_id")
                            timestamp = status.get("timestamp") # Unix timestamp
                            
                            # Store or update the message status
                            status_key = re.sub(
                                r'[^a-zA-Z0-9._-]', '', 
                                f"meta_whatsapp_status_{recipient_id}_{message_id}"
                            )
                            
                            status_data = {
                                "message_id": message_id,
                                "recipient": recipient_id,
                                "status": status_value,
                                "timestamp": datetime.fromtimestamp(timestamp).isoformat() if timestamp else datetime.now().isoformat()
                            }
                            
                            db.storage.json.put(status_key, status_data)
        
        # Always return a 200 OK to acknowledge receipt
        return {"success": True}
    
    except Exception as e:
        print(f"Error processing webhook: {e}")
        # Still return 200 to acknowledge receipt, even on error
        # This prevents Meta from retrying the webhook unnecessarily
        return {"success": False, "error": str(e)}
        
# Send message endpoint (duplicate definition removed)
    try:
        config = get_meta_whatsapp_config()
        if not config:
            raise HTTPException(status_code=400, detail="Meta WhatsApp no está configurado")
        
        # Format phone number (add + if needed and remove spaces)
        phone = message.to.strip()
        if not phone.startswith("+"):
            phone = "+" + phone
        
        # Remove any non-digit characters except the +
        phone = re.sub(r'[^\d+]', '', phone)
        
        # Build the API request
        url = f"https://graph.facebook.com/v17.0/{config['phone_number_id']}/messages"
        
        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": phone,
            "type": "text",
            "text": {"body": message.message}
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config['access_token']}"
        }
        
        # Make the API call
        response = requests.post(url, json=payload, headers=headers)
        
        if response.status_code != 200:
            return {"success": False, "error": f"Error sending message: {response.text}"}
        
        return {"success": True, "data": response.json()}
    except Exception as e:
        print(f"Error sending WhatsApp message via Meta API: {e}")
        return {"success": False, "error": str(e)}

# Get status endpoint (duplicate definition removed)
    try:
        config = get_meta_whatsapp_config()
        if not config or not all(k in config for k in ["phone_number_id", "access_token"]):
            return {"status": "not_configured", "message": "Meta WhatsApp no está configurado"}
        
        # Test the connection by getting the phone number details
        url = f"https://graph.facebook.com/v17.0/{config['phone_number_id']}"
        headers = {"Authorization": f"Bearer {config['access_token']}"}
        
        response = requests.get(url, headers=headers)
        
        if response.status_code != 200:
            return {
                "status": "error", 
                "message": f"Error al conectar con Meta WhatsApp API: {response.text}"
            }
        
        data = response.json()
        return {
            "status": "operational",
            "display_name": data.get("display_phone_number", "Número de WhatsApp"),
            "quality_rating": data.get("quality_rating", "unknown")
        }
    except Exception as e:
        print(f"Error checking Meta WhatsApp status: {e}")
        return {"status": "error", "message": str(e)}

# Webhook endpoint for Meta to call (duplicate definition removed)
    try:
        # Get query parameters
        query_params = dict(request.query_params)
        mode = query_params.get("hub.mode")
        token = query_params.get("hub.verify_token")
        challenge = query_params.get("hub.challenge")
        
        # Get our stored verification token
        config = get_meta_whatsapp_config()
        stored_token = config.get("verification_token", "")
        
        # Verify the mode and token
        if mode == "subscribe" and token == stored_token:
            print("WhatsApp webhook verified!")
            return Response(content=challenge, media_type="text/plain")
        else:
            print("WhatsApp webhook verification failed")
            raise HTTPException(status_code=403, detail="Verification failed")
    except Exception as e:
        print(f"Error in webhook verification: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Webhook for incoming messages (duplicate definition removed)
    

# Setup guide endpoint
@router.get("/meta-whatsapp/setup-guide")
def get_setup_guide():
    guide = SetupGuide(
        steps=[
            SetupGuideStep(
                title="Crear una cuenta de Meta Business",
                content="Si aún no tienes una, crea una cuenta de Meta Business en business.facebook.com."
            ),
            SetupGuideStep(
                title="Registro en Meta for Developers",
                content="Ve a developers.facebook.com y regístrate como desarrollador. Crea una nueva aplicación de tipo 'Business'."
            ),
            SetupGuideStep(
                title="Agregar la API de WhatsApp",
                content="En tu aplicación de Meta, agrega el producto 'WhatsApp' desde el panel de control."
            ),
            SetupGuideStep(
                title="Configurar un número de teléfono",
                content="En la configuración de WhatsApp, selecciona un número de teléfono existente o registra uno nuevo."
            ),
            SetupGuideStep(
                title="Obtener las credenciales",
                content="En la sección de API de WhatsApp, encontrarás tu Phone Number ID y puedes generar un token de acceso permanente."
            ),
            SetupGuideStep(
                title="Configurar el webhook",
                content="En la sección de Webhooks, agrega la URL de webhook proporcionada abajo y crea un token de verificación personalizado. Suscríbete a los eventos 'messages' y 'message_deliveries'."
            ),
            SetupGuideStep(
                title="Completar la configuración",
                content="Copia las credenciales (Phone Number ID, Business Account ID, Access Token) y el token de verificación en esta página."
            ),
        ]
    )
    
    return guide

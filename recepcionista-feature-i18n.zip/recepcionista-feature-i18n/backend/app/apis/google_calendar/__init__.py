from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import json
import os
import databutton as db
from app.auth import AuthorizedUser
from urllib.parse import quote, urlencode
import requests

router = APIRouter(prefix="/google-calendar")

# Models
class GoogleTokenRequest(BaseModel):
    code: str
    redirect_uri: str

class GoogleTokenResponse(BaseModel):
    access_token: str
    refresh_token: Optional[str] = None
    expires_in: int
    token_type: str

class GoogleUserInfo(BaseModel):
    email: str
    name: Optional[str] = None
    picture: Optional[str] = None

class CalendarListResponse(BaseModel):
    calendars: List[Dict[str, Any]]

class CreateEventRequest(BaseModel):
    calendar_id: str
    summary: str  # Title of the event
    description: Optional[str] = None
    location: Optional[str] = None
    start_datetime: str  # ISO format
    end_datetime: str    # ISO format
    attendees: Optional[List[Dict[str, str]]] = None  # [{"email": "attendee@example.com"}]
    reminders: Optional[Dict[str, Any]] = None

class CreateEventResponse(BaseModel):
    event_id: str
    html_link: str  # Link to the event in Google Calendar

class DeleteEventRequest(BaseModel):
    calendar_id: str
    event_id: str

# OAuth Configuration
GOOGLE_CLIENT_ID = db.secrets.get("GOOGLE_CLIENT_ID")
GOOGLE_CLIENT_SECRET = db.secrets.get("GOOGLE_CLIENT_SECRET")
GOOGLE_AUTH_URI = "https://accounts.google.com/o/oauth2/auth"
GOOGLE_TOKEN_URI = "https://oauth2.googleapis.com/token"
GOOGLE_AUTH_PROVIDER_X509_CERT_URL = "https://www.googleapis.com/oauth2/v1/certs"

# Update redirect URIs to match what's configured in Google Cloud Console
GOOGLE_REDIRECT_URIS = [
    "http://localhost:3000/dashboard", 
    "https://recepcionistaai.com/api/google-calendar/auth-callback",
    "https://app.databutton.com/redirect/google",
    "https://recepcionistaai.com/dashboard", # Production redirect for the front-end
    "http://localhost:5000/api/google-calendar/auth-callback",
    "https://recepcionistaai.com", # Add main domain for Firebase Auth redirect
    "https://recepcionistaai.com/login"
]

GOOGLE_JAVASCRIPT_ORIGINS = [
    "http://localhost:3000", 
    "https://recepcionistaai.com",
    "https://app.databutton.com",
    "https://recepcionistaai.com/dashboard",
    "https://recepcionistaai.com/login"
]

GOOGLE_SCOPE = [
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
    "openid" # Add OpenID Connect scope to avoid conflicts with Firebase Auth
]

def get_token_storage_key(user_id: str) -> str:
    """Sanitize and return a storage key for the user's Google token"""
    return f"google_token_{user_id}".replace("/", "_")

@router.get("/auth-url")
async def get_auth_url(user: Optional[AuthorizedUser] = None):
    """Get the Google OAuth authorization URL"""
    if not GOOGLE_CLIENT_ID:
        raise HTTPException(status_code=500, detail="Google Client ID not configured")

    try:
        # Use the production redirect URI for the deployed app, local for development
        redirect_uri = GOOGLE_REDIRECT_URIS[3] if os.environ.get("DATABUTTON_ENV") == "production" else GOOGLE_REDIRECT_URIS[0]
        print(f"Using redirect URI: {redirect_uri} for environment: {os.environ.get('DATABUTTON_ENV', 'development')}")
        
        params = {
            "client_id": GOOGLE_CLIENT_ID,
            "redirect_uri": redirect_uri,
            "scope": " ".join(GOOGLE_SCOPE),
            "response_type": "code",
            "access_type": "offline",  # To get refresh token
            "prompt": "consent",  # Always prompt for consent to get refresh token
        }

        # Add state parameter if user is authenticated
        if user:
            params["state"] = user.sub  # Pass user ID as state for verification
        else:
            # Use a placeholder for unauthenticated users
            # The frontend will need to handle user identification during the callback
            print("Warning: User not authenticated when requesting auth URL")
            params["state"] = "unauthenticated"

        auth_url = f"{GOOGLE_AUTH_URI}?{urlencode(params)}"
        return {"auth_url": auth_url}
    except Exception as e:
        print(f"Error generating Google auth URL: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error generating auth URL: {str(e)}") from e

@router.post("/exchange-token", response_model=GoogleTokenResponse)
async def exchange_token(request: GoogleTokenRequest, user: Optional[AuthorizedUser] = None):
    """Exchange authorization code for access and refresh tokens"""
    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        raise HTTPException(status_code=500, detail="Google Client credentials not configured")
    
    if not user:
        print("Warning: User not authenticated during token exchange")
    
    try:
        # Exchange code for tokens
        token_data = {
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "code": request.code,
            "redirect_uri": request.redirect_uri,
            "grant_type": "authorization_code"
        }
        
        response = requests.post(GOOGLE_TOKEN_URI, data=token_data)
        response.raise_for_status()
        token_info = response.json()
        
        # Store tokens securely
        if user:
            storage_key = get_token_storage_key(user.sub)
            db.storage.json.put(storage_key, token_info)
        else:
            # Handle unauthenticated flow - store in a temporary location
            # The UI will need to handle this and associate with user when they log in
            print("Warning: Cannot store token without authenticated user")
            # Instead of failing, we'll return the token but it won't be stored

        # Get user info to link Google account with profile
        user_info = await get_google_user_info(token_info["access_token"])

        return GoogleTokenResponse(
            access_token=token_info["access_token"],
            refresh_token=token_info.get("refresh_token"),
            expires_in=token_info["expires_in"],
            token_type=token_info["token_type"]
        )
    except requests.RequestException as e:
        raise HTTPException(status_code=400, detail=f"Failed to exchange token: {str(e)}")

async def get_google_user_info(access_token: str) -> GoogleUserInfo:
    """Get user info from Google using the access token"""
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get("https://www.googleapis.com/userinfo/v2/me", headers=headers)
        response.raise_for_status()
        user_data = response.json()

        return GoogleUserInfo(
            email=user_data["email"],
            name=user_data.get("name"),
            picture=user_data.get("picture")
        )
    except requests.RequestException as e:
        raise HTTPException(status_code=400, detail=f"Failed to get user info: {str(e)}")

async def refresh_google_token(user_id: str) -> str:
    """Refresh the Google access token using the refresh token"""
    storage_key = get_token_storage_key(user_id)

    try:
        token_info = db.storage.json.get(storage_key)
        refresh_token = token_info.get("refresh_token")

        if not refresh_token:
            raise HTTPException(status_code=400, detail="No refresh token available")

        refresh_data = {
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "refresh_token": refresh_token,
            "grant_type": "refresh_token"
        }

        response = requests.post(GOOGLE_TOKEN_URI, data=refresh_data)
        response.raise_for_status()
        new_token_info = response.json()

        # Update stored token, preserve refresh token
        token_info.update(new_token_info)
        db.storage.json.put(storage_key, token_info)

        return new_token_info["access_token"]
    except (KeyError, db.storage.FileNotFoundError):
        raise HTTPException(status_code=401, detail="No Google token found")
    except requests.RequestException as e:
        raise HTTPException(status_code=400, detail=f"Failed to refresh token: {str(e)}")

async def get_google_access_token(user_id: str) -> str:
    """Get the Google access token, refreshing if necessary"""
    storage_key = get_token_storage_key(user_id)

    try:
        token_info = db.storage.json.get(storage_key)
        # TODO: Check token expiration and refresh if needed
        # For now, always return the current token
        return token_info["access_token"]
    except (KeyError, db.storage.FileNotFoundError):
        raise HTTPException(status_code=401, detail="No Google token found")

@router.get("/calendars", response_model=CalendarListResponse)
async def list_calendars(user: AuthorizedUser):
    """List the user's Google Calendars"""
    try:
        access_token = await get_google_access_token(user.sub)
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(
            "https://www.googleapis.com/calendar/v3/users/me/calendarList",
            headers=headers
        )
        response.raise_for_status()
        calendar_list = response.json()

        # Extract relevant calendar information
        calendars = [
            {
                "id": calendar["id"],
                "summary": calendar["summary"],
                "description": calendar.get("description", ""),
                "primary": calendar.get("primary", False),
                "timeZone": calendar.get("timeZone", "UTC"),
                "backgroundColor": calendar.get("backgroundColor", "#4285F4")
            }
            for calendar in calendar_list.get("items", [])
        ]

        return CalendarListResponse(calendars=calendars)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list calendars: {str(e)}")

@router.post("/events", response_model=CreateEventResponse)
async def create_event(request: CreateEventRequest, user: AuthorizedUser):
    """Create a new event in Google Calendar"""
    try:
        access_token = await get_google_access_token(user.sub)
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }

        # Build event data
        event_data = {
            "summary": request.summary,
            "start": {
                "dateTime": request.start_datetime,
                "timeZone": "UTC"  # TODO: Get from user settings
            },
            "end": {
                "dateTime": request.end_datetime,
                "timeZone": "UTC"  # TODO: Get from user settings
            }
        }

        if request.description:
            event_data["description"] = request.description

        if request.location:
            event_data["location"] = request.location

        if request.attendees:
            event_data["attendees"] = request.attendees

        if request.reminders:
            event_data["reminders"] = request.reminders

        # Add calendar ID to URL - handle 'primary' special ID
        calendar_id = request.calendar_id
        # Only URL encode if it's not the special 'primary' calendar ID
        if calendar_id != 'primary':
            calendar_id = quote(calendar_id)
        url = f"https://www.googleapis.com/calendar/v3/calendars/{calendar_id}/events"

        response = requests.post(url, headers=headers, json=event_data)
        response.raise_for_status()
        result = response.json()

        return CreateEventResponse(
            event_id=result["id"],
            html_link=result["htmlLink"]
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create event: {str(e)}")

@router.delete("/events")
async def delete_event(request: DeleteEventRequest, user: AuthorizedUser):
    """Delete an event from Google Calendar"""
    try:
        access_token = await get_google_access_token(user.sub)
        headers = {"Authorization": f"Bearer {access_token}"}

        # Add calendar ID and event ID to URL
        calendar_id = request.calendar_id
        event_id = request.event_id

        # Only URL encode if it's not the special 'primary' calendar ID
        if calendar_id != 'primary':
            calendar_id = quote(calendar_id)

        # Always URL encode the event ID
        event_id = quote(event_id)

        url = f"https://www.googleapis.com/calendar/v3/calendars/{calendar_id}/events/{event_id}"

        response = requests.delete(url, headers=headers)
        response.raise_for_status()

        return {"success": True, "message": "Event deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete event: {str(e)}")

@router.get("/connection-status")
async def get_connection_status(user: Optional[AuthorizedUser] = None):
    """Check if the user has connected their Google Calendar"""
    if not user:
        print("Warning: User not authenticated during connection status check")
        return {"connected": False, "message": "No user authentication"}
        
    storage_key = get_token_storage_key(user.sub)

    try:
        # Try to get the token to check if it exists
        token_info = db.storage.json.get(storage_key)

        # Get user info to verify connection
        try:
            user_info = await get_google_user_info(token_info["access_token"])
            return {
                "connected": True,
                "email": user_info.email,
                "name": user_info.name,
                "picture": user_info.picture
            }
        except HTTPException:
            # Try to refresh the token
            try:
                access_token = await refresh_google_token(user.sub)
                user_info = await get_google_user_info(access_token)
                return {
                    "connected": True,
                    "email": user_info.email,
                    "name": user_info.name,
                    "picture": user_info.picture
                }
            except HTTPException:
                # Token refresh failed
                return {"connected": False}
    except (KeyError, db.storage.FileNotFoundError):
        return {"connected": False}

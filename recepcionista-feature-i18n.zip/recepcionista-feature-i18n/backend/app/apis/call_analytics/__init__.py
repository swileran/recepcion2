from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime
from app.auth import AuthorizedUser
import databutton as db
from firebase_admin import firestore
import uuid
import json

router = APIRouter(prefix="/call-analytics")

class AppointmentDetails(BaseModel):
    service: str
    date: datetime
    confirmed: bool

class FaqDetails(BaseModel):
    topic: str
    question: str

class ComplaintDetails(BaseModel):
    severity: str  # "low", "medium", or "high"
    topic: str

class CallRecord(BaseModel):
    businessId: str
    date: datetime
    duration: int  # in seconds
    outcome: str  # "appointment", "faq", "complaint", or "other"
    successful: bool
    clientName: Optional[str] = None
    clientPhone: Optional[str] = None
    appointmentDetails: Optional[AppointmentDetails] = None
    faqDetails: Optional[FaqDetails] = None
    complaintDetails: Optional[ComplaintDetails] = None
    conversationSummary: str
    tags: Optional[List[str]] = None

class SimulationToCallRequest(BaseModel):
    simulationId: str
    scenarioId: str
    scenarioName: str
    date: datetime
    successful: bool
    conversationSummary: str
    appointmentStatus: Optional[str] = None
    appointmentService: Optional[str] = None
    faqMatched: Optional[bool] = None
    faqTopic: Optional[str] = None
    customerComplaint: Optional[bool] = None
    complaintSeverity: Optional[str] = None
    performanceMetrics: Optional[Dict[str, float]] = None
    improvementSuggestions: Optional[List[Dict[str, str]]] = None
    duration: Optional[int] = None  # in seconds

class CallListResponse(BaseModel):
    calls: List[Dict[str, Any]]

# Convert simulation data to call record
@router.post("/convert-simulation", response_model=Dict[str, Any])
def convert_simulation_to_call(request: SimulationToCallRequest, user: AuthorizedUser):
    """Convert a simulation result to a call record and save it to Firestore"""
    
    try:
        # Build the call record
        call_record = {
            "businessId": user.sub,
            "date": request.date,
            "duration": request.duration or 120,  # Default to 2 minutes if not provided
            "successful": request.successful,
            "conversationSummary": request.conversationSummary,
            "tags": ["simulación", request.scenarioName]
        }
        
        # Determine outcome and add details
        if request.appointmentStatus:
            call_record["outcome"] = "appointment"
            call_record["appointmentDetails"] = {
                "service": request.appointmentService or "Servicio no especificado",
                "date": request.date,  # Using the simulation date as placeholder
                "confirmed": request.appointmentStatus == "confirmed"
            }
        elif request.faqMatched:
            call_record["outcome"] = "faq"
            call_record["faqDetails"] = {
                "topic": request.faqTopic or "Tema general",
                "question": "Pregunta simulada"  # Placeholder
            }
        elif request.customerComplaint:
            call_record["outcome"] = "complaint"
            call_record["complaintDetails"] = {
                "severity": request.complaintSeverity or "medium",
                "topic": "Queja simulada"  # Placeholder
            }
        else:
            call_record["outcome"] = "other"
        
        # Get Firestore client
        db = firestore.client()
        
        # Add the call record to Firestore
        call_ref = db.collection("calls").document()
        call_ref.set(call_record)
        
        return {
            "success": True,
            "message": "Registro de llamada guardado correctamente",
            "call_id": call_ref.id
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al guardar el registro de llamada: {str(e)}")

@router.get("/list", response_model=CallListResponse)
def list_calls(user: AuthorizedUser):
    """List all call records for a business"""
    
    try:
        # Get Firestore client
        db = firestore.client()
        
        # Query calls collection
        calls_ref = db.collection("calls")
        query = calls_ref.where("businessId", "==", user.sub).order_by("date", direction=firestore.Query.DESCENDING)
        
        results = query.stream()
        
        # Convert to list of dictionaries
        calls = []
        for doc in results:
            call_data = doc.to_dict()
            call_data["id"] = doc.id
            
            # Convert Firestore timestamps to ISO format strings
            if "date" in call_data and hasattr(call_data["date"], "isoformat"):
                call_data["date"] = call_data["date"].isoformat()
                
            if "appointmentDetails" in call_data and call_data["appointmentDetails"] and "date" in call_data["appointmentDetails"]:
                if hasattr(call_data["appointmentDetails"]["date"], "isoformat"):
                    call_data["appointmentDetails"]["date"] = call_data["appointmentDetails"]["date"].isoformat()
            
            calls.append(call_data)
        
        return {"calls": calls}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al obtener los registros de llamadas: {str(e)}")

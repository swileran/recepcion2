from fastapi import APIRouter, HTTPException
import requests
import json
import databutton as db
from pydantic import BaseModel
from typing import Dict, List, Optional
import base64

router = APIRouter(prefix="/voice-synthesis")

# Models
class VoiceDetails(BaseModel):
    id: str
    name: str
    voice_id: str
    description: str = ""
    region: str = ""
    gender: str = ""
    style: str = ""

class VoiceListResponse(BaseModel):
    voices: List[VoiceDetails]

class TextToSpeechRequest(BaseModel):
    text: str
    voice_id: str
    model_id: Optional[str] = "eleven_multilingual_v2"

class TextToSpeechResponse(BaseModel):
    audio_base64: str

# Spanish voice IDs from ElevenLabs with regional metadata
SPANISH_VOICE_SAMPLES = {
    # Spain (Castilian)
    "antonio": {
        "voice_id": "29vD33N1CtxCmqQRPOHJ",
        "name": "Antonio",
        "description": "Masculino, acento español de España",
        "region": "España",
        "gender": "Masculino",
        "style": "Profesional"
    },
    "elena": {
        "voice_id": "MF3mGyEYCl7XYWbV9V6O",
        "name": "Elena", 
        "description": "Femenina, acento español de España",
        "region": "España",
        "gender": "Femenina",
        "style": "Cálida"
    },
    # Latin America - Mexico/Central America
    "ximena": {
        "voice_id": "gD1IexrzCvsXPHUuT0s3",
        "name": "Ximena",
        "description": "Femenina, acento mexicano",
        "region": "México",
        "gender": "Femenina",
        "style": "Profesional"
    },
    "rodrigo": {
        "voice_id": "ZQ6m87kt4zh0Wrc3C91j",
        "name": "Rodrigo",
        "description": "Masculino, acento mexicano",
        "region": "México",
        "gender": "Masculino",
        "style": "Casual"
    },
    # South America - Colombia
    "valeria": {
        "voice_id": "ThT5KcBeYPX3keUQqHPh",
        "name": "Valeria",
        "description": "Femenina, acento colombiano",
        "region": "Colombia",
        "gender": "Femenina",
        "style": "Amigable"
    },
    # South America - Argentina
    "mateo": {
        "voice_id": "ErXwobaYiN019PkySvjV",
        "name": "Mateo",
        "description": "Masculino, acento argentino",
        "region": "Argentina",
        "gender": "Masculino",
        "style": "Conversacional"
    },
    # Caribbean - Cuban/Dominican
    "camila": {
        "voice_id": "EXAVITQu4vr4xnSDxMaL",
        "name": "Camila",
        "description": "Femenina, acento caribeño",
        "region": "Caribe",
        "gender": "Femenina",
        "style": "Expresiva"
    }
}

def get_elevenlabs_api_key():
    api_key = db.secrets.get("ELEVENLABS_API_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="ElevenLabs API key not configured")
    return api_key

@router.get("/voices", response_model=VoiceListResponse)
def get_voice_options():
    """Get available Spanish voices from ElevenLabs with regional metadata"""
    try:
        # Return predefined Spanish voices with regional metadata
        voices = []
        for voice_id, voice_data in SPANISH_VOICE_SAMPLES.items():
            voices.append({
                "id": voice_id,
                "name": f"{voice_data['name']} ({voice_data['gender']})",
                "voice_id": voice_data['voice_id'],
                "description": voice_data['description'],
                "region": voice_data['region'],
                "gender": voice_data['gender'],
                "style": voice_data['style']
            })
        
        # Sort by region and then by name
        voices.sort(key=lambda x: (x['region'], x['name']))
        
        return VoiceListResponse(voices=voices)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching voices: {str(e)}")

import hashlib
import os

# Cache directory for storing audio files
CACHE_DIR = "voice_cache"
os.makedirs(CACHE_DIR, exist_ok=True)

# Create regional folders for better organization
for region in set(voice['region'] for voice in SPANISH_VOICE_SAMPLES.values()):
    os.makedirs(os.path.join(CACHE_DIR, region.lower().replace(" ", "_")), exist_ok=True)

@router.post("/text-to-speech", response_model=TextToSpeechResponse)
def text_to_speech(request: TextToSpeechRequest):
    """Convert text to speech using ElevenLabs API with caching"""
    try:
        # Map internal voice ID to ElevenLabs voice ID
        voice_data = SPANISH_VOICE_SAMPLES.get(request.voice_id)
        elevenlabs_voice_id = None
        region = "general"
        
        if voice_data:
            elevenlabs_voice_id = voice_data["voice_id"]
            region = voice_data["region"].lower().replace(" ", "_")
        else:
            # If not found in our mapping, use the provided ID directly
            elevenlabs_voice_id = request.voice_id
            
        # Create a cache key based on text, voice ID and model
        cache_key = hashlib.md5(f"{request.text}:{elevenlabs_voice_id}:{request.model_id}".encode()).hexdigest()
        cache_file = os.path.join(CACHE_DIR, region, f"{cache_key}.mp3")
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(cache_file), exist_ok=True)
        
        # Check if we have this audio cached
        if os.path.exists(cache_file):
            print(f"Using cached audio for voice {request.voice_id}, text: {request.text[:30]}...")
            with open(cache_file, "rb") as f:
                audio_data = f.read()
                audio_base64 = base64.b64encode(audio_data).decode("utf-8")
                return TextToSpeechResponse(audio_base64=audio_base64)
        
        # If not cached, request from ElevenLabs API
        api_key = get_elevenlabs_api_key()
        
        url = f"https://api.elevenlabs.io/v1/text-to-speech/{elevenlabs_voice_id}"
        
        headers = {
            "Accept": "audio/mpeg",
            "Content-Type": "application/json",
            "xi-api-key": api_key
        }
        
        data = {
            "text": request.text,
            "model_id": request.model_id,
            "voice_settings": {
                "stability": 0.5,
                "similarity_boost": 0.75
            }
        }
        
        print(f"Requesting audio from ElevenLabs for voice {request.voice_id}, text: {request.text[:30]}...")
        response = requests.post(url, json=data, headers=headers)
        
        if response.status_code != 200:
            error_msg = f"ElevenLabs API error: {response.status_code} - {response.text}"
            print(error_msg)
            raise HTTPException(status_code=response.status_code, detail=error_msg)
        
        # Cache the response
        with open(cache_file, "wb") as f:
            f.write(response.content)
        
        # Convert binary audio to base64 for sending over JSON
        audio_base64 = base64.b64encode(response.content).decode("utf-8")
        
        return TextToSpeechResponse(audio_base64=audio_base64)
        
    except HTTPException as e:
        # Re-raise HTTP exceptions
        raise e
    except Exception as e:
        error_msg = f"Error generating speech: {str(e)}"
        print(error_msg)
        raise HTTPException(status_code=500, detail=error_msg)

class VoiceSampleRequest(BaseModel):
    voice_id: str
    sample_type: Optional[str] = "greeting"  # greeting, farewell, confirmation, businessInfo

@router.post("/sample", response_model=TextToSpeechResponse)
def get_voice_sample(request: VoiceSampleRequest):
    """Get a sample of a voice saying different types of standard phrases"""
    sample_texts = {
        "greeting": "Hola, soy tu recepcionista virtual. ¿En qué puedo ayudarte hoy?",
        "farewell": "Muchas gracias por llamar. ¡Que tengas un excelente día!",
        "confirmation": "Perfecto, he registrado tu cita para el próximo martes a las 3 de la tarde.",
        "businessInfo": "Estamos abiertos de lunes a viernes de 9 AM a 6 PM. Los sábados atendemos de 10 AM a 2 PM."
    }
    
    # Get the appropriate sample text or default to greeting
    sample_text = sample_texts.get(request.sample_type, sample_texts["greeting"])
    
    # Check if the voice_id is one of our predefined IDs or an actual ElevenLabs ID
    if request.voice_id in SPANISH_VOICE_SAMPLES:
        # Use our internal ID
        voice_id = request.voice_id
    else:
        # It might be a direct ElevenLabs ID - validate it's in our list
        found = False
        for internal_id, data in SPANISH_VOICE_SAMPLES.items():
            if data["voice_id"] == request.voice_id:
                voice_id = internal_id
                found = True
                break
        
        if not found:
            # Default to the first voice if we can't find it
            voice_id = list(SPANISH_VOICE_SAMPLES.keys())[0]
            print(f"Voice ID {request.voice_id} not found, defaulting to {voice_id}")
    
    # Create a text-to-speech request with the sample text
    tts_request = TextToSpeechRequest(
        text=sample_text,
        voice_id=voice_id
    )
    
    return text_to_speech(tts_request)

from fastapi import APIRouter, HTTPException, Depends, Header
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import databutton as db
import stripe
import json
from app.auth import AuthorizedUser

# Router for subscription endpoints
router = APIRouter(prefix="/subscription")

# Initialize Stripe with the API key
stripe.api_key = db.secrets.get("STRIPE_SECRET_KEY") or "" # Will override in functions if empty
WEBHOOK_SECRET = db.secrets.get("STRIPE_WEBHOOK_SECRET") or ""

# Models
class PriceOption(BaseModel):
    """Price option model"""
    id: str
    name: str
    price_id: str
    price: int
    interval: str
    currency: str
    features: List[str]

class SubscriptionPlan(BaseModel):
    """Subscription plan model"""
    id: str
    name: str
    description: str
    prices: List[PriceOption]

class CreateCheckoutSessionRequest(BaseModel):
    """Request model for creating a checkout session"""
    price_id: str
    business_id: str
    business_name: str
    customer_email: str
    success_url: str
    cancel_url: str

class CreatePortalSessionRequest(BaseModel):
    """Request model for creating a customer portal session"""
    customer_id: str
    return_url: str

class CheckoutSessionResponse(BaseModel):
    """Response model for checkout session creation"""
    session_id: str
    url: str

class CustomerPortalResponse(BaseModel):
    """Response model for customer portal session creation"""
    url: str

class SubscriptionInfo(BaseModel):
    """Subscription information model"""
    subscription_id: str
    status: str
    current_period_end: int
    cancel_at_period_end: bool
    plan_id: str
    price_id: str
    amount: int
    currency: str
    interval: str

class CustomerSubscriptionResponse(BaseModel):
    """Response model for getting customer subscription info"""
    customer_id: str
    subscriptions: List[SubscriptionInfo]
    has_active_subscription: bool

class WebhookEventData(BaseModel):
    """Model for Stripe webhook event data"""
    id: str
    type: str
    data: Dict[str, Any] = {}

# Helper function to get a list of subscription plans
def get_subscription_plans() -> List[SubscriptionPlan]:
    # Get API key (allows for testing with different keys)
    api_key = db.secrets.get("STRIPE_SECRET_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="Stripe API key not configured")
    
    stripe.api_key = api_key
    
    try:
        # Fetch products from Stripe
        products = stripe.Product.list(active=True)
        
        # Create plans from products
        plans = []
        for product in products.data:
            if not product.get("metadata", {}).get("subscription_plan"):
                continue  # Skip non-subscription products
                
            # Get prices for this product
            prices = stripe.Price.list(product=product.id, active=True)
            
            price_options = []
            for price in prices.data:
                if price.type != "recurring":
                    continue
                    
                price_options.append(PriceOption(
                    id=f"{product.id}_{price.id}",
                    name=price.nickname or f"{product.name} ({price.recurring.interval})",
                    price_id=price.id,
                    price=price.unit_amount,
                    interval=price.recurring.interval,
                    currency=price.currency,
                    features=product.get("metadata", {}).get("features", "").split(",") if product.get("metadata", {}).get("features") else []
                ))
            
            if price_options:  # Only add products with valid recurring prices
                plans.append(SubscriptionPlan(
                    id=product.id,
                    name=product.name,
                    description=product.description or "",
                    prices=price_options
                ))
                
        return plans
    except Exception as e:
        print(f"Error fetching subscription plans: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error fetching subscription plans: {str(e)}")

@router.get("/plans", response_model=List[SubscriptionPlan])
async def list_subscription_plans(user: AuthorizedUser):
    """Get available subscription plans"""
    return get_subscription_plans()

@router.post("/checkout", response_model=CheckoutSessionResponse)
async def create_checkout_session(request: CreateCheckoutSessionRequest, user: AuthorizedUser):
    """Create a Stripe checkout session for subscription"""
    api_key = db.secrets.get("STRIPE_SECRET_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="Stripe API key not configured")
    
    stripe.api_key = api_key
    
    try:
        # Look for existing customer with the same email
        customers = stripe.Customer.list(email=request.customer_email, limit=1)
        
        if customers and customers.data:
            customer = customers.data[0]
            # Update customer metadata
            stripe.Customer.modify(
                customer.id,
                metadata={
                    "business_id": request.business_id,
                    "business_name": request.business_name
                }
            )
        else:
            # Create a new customer
            customer = stripe.Customer.create(
                email=request.customer_email,
                metadata={
                    "business_id": request.business_id,
                    "business_name": request.business_name
                }
            )
        
        # Create checkout session with 14-day free trial
        checkout_session = stripe.checkout.Session.create(
            customer=customer.id,
            payment_method_types=["card"],
            line_items=[{
                "price": request.price_id,
                "quantity": 1,
            }],
            mode="subscription",
            subscription_data={
                "trial_period_days": 14  # 14-day free trial
            },
            success_url=request.success_url,
            cancel_url=request.cancel_url,
            locale="es",  # Spanish locale
            client_reference_id=request.business_id,
            metadata={
                "business_id": request.business_id,
                "business_name": request.business_name,
                "featured_product": "prod_S383n3NQk3fGHj"
            }
        )
        
        return CheckoutSessionResponse(
            session_id=checkout_session.id,
            url=checkout_session.url
        )
    except Exception as e:
        print(f"Error creating checkout session: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error creating checkout session: {str(e)}")

@router.post("/portal", response_model=CustomerPortalResponse)
async def create_portal_session(request: CreatePortalSessionRequest, user: AuthorizedUser):
    """Create a Stripe customer portal session"""
    api_key = db.secrets.get("STRIPE_SECRET_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="Stripe API key not configured")
    
    stripe.api_key = api_key
    
    try:
        # Create portal session
        portal_session = stripe.billing_portal.Session.create(
            customer=request.customer_id,
            return_url=request.return_url,
        )
        
        return CustomerPortalResponse(url=portal_session.url)
    except Exception as e:
        print(f"Error creating portal session: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error creating portal session: {str(e)}")

@router.get("/customer/{customer_id}", response_model=CustomerSubscriptionResponse)
async def get_customer_subscription(customer_id: str, user: AuthorizedUser):
    """Get subscription information for a customer"""
    api_key = db.secrets.get("STRIPE_SECRET_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="Stripe API key not configured")
    
    stripe.api_key = api_key
    
    try:
        # Get customer subscriptions
        subscriptions = stripe.Subscription.list(customer=customer_id, status="all")
        
        subscription_list = []
        has_active = False
        
        for sub in subscriptions.data:
            # Check if this subscription is active
            if sub.status in ["active", "trialing"]:
                has_active = True
            
            # Get the plan and price information
            plan = sub.items.data[0].plan if sub.items.data else None
            
            if plan:
                subscription_list.append(SubscriptionInfo(
                    subscription_id=sub.id,
                    status=sub.status,
                    current_period_end=sub.current_period_end,
                    cancel_at_period_end=sub.cancel_at_period_end,
                    plan_id=plan.product,
                    price_id=plan.id,
                    amount=plan.amount,
                    currency=plan.currency,
                    interval=plan.interval
                ))
        
        return CustomerSubscriptionResponse(
            customer_id=customer_id,
            subscriptions=subscription_list,
            has_active_subscription=has_active
        )
    except Exception as e:
        print(f"Error getting customer subscription: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting customer subscription: {str(e)}")

@router.post("/webhook", status_code=200)
async def handle_webhook(payload: bytes, signature: str = Header(None, alias="stripe-signature")):
    """Handle Stripe webhooks"""
    webhook_secret = db.secrets.get("STRIPE_WEBHOOK_SECRET")
    if not webhook_secret:
        raise HTTPException(status_code=500, detail="Stripe webhook secret not configured")
    
    api_key = db.secrets.get("STRIPE_SECRET_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="Stripe API key not configured")
    
    stripe.api_key = api_key
    
    try:
        # Verify webhook signature
        event = stripe.Webhook.construct_event(
            payload, signature, webhook_secret
        ) if signature else None
        
        if not event:
            raise HTTPException(status_code=400, detail="Missing Stripe signature header")
        
        # Process specific webhook events
        event_type = event["type"]
        data = event["data"]
        
        # Store the webhook event for logging or future reference
        event_data = WebhookEventData(
            id=event["id"],
            type=event_type,
            data=data
        )
        
        db.storage.json.put(f"webhook_events/{event['id']}", event_data.dict())
        
        # Log webhook events instead of processing them directly
        # The frontend will handle profile updates based on webhook events
        print(f"Received webhook event: {event_type}")
        
        if event_type == "checkout.session.completed":
            # A customer has completed checkout
            session = event["data"]["object"]
            customer_id = session.get("customer")
            business_id = session.get("metadata", {}).get("business_id")
            print(f"Checkout completed for customer {customer_id}, business {business_id}")
            
        elif event_type == "customer.subscription.created":
            # A subscription was created
            subscription = event["data"]["object"]
            customer_id = subscription.get("customer")
            print(f"Subscription created for customer {customer_id}")
            
        elif event_type == "customer.subscription.updated":
            # A subscription was updated
            subscription = event["data"]["object"]
            customer_id = subscription.get("customer")
            print(f"Subscription updated for customer {customer_id}")
            
        elif event_type == "customer.subscription.deleted":
            # A subscription was cancelled or ended
            subscription = event["data"]["object"]
            customer_id = subscription.get("customer")
            subscription_id = subscription.get("id")
            print(f"Subscription {subscription_id} cancelled for customer {customer_id}")
        
        # Store the event for future processing if needed
        db.storage.json.put(f"stripe_events/{event['id']}", event)
        
        # Other events like payment_succeeded, payment_failed, etc.
        # can be handled similarly
        
        return {"status": "success"}
    except Exception as e:
        print(f"Error processing webhook: {str(e)}")
        raise HTTPException(status_code=400, detail=f"Webhook error: {str(e)}")

# Helper functions
async def find_profiles_by_customer_id(customer_id: str):
    """Find profiles with the given Stripe customer ID"""
    # This is now a stub function - in production we would use Firebase Admin SDK
    # For now, we'll handle this logic directly in the frontend
    print(f"Looking for profiles with customer_id: {customer_id}")
    return []

async def update_profile_subscription(profile_id: str, data: dict):
    """Update subscription data for a profile"""
    # This is now a stub function - in production we would use Firebase Admin SDK
    # For now, we'll handle this logic directly in the frontend
    print(f"Would update profile {profile_id} with data: {data}")
    return

async def sync_subscription_with_profile(customer_id: str, profile_id: str):
    """Sync subscription data with profile"""
    try:
        # Get customer's subscriptions from Stripe
        subscriptions = stripe.Subscription.list(customer=customer_id, status="all", limit=1)
        
        # Log instead of updating directly
        if subscriptions and subscriptions.data:
            # Get the latest subscription
            subscription = subscriptions.data[0]
            plan = subscription.items.data[0].plan if subscription.items.data else None
            
            if plan:
                subscription_data = {
                    "subscription.stripeCustomerId": customer_id,
                    "subscription.subscriptionId": subscription.id,
                    "subscription.planId": plan.product,
                    "subscription.status": subscription.status,
                    "subscription.currentPeriodEnd": subscription.current_period_end,
                    "subscription.cancelAtPeriodEnd": subscription.cancel_at_period_end
                }
                
                # Log update instead of updating directly
                print(f"Would update profile {profile_id} with subscription data: {subscription_data}")
                return subscription_data
        else:
            # No active subscriptions
            subscription_data = {"subscription.stripeCustomerId": customer_id, "subscription.status": "none"}
            print(f"Would update profile {profile_id} with subscription data: {subscription_data}")
            return subscription_data
            
    except Exception as e:
        print(f"Error syncing subscription with profile: {e}")
        raise HTTPException(status_code=500, detail=f"Error syncing subscription: {e}")
    
    return {"subscription.stripeCustomerId": customer_id}

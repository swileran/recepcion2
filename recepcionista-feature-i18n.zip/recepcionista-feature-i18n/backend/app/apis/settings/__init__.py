from fastapi import APIRouter, Depends, HTTPException, Body
from pydantic import BaseModel, Field
from typing import Optional
import databutton as db
from app.auth import AuthorizedUser
import re

router = APIRouter(prefix="/settings", tags=["settings"])

class TwilioConfig(BaseModel):
    account_sid: str = Field(..., pattern=r'^AC[a-zA-Z0-9]{32}$')
    auth_token: str
    whatsapp_number: str

@router.post("/twilio")
def save_twilio_config(config: TwilioConfig, user: AuthorizedUser):
    """Save Twilio configuration for WhatsApp integration."""
    try:
        # Validate account_sid format
        if not config.account_sid.startswith("AC"):
            raise HTTPException(status_code=400, detail="Invalid Account SID format. Must start with 'AC'")

        # Format WhatsApp number
        whatsapp_number = config.whatsapp_number.strip()
        # If it doesn't have the whatsapp: prefix, add it
        if not whatsapp_number.startswith("whatsapp:"):
            whatsapp_number = f"whatsapp:{whatsapp_number}"

        # Store credentials in secrets
        db.secrets.put("TWILIO_ACCOUNT_SID", config.account_sid)
        db.secrets.put("TWILIO_AUTH_TOKEN", config.auth_token)
        db.secrets.put("TWILIO_WHATSAPP_NUMBER", whatsapp_number)

        # Store user-specific configuration in a secure way
        user_id = user.sub
        config_key = re.sub(r'[^a-zA-Z0-9._-]', '', f"twilio_config_{user_id}")
        
        # Store configuration without the auth token for security
        config_data = {
            "account_sid": config.account_sid,
            "whatsapp_number": whatsapp_number,
            "user_id": user_id,
            "configured_at": db.utils.now_iso()
        }
        
        db.storage.json.put(config_key, config_data)
        
        return {"success": True, "message": "Twilio configuration saved successfully"}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save Twilio configuration: {str(e)}")

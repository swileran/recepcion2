import { create } from "zustand";
import { firebaseApp } from "app";
import { collection, addDoc, getDocs, query, where, doc, updateDoc, deleteDoc, getFirestore } from "firebase/firestore";

// Initialize Firestore
const db = getFirestore(firebaseApp);

// Define user profile type
interface UserProfile {
  id?: string;
  userId: string;
  businessName: string;
  businessType: string;
  phone: string;
  email: string;
  address?: string;
  city?: string;
  zipCode?: string;
  servicesOffered?: string[];
  workingHours?: Record<string, { start: string; end: string }>;
  
  // Calendar settings
  calendarSettings?: {
    appointmentDuration?: number; // Default appointment duration in minutes
    bufferTime?: number; // Buffer time between appointments in minutes
    maxAdvanceBookingDays?: number; // How far in advance clients can book
    googleCalendarIntegrated?: boolean; // Whether Google Calendar is integrated
    googleCalendarId?: string; // Google Calendar ID if integrated
  };
  
  // Voice agent configuration
  voiceAgent?: {
    voice?: string;
    voice_id?: string; // ElevenLabs voice ID
    greetingMessage?: string;
    farewellMessage?: string;
    faqs?: Array<{question: string; answer: string}>;
    confirmationMessage?: string;
  };
  
  // Subscription information
  subscription?: {
    stripeCustomerId?: string;
    subscriptionId?: string;
    planId?: string;
    status?: string;
    currentPeriodEnd?: number;
    cancelAtPeriodEnd?: boolean;
  };
  
  createdAt: Date;
  updatedAt: Date;
}

interface ProfileState {
  profile: UserProfile | null;
  isLoading: boolean;
  error: Error | null;
  
  // Actions
  createProfile: (data: Omit<UserProfile, 'createdAt' | 'updatedAt'>) => Promise<void>;
  updateProfile: (id: string, data: Partial<UserProfile>) => Promise<void>;
  fetchProfile: (userId: string) => Promise<void>;
}

export const useProfileStore = create<ProfileState>((set) => ({
  profile: null,
  isLoading: false,
  error: null,
  
  createProfile: async (data) => {
    try {
      set({ isLoading: true, error: null });
      
      console.log('Creating profile for user:', data.userId);
      
      // Check if profile already exists for this user
      const profilesRef = collection(db, "profiles");
      const q = query(profilesRef, where("userId", "==", data.userId));
      const querySnapshot = await getDocs(q);
      
      if (!querySnapshot.empty) {
        throw new Error("El perfil ya existe para este usuario");
      }
      
      // First update local state to avoid data loss if Firestore fails
      const profileData: UserProfile = {
        ...data,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      set({ 
        profile: { ...profileData, id: 'temp-id' },
        isLoading: true 
      });
      
      const docRef = await addDoc(collection(db, "profiles"), profileData);
      
      set({ 
        profile: { ...profileData, id: docRef.id },
        isLoading: false 
      });
    } catch (error) {
      console.error('Error creating profile:', error);
      set({ error: error as Error, isLoading: false });
      throw error; // Re-throw to let the component handle it
    }
  },
  
  updateProfile: async (id, data) => {
    try {
      set({ isLoading: true, error: null });
      
      console.log('Updating profile:', id, data);
      
      // First update local state to avoid data loss if Firestore fails
      set(state => ({
        profile: state.profile ? { ...state.profile, ...data, updatedAt: new Date() } : null,
        isLoading: true
      }));
      
      const profileRef = doc(db, "profiles", id);
      
      // Deeply clean the data to remove undefined values and ensure proper types
      const deepCleanObject = (obj: any): any => {
        // Special case for null or undefined
        if (obj === null || obj === undefined) {
          return null; // Always use null instead of undefined for Firestore
        }
        
        // Handle primitive types
        if (typeof obj !== 'object') {
          // Convert NaN to null
          if (typeof obj === 'number' && isNaN(obj)) {
            return null;
          }
          return obj;
        }
        
        // Handle arrays
        if (Array.isArray(obj)) {
          return obj
            .map(item => deepCleanObject(item))
            .filter(item => item !== undefined && item !== null);
        }
        
        // Handle objects - but skip Date objects
        if (obj instanceof Date) {
          return obj;
        }
        
        // Process regular objects
        const cleaned: Record<string, any> = {};
        for (const [key, value] of Object.entries(obj)) {
          // Skip undefined values completely
          if (value === undefined) continue;
          
          const cleanedValue = deepCleanObject(value);
          // Only add non-undefined values
          if (cleanedValue !== undefined) {
            cleaned[key] = cleanedValue;
          }
        }
        
        return cleaned;
      };
      
      const cleanedData = deepCleanObject(data);
      
      console.log('Cleaned data for Firestore:', JSON.stringify(cleanedData));
      
      await updateDoc(profileRef, {
        ...cleanedData,
        updatedAt: new Date()
      });
      
      set({ isLoading: false });
    } catch (error) {
      console.error('Error updating profile:', error);
      set({ error: error as Error, isLoading: false });
      throw error; // Re-throw to let the component handle it
    }
  },
  
  fetchProfile: async (userId) => {
    try {
      set({ isLoading: true, error: null });
      
      console.log('Fetching profile for user:', userId);
      
      const profilesRef = collection(db, "profiles");
      const q = query(profilesRef, where("userId", "==", userId));
      const querySnapshot = await getDocs(q);
      
      if (querySnapshot.empty) {
        set({ profile: null, isLoading: false });
        return;
      }
      
      const profileDoc = querySnapshot.docs[0];
      const profileData = profileDoc.data() as UserProfile;
      
      set({ 
        profile: { ...profileData, id: profileDoc.id },
        isLoading: false 
      });
    } catch (error) {
      set({ error: error as Error, isLoading: false });
    }
  }
}));

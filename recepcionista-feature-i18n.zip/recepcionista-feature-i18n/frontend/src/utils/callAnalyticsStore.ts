import { create } from "zustand";
import { firebaseApp } from "app";
import { collection, query, where, orderBy, getDocs, addDoc, getFirestore, Timestamp, onSnapshot } from "firebase/firestore";
import { User } from "firebase/auth";

// Initialize Firestore
const db = getFirestore(firebaseApp);

// Call data structure
export interface CallRecord {
  id?: string;
  businessId: string;
  date: Date;
  duration: number; // in seconds
  outcome: 'appointment' | 'faq' | 'complaint' | 'other';
  successful: boolean;
  clientName?: string;
  clientPhone?: string;
  appointmentDetails?: {
    service: string;
    date: Date;
    confirmed: boolean;
  };
  faqDetails?: {
    topic: string;
    question: string;
  };
  complaintDetails?: {
    severity: 'low' | 'medium' | 'high';
    topic: string;
  };
  conversationSummary: string;
  tags?: string[];
}

// Analytics period structure
export type AnalyticsPeriod = 'today' | 'week' | 'month' | 'custom';

// Call analytics metrics structure
export interface CallAnalytics {
  totalCalls: number;
  totalDuration: number;
  averageDuration: number;
  appointmentsBooked: number;
  appointmentsBookedRate: number;
  faqsAnswered: number;
  complaintsHandled: number;
  successRate: number;
  outcomeCounts: {
    appointment: number;
    faq: number;
    complaint: number;
    other: number;
  };
  serviceRequestCounts: Record<string, number>;
  callsByDate: Array<{date: string; count: number}>;
}

export interface CallAnalyticsState {
  calls: CallRecord[];
  isLoading: boolean;
  error: Error | null;
  analytics: CallAnalytics | null;
  dateRange: {
    startDate: Date;
    endDate: Date;
  };
  
  // Methods
  fetchCalls: (userId: string, period?: AnalyticsPeriod, startDate?: Date, endDate?: Date) => Promise<void>;
  addCall: (call: Omit<CallRecord, 'id'>) => Promise<string | null>;
  calculateAnalytics: () => void;
  setDateRange: (startDate: Date, endDate: Date) => void;
}

// Helper to get date ranges
const getDateRange = (period: AnalyticsPeriod): { startDate: Date, endDate: Date } => {
  const now = new Date();
  const endDate = new Date(now);
  let startDate = new Date(now);
  
  switch (period) {
    case 'today':
      startDate.setHours(0, 0, 0, 0);
      break;
    case 'week':
      startDate.setDate(now.getDate() - 7);
      break;
    case 'month':
      startDate.setMonth(now.getMonth() - 1);
      break;
    case 'custom':
      // Custom range will be set manually
      break;
  }
  
  return { startDate, endDate };
};

export const useCallAnalyticsStore = create<CallAnalyticsState>((set, get) => ({
  calls: [],
  isLoading: false,
  error: null,
  analytics: null,
  dateRange: {
    startDate: new Date(new Date().setDate(new Date().getDate() - 30)), // Default to last 30 days
    endDate: new Date()
  },
  
  // Fetch calls for a user within a date range
  fetchCalls: async (userId: string, period: AnalyticsPeriod = 'month', startDate?: Date, endDate?: Date) => {
    set({ isLoading: true, error: null });
    
    try {
      // Determine date range
      let dateRange;
      if (period === 'custom' && startDate && endDate) {
        dateRange = { startDate, endDate };
      } else {
        dateRange = getDateRange(period);
      }
      
      set({ dateRange }); // Update store date range
      
      // Create Firestore query
      const callsRef = collection(db, "calls");
      const callsQuery = query(
        callsRef,
        where("businessId", "==", userId),
        where("date", ">=", Timestamp.fromDate(dateRange.startDate)),
        where("date", "<=", Timestamp.fromDate(dateRange.endDate)),
        orderBy("date", "desc")
      );
      
      // Execute query
      const querySnapshot = await getDocs(callsQuery);
      const calls: CallRecord[] = [];
      
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        calls.push({
          ...data,
          id: doc.id,
          date: data.date.toDate(),
          appointmentDetails: data.appointmentDetails ? {
            ...data.appointmentDetails,
            date: data.appointmentDetails.date.toDate()
          } : undefined,
        } as CallRecord);
      });
      
      set({ calls, isLoading: false });
      get().calculateAnalytics();
    } catch (error) {
      console.error("Error fetching calls:", error);
      set({ error: error as Error, isLoading: false });
    }
  },
  
  // Add a new call record
  addCall: async (call: Omit<CallRecord, 'id'>) => {
    try {
      // Convert JavaScript Date objects to Firestore Timestamps
      const firestoreData = {
        ...call,
        date: Timestamp.fromDate(call.date),
        appointmentDetails: call.appointmentDetails ? {
          ...call.appointmentDetails,
          date: Timestamp.fromDate(call.appointmentDetails.date)
        } : undefined,
        createdAt: Timestamp.fromDate(new Date())
      };
      
      // Add document to Firestore
      const docRef = await addDoc(collection(db, "calls"), firestoreData);
      
      // Update local state
      set(state => ({
        calls: [{ ...call, id: docRef.id }, ...state.calls]
      }));
      
      // Recalculate analytics
      get().calculateAnalytics();
      
      return docRef.id;
    } catch (error) {
      console.error("Error adding call record:", error);
      return null;
    }
  },
  
  // Calculate analytics from the current calls data
  calculateAnalytics: () => {
    const { calls } = get();
    
    if (calls.length === 0) {
      set({
        analytics: {
          totalCalls: 0,
          totalDuration: 0,
          averageDuration: 0,
          appointmentsBooked: 0,
          appointmentsBookedRate: 0,
          faqsAnswered: 0,
          complaintsHandled: 0,
          successRate: 0,
          outcomeCounts: {
            appointment: 0,
            faq: 0,
            complaint: 0,
            other: 0
          },
          serviceRequestCounts: {},
          callsByDate: []
        }
      });
      return;
    }
    
    // Calculate general metrics
    const totalCalls = calls.length;
    const totalDuration = calls.reduce((sum, call) => sum + call.duration, 0);
    const averageDuration = totalDuration / totalCalls;
    
    // Calculate outcome-specific metrics
    const appointmentsBooked = calls.filter(call => call.outcome === 'appointment' && call.appointmentDetails?.confirmed).length;
    const appointmentsBookedRate = (appointmentsBooked / totalCalls) * 100;
    const faqsAnswered = calls.filter(call => call.outcome === 'faq').length;
    const complaintsHandled = calls.filter(call => call.outcome === 'complaint').length;
    const successfulCalls = calls.filter(call => call.successful).length;
    const successRate = (successfulCalls / totalCalls) * 100;
    
    // Count outcomes
    const outcomeCounts = {
      appointment: calls.filter(call => call.outcome === 'appointment').length,
      faq: faqsAnswered,
      complaint: complaintsHandled,
      other: calls.filter(call => call.outcome === 'other').length
    };
    
    // Count service requests
    const serviceRequestCounts: Record<string, number> = {};
    calls.forEach(call => {
      if (call.outcome === 'appointment' && call.appointmentDetails?.service) {
        const service = call.appointmentDetails.service;
        serviceRequestCounts[service] = (serviceRequestCounts[service] || 0) + 1;
      }
    });
    
    // Group calls by date
    const dateMap: Record<string, number> = {};
    calls.forEach(call => {
      const dateStr = call.date.toISOString().split('T')[0]; // YYYY-MM-DD
      dateMap[dateStr] = (dateMap[dateStr] || 0) + 1;
    });
    
    const callsByDate = Object.entries(dateMap)
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => a.date.localeCompare(b.date));
    
    // Update analytics state
    set({
      analytics: {
        totalCalls,
        totalDuration,
        averageDuration,
        appointmentsBooked,
        appointmentsBookedRate,
        faqsAnswered,
        complaintsHandled,
        successRate,
        outcomeCounts,
        serviceRequestCounts,
        callsByDate
      }
    });
  },
  
  // Set custom date range
  setDateRange: (startDate: Date, endDate: Date) => {
    set({ dateRange: { startDate, endDate } });
  }
}));

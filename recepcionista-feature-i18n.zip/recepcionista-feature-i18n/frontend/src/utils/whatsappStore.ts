import { create } from "zustand";
import brain from "brain";
import { toast } from "sonner";
import { WhatsAppTemplate, WhatsAppMessageRequest } from "types";
import { firebaseApp } from "app";
import { collection, query, orderBy, onSnapshot, addDoc, updateDoc, where, getDocs, doc, setDoc, getDoc, serverTimestamp, getFirestore } from "firebase/firestore";
import { User } from "firebase/auth";
import { WhatsAppMessage, WhatsAppStore, WhatsAppTemplate as CustomWhatsAppTemplate, WhatsAppMessageRequest as CustomWhatsAppMessageRequest } from "./whatsappTypes";

// Initialize Firestore
const db = getFirestore(firebaseApp);

// Define the WhatsApp message interface
export type { WhatsAppMessage, WhatsAppStore } from "./whatsappTypes";

// Format phone number to E.164 format
export const formatPhone = (phone: string): string => {
  // Remove all non-numeric characters
  const cleaned = phone.replace(/\D/g, "");
  
  // Ensure it has country code
  if (!cleaned.startsWith("1") && !cleaned.startsWith("52")) {
    // Default to US/Canada code (1)
    return `1${cleaned}`;
  }
  
  return cleaned;
};

// Create the WhatsApp store
export const useWhatsAppStore = create<WhatsAppStore>((set, get) => ({
  messages: {},
  activePhone: null,
  isLoading: false,
  error: null,
  
  // Set the active conversation phone number
  setActivePhone: (phone: string) => {
    set({ activePhone: phone });
  },
  
  // Send a text message to a WhatsApp number
  sendMessage: async (to: string, text: string) => {
    const formattedTo = formatPhone(to);
    set({ isLoading: true, error: null });
    
    try {
      // First check if WhatsApp is configured
      const statusResponse = await brain.check_whatsapp_status();
      const statusData = await statusResponse.json();
      
      if (statusData.status !== "operational") {
        throw new Error("WhatsApp no está configurado correctamente. Por favor, configura tus credenciales de Twilio.");
      }
      
      // Create a temporary message ID
      const tempId = `temp-${Date.now()}`;
      
      // Add the message to the local state optimistically
      const message: WhatsAppMessage = {
        id: tempId,
        body: text,
        sender: "business",
        timestamp: new Date(),
        status: "sent",
        phone: formattedTo
      };
      
      get().addMessage(message);
      
      // Send the message via the API
      const request: WhatsAppMessageRequest = {
        to_number: formattedTo,
        message: text
      };
      
      const response = await brain.send_whatsapp_message(request);
      const data = await response.json();
      
      if (data.success) {
        // Update the message with the new ID and save to Firestore
        const messages = [...get().messages[formattedTo] || []];
        const msgIndex = messages.findIndex(m => m.id === tempId);
        
        if (msgIndex !== -1) {
          messages[msgIndex] = {
            ...messages[msgIndex],
            id: data.message_sid as string,
            status: "sent"
          };
          
          set({
            messages: {
              ...get().messages,
              [formattedTo]: messages
            }
          });
          
          // Store in Firestore if user is authenticated
          const { user } = get();
          if (user) {
            try {
              const messagesCollection = collection(db, `users/${user.uid}/whatsapp_messages`);
              await addDoc(messagesCollection, {
                id: data.message_sid,
                body: text,
                sender: "business",
                timestamp: serverTimestamp(),
                status: "sent",
                phone: formattedTo,
                createdAt: serverTimestamp()
              });
            } catch (firebaseError) {
              console.error("Error saving to Firestore:", firebaseError);
            }
          }
        }
      } else {
        // Update the message as failed
        const messages = [...get().messages[formattedTo] || []];
        const msgIndex = messages.findIndex(m => m.id === tempId);
        
        if (msgIndex !== -1) {
          messages[msgIndex] = {
            ...messages[msgIndex],
            status: "failed",
            error: data.error || "Failed to send message"
          };
          
          set({
            messages: {
              ...get().messages,
              [formattedTo]: messages
            }
          });
        }
        
        toast.error("Error al enviar mensaje de WhatsApp: " + (data.error || "Error desconocido"));
      }
    } catch (error) {
      set({ error: String(error) });
      toast.error("Error sending WhatsApp message");
    } finally {
      set({ isLoading: false });
    }
  },
  
  // Send a template message to a WhatsApp number
  sendTemplateMessage: async (to: string, template: WhatsAppTemplate) => {
    const formattedTo = formatPhone(to);
    set({ isLoading: true, error: null });
    
    try {
      // First check if WhatsApp is configured
      const statusResponse = await brain.check_whatsapp_status();
      const statusData = await statusResponse.json();
      
      if (statusData.status !== "operational") {
        throw new Error("WhatsApp no está configurado correctamente. Por favor, configura tus credenciales de Twilio.");
      }
      
      // Create a temporary message ID
      const tempId = `temp-${Date.now()}`;
      
      // Add the message to the local state optimistically
      const message: WhatsAppMessage = {
        id: tempId,
        body: `Plantilla: ${template.name}`,
        sender: "business",
        timestamp: new Date(),
        status: "sent",
        phone: formattedTo
      };
      
      get().addMessage(message);
      
      // Send the message via the API
      const request: WhatsAppMessageRequest = {
        to_number: formattedTo,
        template: template
      };
      
      const response = await brain.send_whatsapp_message(request);
      const data = await response.json();
      
      if (data.success) {
        // Update the message with the new ID
        const messages = [...get().messages[formattedTo] || []];
        const msgIndex = messages.findIndex(m => m.id === tempId);
        
        if (msgIndex !== -1) {
          messages[msgIndex] = {
            ...messages[msgIndex],
            id: data.message_sid as string,
            status: "sent"
          };
          
          set({
            messages: {
              ...get().messages,
              [formattedTo]: messages
            }
          });
          
          // Store in Firestore
          const { user } = get();
          if (user) {
            try {
              const messagesCollection = collection(db, `users/${user.uid}/whatsapp_messages`);
              await addDoc(messagesCollection, {
                id: data.message_sid,
                body: `Plantilla: ${template.name}`,
                sender: "business",
                timestamp: serverTimestamp(),
                status: "sent",
                phone: formattedTo,
                template: template,
                createdAt: serverTimestamp()
              });
            } catch (firebaseError) {
              console.error("Error saving to Firestore:", firebaseError);
            }
          }
        }
      } else {
        // Update the message as failed
        const messages = [...get().messages[formattedTo] || []];
        const msgIndex = messages.findIndex(m => m.id === tempId);
        
        if (msgIndex !== -1) {
          messages[msgIndex] = {
            ...messages[msgIndex],
            status: "failed",
            error: data.error || "Failed to send message"
          };
          
          set({
            messages: {
              ...get().messages,
              [formattedTo]: messages
            }
          });
        }
        
        toast.error("Error al enviar plantilla de WhatsApp: " + (data.error || "Error desconocido"));
      }
    } catch (error) {
      set({ error: String(error) });
      toast.error("Error sending WhatsApp template");
    } finally {
      set({ isLoading: false });
    }
  },
  
  // Add a message to the store
  addMessage: (message: WhatsAppMessage) => {
    const { phone } = message;
    const currentMessages = get().messages[phone] || [];
    
    set({
      messages: {
        ...get().messages,
        [phone]: [...currentMessages, message]
      }
    });
    
    // If this is the first message for this number, set it as active
    if (!get().activePhone) {
      set({ activePhone: phone });
    }
  },
  
  // Fetch existing conversations from Firestore
  fetchConversations: async () => {
    const { user } = get();
    if (!user) return;
    
    set({ isLoading: true, error: null });
    
    try {
      // Get messages from Firestore
      const messagesCollection = collection(db, `users/${user.uid}/whatsapp_messages`);
      const q = query(messagesCollection, orderBy("timestamp", "asc"));
      
      // Set up realtime listener
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const messages: Record<string, WhatsAppMessage[]> = {};
        
        snapshot.forEach(doc => {
          const messageData = doc.data();
          const phone = messageData.phone;
          
          if (!messages[phone]) {
            messages[phone] = [];
          }
          
          messages[phone].push({
            id: messageData.id || doc.id,
            body: messageData.body,
            sender: messageData.sender,
            timestamp: messageData.timestamp?.toDate() || new Date(),
            status: messageData.status,
            phone: messageData.phone,
            error: messageData.error
          });
        });
        
        // Sort messages by timestamp
        Object.keys(messages).forEach(phone => {
          messages[phone].sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
        });
        
        set({ messages, isLoading: false });
        
        // Set first conversation as active if none is selected
        if (!get().activePhone && Object.keys(messages).length > 0) {
          set({ activePhone: Object.keys(messages)[0] });
        }
      });
      
      // Store unsubscribe function for cleanup
      return () => unsubscribe();
    } catch (error) {
      set({ error: String(error), isLoading: false });
      console.error("Error fetching WhatsApp conversations:", error);
    }
  },
  
  // Clear any errors
  clearError: () => set({ error: null }),
  
  // Initialize current user
  user: null,
  
  // Set current user
  setUser: (user: User | null) => set({ user })
}));

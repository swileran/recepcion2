import { create } from "zustand";
import { firebaseApp } from "app";
import { getFirestore, doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { toast } from "sonner";

// Initialize Firestore
const db = getFirestore(firebaseApp);

export interface UserProfile {
  id?: string;
  userId: string;
  businessName: string;
  businessType?: string;
  businessDescription?: string;
  phone?: string;
  email?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  country?: string;
  industry?: string;
  stripeCustomerId?: string;
  subscription?: {
    status?: string;
    plan?: string;
    currentPeriodEnd?: number;
  };
  voiceAgent?: {
    voice?: string;  // Internal voice ID (antonio, elena, etc)
    voice_id?: string;  // ElevenLabs voice ID
    greetingMessage?: string;
    farewellMessage?: string;
    confirmationMessage?: string;
    faqs?: Array<{
      question: string;
      answer: string;
    }>;
  };
  createdAt?: number;
  updatedAt: number;
}

interface ProfileState {
  profile: UserProfile | null;
  isLoading: boolean;
  error: Error | null;
  
  fetchProfile: (userId: string) => Promise<UserProfile | null>;
  updateProfile: (userId: string, data: Partial<UserProfile>) => Promise<void>;
  updateSubscriptionDetails: (userId: string, subscriptionData: any) => Promise<void>;
  updateStripeCustomerId: (userId: string, customerId: string) => Promise<void>;
}

export const useProfileStore = create<ProfileState>((set, get) => ({
  profile: null,
  isLoading: false,
  error: null,
  
  fetchProfile: async (userId: string) => {
    set({ isLoading: true, error: null });
    try {
      const profileRef = doc(db, "profiles", userId);
      const profileDoc = await getDoc(profileRef);
      
      if (profileDoc.exists()) {
        const profileData = profileDoc.data() as UserProfile;
        set({ profile: profileData, isLoading: false });
        return profileData;
      } else {
        set({ profile: null, isLoading: false });
        return null;
      }
    } catch (error) {
      console.error("Error fetching profile:", error);
      set({ error: error as Error, isLoading: false });
      return null;
    }
  },
  
  updateProfile: async (userId: string, data: Partial<UserProfile>) => {
    set({ isLoading: true, error: null });
    try {
      if (!userId) {
        throw new Error("UserId is required");
      }
      
      console.log("Profile update - Starting, userId:", userId);
      
      // Create a simplified update object with only necessary fields
      const updateData: Record<string, any> = {
        businessName: data.businessName || "Mi Negocio",
        updatedAt: Date.now()
      };
      
      // Always store the userId in the profile
      updateData.userId = userId;
      
      // Add optional fields one by one to avoid complex objects which can cause Firestore errors
      if (data.industry) updateData.industry = data.industry;
      if (data.businessDescription) updateData.businessDescription = data.businessDescription;
      if (data.phone) updateData.phone = data.phone;
      if (data.email) updateData.email = data.email;
      if (data.address) updateData.address = data.address;
      if (data.city) updateData.city = data.city;
      if (data.postalCode) updateData.postalCode = data.postalCode;
      if (data.country) updateData.country = data.country;
      
      console.log("Profile update - Data to save:", JSON.stringify(updateData));
      
      // Create local profile for state update
      const currentProfile = get().profile || {};
      const localProfile = {
        ...currentProfile,
        ...updateData,
        id: userId
      };
      
      // Update local state immediately (optimistic update)
      set({ profile: localProfile as UserProfile });
      
      // Try updating or creating in Firestore
      try {
        const profileRef = doc(db, "profiles", userId);
        const profileDoc = await getDoc(profileRef);
        
        if (profileDoc.exists()) {
          // For existing profiles, just update the fields we've changed
          await updateDoc(profileRef, updateData);
          console.log("Profile updated successfully");
        } else {
          // For new profiles, add creation timestamp
          updateData.createdAt = Date.now();
          await setDoc(profileRef, updateData);
          console.log("New profile created successfully");
        }
        
        // Set final state
        set({ isLoading: false, error: null });
        
      } catch (firestoreError) {
        console.error("Firestore update error:", firestoreError);
        // Don't throw the error so the UI can continue - we keep the optimistic update
        toast.error("No se pudo guardar en la base de datos, pero los cambios se mantienen localmente");
        set({ error: firestoreError as Error, isLoading: false });
      }
      
      // Always return the local profile regardless of Firestore success
      // This ensures the UI always has the most recent data even if saving to Firestore fails
      return localProfile as UserProfile;
    } catch (error) {
      console.error("Error in profile update:", error);
      set({ error: error as Error, isLoading: false });
      // Don't throw - return current profile instead
      return get().profile;
    }
  },
  
  updateSubscriptionDetails: async (userId: string, subscriptionData: any) => {
    set({ isLoading: true, error: null });
    try {
      const profileRef = doc(db, "profiles", userId);
      const profileDoc = await getDoc(profileRef);
      
      if (!profileDoc.exists()) {
        throw new Error("Profile not found");
      }
      
      const subscription = {
        status: subscriptionData.status,
        plan: subscriptionData.items?.data[0]?.price?.product?.name || "Plan Personalizado",
        currentPeriodEnd: subscriptionData.current_period_end
      };
      
      await updateDoc(profileRef, {
        subscription,
        updatedAt: Date.now()
      });
      
      // Update local state
      const currentProfile = get().profile;
      if (currentProfile) {
        set({
          profile: {
            ...currentProfile,
            subscription
          },
          isLoading: false
        });
      } else {
        // Refresh the profile
        await get().fetchProfile(userId);
        set({ isLoading: false });
      }
    } catch (error) {
      console.error("Error updating subscription details:", error);
      set({ error: error as Error, isLoading: false });
    }
  },
  
  updateStripeCustomerId: async (userId: string, customerId: string) => {
    set({ isLoading: true, error: null });
    try {
      const profileRef = doc(db, "profiles", userId);
      const profileDoc = await getDoc(profileRef);
      
      if (profileDoc.exists()) {
        await updateDoc(profileRef, {
          stripeCustomerId: customerId,
          updatedAt: Date.now()
        });
      } else {
        await setDoc(profileRef, {
          userId,
          stripeCustomerId: customerId,
          createdAt: Date.now(),
          updatedAt: Date.now()
        });
      }
      
      // Update local state
      const currentProfile = get().profile;
      if (currentProfile) {
        set({
          profile: {
            ...currentProfile,
            stripeCustomerId: customerId
          },
          isLoading: false
        });
      } else {
        // Refresh the profile
        await get().fetchProfile(userId);
        set({ isLoading: false });
      }
    } catch (error) {
      console.error("Error updating stripe customer ID:", error);
      set({ error: error as Error, isLoading: false });
      throw error;
    }
  }
}));

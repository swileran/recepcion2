import { create } from "zustand";
import brain from "brain";

// Subscription API Types
export interface PriceOption {
  id: string;
  name: string;
  price_id: string;
  price: number;
  interval: string;
  currency: string;
  features: string[];
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  prices: PriceOption[];
}

interface CheckoutSessionRequestParams {
  price_id: string;
  business_id: string;
  business_name?: string;
  customer_email?: string;
  success_url: string;
  cancel_url: string;
}

interface PortalSessionRequestParams {
  customer_id: string;
  return_url: string;
}

interface SubscriptionStore {
  plans: SubscriptionPlan[];
  isLoading: boolean;
  error: Error | null;
  fetchPlans: () => Promise<void>;
  createCheckoutSession: (params: CheckoutSessionRequestParams) => Promise<{ url: string }>;
  createPortalSession: (params: PortalSessionRequestParams) => Promise<{ url: string }>;
  getCustomerSubscription: (customerId: string) => Promise<any>;
}

export const useSubscriptionStore = create<SubscriptionStore>((set) => ({
  plans: [],
  isLoading: false,
  error: null,
  
  fetchPlans: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await brain.list_subscription_plans();
      const plans = await response.json();
      set({ plans, isLoading: false });
    } catch (error) {
      console.error("Error fetching subscription plans:", error);
      set({ error: error as Error, isLoading: false });
    }
  },
  
  createCheckoutSession: async (params) => {
    try {
      const response = await brain.create_checkout_session(params);
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Error creating checkout session:", error);
      throw error;
    }
  },
  
  createPortalSession: async (params) => {
    try {
      const response = await brain.create_portal_session(params);
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Error creating portal session:", error);
      throw error;
    }
  },
  
  getCustomerSubscription: async (customerId) => {
    try {
      const response = await brain.get_customer_subscription({ customer_id: customerId });
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Error getting customer subscription:", error);
      throw error;
    }
  }
}));

import { create } from "zustand";
import { firebaseApp } from "app";
import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  doc, 
  updateDoc, 
  deleteDoc,
  getFirestore,
  orderBy,
  Timestamp,
  onSnapshot
} from "firebase/firestore";
import { useProfileStore } from "./store";

// Initialize Firestore
const db = getFirestore(firebaseApp);

export interface Appointment {
  id?: string;
  businessId: string; // The profile ID of the business
  clientName: string;
  clientPhone: string;
  clientEmail?: string;
  serviceId?: string; // ID or index of the service from the business profile
  serviceName: string;
  date: Date;
  startTime: string; // Format: "HH:MM"
  endTime: string; // Format: "HH:MM"
  duration: number; // Duration in minutes
  status: "scheduled" | "confirmed" | "completed" | "cancelled" | "noShow";
  notes?: string;
  googleEventId?: string; // ID of the event in Google Calendar if integrated
  createdAt: Date;
  updatedAt: Date;
}

interface AppointmentState {
  appointments: Appointment[];
  isLoading: boolean;
  error: Error | null;
  unsubscribe: (() => void) | null;
  
  // Actions
  createAppointment: (data: Omit<Appointment, 'createdAt' | 'updatedAt'>) => Promise<string>;
  updateAppointment: (id: string, data: Partial<Appointment>) => Promise<void>;
  deleteAppointment: (id: string) => Promise<void>;
  fetchAppointments: (businessId: string, startDate?: Date, endDate?: Date) => Promise<void>;
  subscribeToAppointments: (businessId: string, startDate?: Date, endDate?: Date) => void;
  unsubscribeFromAppointments: () => void;
  getAppointmentById: (id: string) => Appointment | undefined;
  getAppointmentsByDate: (date: Date) => Appointment[];
  getUpcomingAppointments: (days: number) => Appointment[];
}

export const useAppointmentStore = create<AppointmentState>((set, get) => ({
  appointments: [],
  isLoading: false,
  error: null,
  unsubscribe: null,
  
  createAppointment: async (data) => {
    try {
      set({ isLoading: true, error: null });
      
      // First update local state to provide immediate feedback
      const appointmentData: Appointment = {
        ...data,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // Store dates as Firestore Timestamps
      const firestoreData = {
        ...appointmentData,
        date: Timestamp.fromDate(appointmentData.date),
        createdAt: Timestamp.fromDate(appointmentData.createdAt),
        updatedAt: Timestamp.fromDate(appointmentData.updatedAt)
      };
      
      const docRef = await addDoc(collection(db, "appointments"), firestoreData);
      const appointmentId = docRef.id;
      
      // Sync with Google Calendar if enabled
      const profile = useProfileStore.getState().profile;
      if (profile?.calendarSettings?.googleCalendarIntegrated && 
          profile.calendarSettings.googleCalendarId) {
        try {
          // Create Google Calendar event
          const startDateTime = new Date(appointmentData.date);
          const [startHours, startMinutes] = appointmentData.startTime.split(':').map(Number);
          startDateTime.setHours(startHours, startMinutes, 0, 0);
          
          const endDateTime = new Date(appointmentData.date);
          const [endHours, endMinutes] = appointmentData.endTime.split(':').map(Number);
          endDateTime.setHours(endHours, endMinutes, 0, 0);
          
          const eventData = {
            calendar_id: profile.calendarSettings.googleCalendarId,
            summary: `Cita: ${appointmentData.serviceName} - ${appointmentData.clientName}`,
            description: `Cliente: ${appointmentData.clientName}\nTeléfono: ${appointmentData.clientPhone}${appointmentData.clientEmail ? '\nEmail: ' + appointmentData.clientEmail : ''}${appointmentData.notes ? '\n\nNotas: ' + appointmentData.notes : ''}`,
            start_datetime: startDateTime.toISOString(),
            end_datetime: endDateTime.toISOString(),
            attendees: appointmentData.clientEmail ? [{ email: appointmentData.clientEmail }] : undefined,
            reminders: {
              useDefault: true
            }
          };
          
          const response = await fetch('/api/google-calendar/events', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(eventData),
            credentials: 'include'
          });
          
          if (response.ok) {
            const result = await response.json();
            
            // Update the appointment with Google Calendar event ID
            await updateDoc(doc(db, "appointments", appointmentId), {
              googleEventId: result.event_id
            });
            
            // Update local state with Google Calendar event ID
            appointmentData.googleEventId = result.event_id;
          } else {
            console.error('Failed to create Google Calendar event:', await response.text());
          }
        } catch (googleError) {
          console.error('Error creating Google Calendar event:', googleError);
          // Continue even if Google Calendar sync fails
        }
      }
      
      // Add the appointment to the local state with the new ID
      set(state => ({
        appointments: [...state.appointments, { ...appointmentData, id: appointmentId }],
        isLoading: false
      }));
      
      return appointmentId;
    } catch (error) {
      console.error('Error creating appointment:', error);
      set({ error: error as Error, isLoading: false });
      throw error;
    }
  },
  
  updateAppointment: async (id, data) => {
    try {
      set({ isLoading: true, error: null });
      
      // Fetch current appointment data to get Google Calendar event ID
      const currentAppointment = get().getAppointmentById(id);
      if (!currentAppointment) {
        throw new Error('Appointment not found');
      }
      
      // First update local state to provide immediate feedback
      set(state => ({
        appointments: state.appointments.map(apt => 
          apt.id === id ? { ...apt, ...data, updatedAt: new Date() } : apt
        ),
        isLoading: true
      }));
      
      const appointmentRef = doc(db, "appointments", id);
      
      // Prepare data for Firestore
      const updateData = { ...data, updatedAt: new Date() };
      
      // Convert Date objects to Firestore Timestamps
      if (updateData.date instanceof Date) {
        updateData.date = Timestamp.fromDate(updateData.date);
      }
      if (updateData.updatedAt instanceof Date) {
        updateData.updatedAt = Timestamp.fromDate(updateData.updatedAt);
      }
      
      await updateDoc(appointmentRef, updateData);
      
      // Sync with Google Calendar if enabled
      const profile = useProfileStore.getState().profile;
      if (profile?.calendarSettings?.googleCalendarIntegrated && 
          profile.calendarSettings.googleCalendarId && 
          currentAppointment.googleEventId) {
        
        try {
          // First delete the existing event
          await fetch('/api/google-calendar/events', {
            method: 'DELETE',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              calendar_id: profile.calendarSettings.googleCalendarId,
              event_id: currentAppointment.googleEventId
            }),
            credentials: 'include'
          });
          
          // Then create a new event with updated information
          const updatedAppointment = { ...currentAppointment, ...data };
          
          const startDateTime = new Date(updatedAppointment.date);
          const [startHours, startMinutes] = updatedAppointment.startTime.split(':').map(Number);
          startDateTime.setHours(startHours, startMinutes, 0, 0);
          
          const endDateTime = new Date(updatedAppointment.date);
          const [endHours, endMinutes] = updatedAppointment.endTime.split(':').map(Number);
          endDateTime.setHours(endHours, endMinutes, 0, 0);
          
          const eventData = {
            calendar_id: profile.calendarSettings.googleCalendarId,
            summary: `Cita: ${updatedAppointment.serviceName} - ${updatedAppointment.clientName}`,
            description: `Cliente: ${updatedAppointment.clientName}\nTeléfono: ${updatedAppointment.clientPhone}${updatedAppointment.clientEmail ? '\nEmail: ' + updatedAppointment.clientEmail : ''}${updatedAppointment.notes ? '\n\nNotas: ' + updatedAppointment.notes : ''}`,
            start_datetime: startDateTime.toISOString(),
            end_datetime: endDateTime.toISOString(),
            attendees: updatedAppointment.clientEmail ? [{ email: updatedAppointment.clientEmail }] : undefined,
            reminders: {
              useDefault: true
            }
          };
          
          const response = await fetch('/api/google-calendar/events', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(eventData),
            credentials: 'include'
          });
          
          if (response.ok) {
            const result = await response.json();
            
            // Update the appointment with the new Google Calendar event ID
            await updateDoc(doc(db, "appointments", id), {
              googleEventId: result.event_id
            });
          } else {
            console.error('Failed to update Google Calendar event:', await response.text());
          }
        } catch (googleError) {
          console.error('Error updating Google Calendar event:', googleError);
          // Continue even if Google Calendar sync fails
        }
      }
      
      set({ isLoading: false });
    } catch (error) {
      console.error('Error updating appointment:', error);
      set({ error: error as Error, isLoading: false });
      throw error;
    }
  },
  
  deleteAppointment: async (id) => {
    try {
      set({ isLoading: true, error: null });
      
      // Fetch appointment before deletion to get Google Calendar event ID
      const appointment = get().getAppointmentById(id);
      
      // First update local state to provide immediate feedback
      set(state => ({
        appointments: state.appointments.filter(apt => apt.id !== id),
        isLoading: true
      }));
      
      const appointmentRef = doc(db, "appointments", id);
      await deleteDoc(appointmentRef);
      
      // Delete from Google Calendar if integrated
      if (appointment?.googleEventId) {
        const profile = useProfileStore.getState().profile;
        if (profile?.calendarSettings?.googleCalendarIntegrated && 
            profile.calendarSettings.googleCalendarId) {
          try {
            await fetch('/api/google-calendar/events', {
              method: 'DELETE',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                calendar_id: profile.calendarSettings.googleCalendarId,
                event_id: appointment.googleEventId
              }),
              credentials: 'include'
            });
          } catch (googleError) {
            console.error('Error deleting Google Calendar event:', googleError);
            // Continue even if Google Calendar deletion fails
          }
        }
      }
      
      set({ isLoading: false });
    } catch (error) {
      console.error('Error deleting appointment:', error);
      set({ error: error as Error, isLoading: false });
      throw error;
    }
  },
  
  fetchAppointments: async (businessId, startDate, endDate) => {
    try {
      set({ isLoading: true, error: null });
      
      const appointmentsRef = collection(db, "appointments");
      let q = query(
        appointmentsRef, 
        where("businessId", "==", businessId),
        orderBy("date", "asc"),
        orderBy("startTime", "asc")
      );
      
      // Add date filters if provided
      if (startDate) {
        q = query(q, where("date", ">=", Timestamp.fromDate(startDate)));
      }
      
      if (endDate) {
        q = query(q, where("date", "<=", Timestamp.fromDate(endDate)));
      }
      
      const querySnapshot = await getDocs(q);
      
      const appointments: Appointment[] = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        
        // Convert Firestore Timestamps to JavaScript Dates
        appointments.push({
          ...data,
          id: doc.id,
          date: data.date.toDate(),
          createdAt: data.createdAt.toDate(),
          updatedAt: data.updatedAt.toDate()
        } as Appointment);
      });
      
      set({ 
        appointments,
        isLoading: false 
      });
    } catch (error) {
      console.error('Error fetching appointments:', error);
      set({ error: error as Error, isLoading: false });
    }
  },
  
  subscribeToAppointments: (businessId, startDate, endDate) => {
    // Unsubscribe from any existing subscription
    get().unsubscribeFromAppointments();
    
    set({ isLoading: true, error: null });
    
    const appointmentsRef = collection(db, "appointments");
    let q = query(
      appointmentsRef, 
      where("businessId", "==", businessId),
      orderBy("date", "asc"),
      orderBy("startTime", "asc")
    );
    
    // Add date filters if provided
    if (startDate) {
      q = query(q, where("date", ">=", Timestamp.fromDate(startDate)));
    }
    
    if (endDate) {
      q = query(q, where("date", "<=", Timestamp.fromDate(endDate)));
    }
    
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const appointments: Appointment[] = [];
      
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        
        // Convert Firestore Timestamps to JavaScript Dates
        appointments.push({
          ...data,
          id: doc.id,
          date: data.date.toDate(),
          createdAt: data.createdAt.toDate(),
          updatedAt: data.updatedAt.toDate()
        } as Appointment);
      });
      
      set({ 
        appointments,
        isLoading: false 
      });
    }, (error) => {
      console.error('Error in appointments subscription:', error);
      set({ error: error as Error, isLoading: false });
    });
    
    set({ unsubscribe });
  },
  
  unsubscribeFromAppointments: () => {
    const { unsubscribe } = get();
    if (unsubscribe) {
      unsubscribe();
      set({ unsubscribe: null });
    }
  },
  
  getAppointmentById: (id) => {
    return get().appointments.find(apt => apt.id === id);
  },
  
  getAppointmentsByDate: (date) => {
    const targetDate = new Date(date);
    targetDate.setHours(0, 0, 0, 0);
    
    return get().appointments.filter(apt => {
      const aptDate = new Date(apt.date);
      aptDate.setHours(0, 0, 0, 0);
      return aptDate.getTime() === targetDate.getTime();
    });
  },
  
  getUpcomingAppointments: (days) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const endDate = new Date(today);
    endDate.setDate(today.getDate() + days);
    
    return get().appointments.filter(apt => {
      const aptDate = new Date(apt.date);
      aptDate.setHours(0, 0, 0, 0);
      return aptDate >= today && aptDate <= endDate;
    });
  }
}));

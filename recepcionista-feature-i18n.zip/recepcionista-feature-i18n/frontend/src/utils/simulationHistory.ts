import { useState, useEffect } from 'react';

interface SimulationResult {
  id: string;
  scenarioId: string;
  scenarioName: string;
  date: string;
  successful: boolean;
  conversationSummary: string;
  appointmentStatus?: string;
  appointmentService?: string;
  appointmentMultiplePeople?: boolean;
  faqMatched?: boolean;
  faqTopic?: string;
  customerComplaint?: boolean;
  complaintSeverity?: string;
  performanceMetrics?: Record<string, number>;
  improvementSuggestions?: Array<{category: string; suggestion: string; priority: string}>;
}

export interface SimulationStats {
  totalSimulations: number;
  successfulSimulations: number;
  appointmentsBooked: number;
  faqsAnswered: number;
  complaintsHandled: number;
  lastSimulationDate: string | null;
  averagePerformance?: number;
  performanceHistory?: Array<{date: string; value: number}>;
  scenarioBreakdown?: Array<{name: string; count: number}>;
  servicesRequested?: Array<{service: string; count: number}>;
}

// Helper functions to work with localStorage for simulation history
const STORAGE_KEY = 'recepcionista_simulation_history';

// Save a new simulation result
export const saveSimulationResult = (result: Omit<SimulationResult, 'id'>) => {
  try {
    const existingHistory = getSimulationHistory();
    const newResult: SimulationResult = {
      ...result,
      id: `sim_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    };
    
    const updatedHistory = [newResult, ...existingHistory].slice(0, 50); // Keep last 50 simulations
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedHistory));
    return newResult;
  } catch (error) {
    console.error('Error saving simulation result:', error);
    return null;
  }
};

// Get all simulation history
export const getSimulationHistory = (): SimulationResult[] => {
  try {
    const historyString = localStorage.getItem(STORAGE_KEY);
    return historyString ? JSON.parse(historyString) : [];
  } catch (error) {
    console.error('Error retrieving simulation history:', error);
    return [];
  }
};

// Calculate statistics from simulation history
export const calculateSimulationStats = (): SimulationStats => {
  const history = getSimulationHistory();
  
  if (history.length === 0) {
    return {
      totalSimulations: 0,
      successfulSimulations: 0,
      appointmentsBooked: 0,
      faqsAnswered: 0,
      complaintsHandled: 0,
      lastSimulationDate: null,
      averagePerformance: 0,
      performanceHistory: [],
      scenarioBreakdown: [],
      servicesRequested: []
    };
  }
  
  const stats: SimulationStats = {
    totalSimulations: history.length,
    successfulSimulations: history.filter(result => result.successful).length,
    appointmentsBooked: history.filter(result => result.appointmentStatus === 'confirmed').length,
    faqsAnswered: history.filter(result => result.faqMatched).length,
    complaintsHandled: history.filter(result => result.customerComplaint).length,
    lastSimulationDate: history[0]?.date || null
  };
  
  // Calculate scenario breakdown
  const scenarioCounts: Record<string, number> = {};
  history.forEach(result => {
    if (!scenarioCounts[result.scenarioName]) {
      scenarioCounts[result.scenarioName] = 0;
    }
    scenarioCounts[result.scenarioName]++;
  });
  
  stats.scenarioBreakdown = Object.entries(scenarioCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5); // Top 5 scenarios
  
  // Calculate services requested
  const serviceCounts: Record<string, number> = {};
  history.forEach(result => {
    if (result.appointmentService) {
      if (!serviceCounts[result.appointmentService]) {
        serviceCounts[result.appointmentService] = 0;
      }
      serviceCounts[result.appointmentService]++;
    }
  });
  
  stats.servicesRequested = Object.entries(serviceCounts)
    .map(([service, count]) => ({ service, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5); // Top 5 services
  
  // Calculate average performance if metrics are available
  const simulationsWithMetrics = history.filter(result => result.performanceMetrics?.overall !== undefined);
  if (simulationsWithMetrics.length > 0) {
    const totalPerformance = simulationsWithMetrics.reduce(
      (sum, result) => sum + (result.performanceMetrics?.overall || 0), 
      0
    );
    stats.averagePerformance = totalPerformance / simulationsWithMetrics.length;
    
    // Create performance history for charts (last 10 simulations)
    stats.performanceHistory = simulationsWithMetrics
      .slice(0, 10)
      .reverse()
      .map(result => ({
        date: new Date(result.date).toLocaleDateString(),
        value: result.performanceMetrics?.overall || 0
      }));
  }
  
  return stats;
};

// Clear all simulation history
export const clearSimulationHistory = (): void => {
  localStorage.removeItem(STORAGE_KEY);
};

// React hook to get and update simulation stats
export const useSimulationStats = () => {
  const [stats, setStats] = useState<SimulationStats>(calculateSimulationStats());
  
  const refreshStats = () => {
    setStats(calculateSimulationStats());
  };
  
  // Initial load and setup window storage event listener
  useEffect(() => {
    // Handle storage events (in case stats are updated in another tab)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) {
        refreshStats();
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);
  
  return { stats, refreshStats };
};

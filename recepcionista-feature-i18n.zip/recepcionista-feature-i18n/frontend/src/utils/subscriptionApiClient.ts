import { auth } from "app/auth";
import { API_URL } from "app";

// Subscription API Types
export interface PriceOption {
  id: string;
  name: string;
  price_id: string;
  price: number;
  interval: string;
  currency: string;
  features: string[];
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  prices: PriceOption[];
}

export interface CreateCheckoutSessionRequest {
  price_id: string;
  business_id: string;
  business_name: string;
  customer_email: string;
  success_url: string;
  cancel_url: string;
}

export interface CheckoutSessionResponse {
  session_id: string;
  url: string;
}

export interface CreatePortalSessionRequest {
  customer_id: string;
  return_url: string;
}

export interface CustomerPortalResponse {
  url: string;
}

export interface SubscriptionInfo {
  subscription_id: string;
  status: string;
  current_period_end: number;
  cancel_at_period_end: boolean;
  plan_id: string;
  price_id: string;
  amount: number;
  currency: string;
  interval: string;
}

export interface CustomerSubscriptionResponse {
  customer_id: string;
  subscriptions: SubscriptionInfo[];
  has_active_subscription: boolean;
}

// Helper function to get auth header
const getAuthHeader = async () => {
  return {
    Authorization: await auth.getAuthHeaderValue(),
  };
};

// API client for subscription endpoints
const subscriptionApi = {
  // Get subscription plans
  getSubscriptionPlans: async (): Promise<SubscriptionPlan[]> => {
    const response = await fetch(`${API_URL}/routes/subscription/plans`, {
      method: "GET",
      headers: {
        ...await getAuthHeader(),
      },
      credentials: "include",
    });
    
    if (!response.ok) {
      throw new Error(`Error fetching subscription plans: ${response.statusText}`);
    }
    
    return response.json();
  },
  
  // Get customer subscription
  getCustomerSubscription: async (customerId: string): Promise<CustomerSubscriptionResponse> => {
    const response = await fetch(`${API_URL}/routes/subscription/customer/${customerId}`, {
      method: "GET",
      headers: {
        ...await getAuthHeader(),
      },
      credentials: "include",
    });
    
    if (!response.ok) {
      throw new Error(`Error fetching customer subscription: ${response.statusText}`);
    }
    
    return response.json();
  },
  
  // Create checkout session
  createCheckoutSession: async (data: CreateCheckoutSessionRequest): Promise<CheckoutSessionResponse> => {
    const response = await fetch(`${API_URL}/routes/subscription/checkout`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...await getAuthHeader(),
      },
      body: JSON.stringify(data),
      credentials: "include",
    });
    
    if (!response.ok) {
      throw new Error(`Error creating checkout session: ${response.statusText}`);
    }
    
    return response.json();
  },
  
  // Create customer portal session
  createPortalSession: async (data: CreatePortalSessionRequest): Promise<CustomerPortalResponse> => {
    const response = await fetch(`${API_URL}/routes/subscription/portal`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...await getAuthHeader(),
      },
      body: JSON.stringify(data),
      credentials: "include",
    });
    
    if (!response.ok) {
      throw new Error(`Error creating customer portal: ${response.statusText}`);
    }
    
    return response.json();
  },
};

export default subscriptionApi;

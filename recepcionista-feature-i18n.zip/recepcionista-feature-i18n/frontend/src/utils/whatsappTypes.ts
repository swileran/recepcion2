import { User } from "firebase/auth";

// Define WhatsApp specific types

// Message interface for WhatsApp communications
export interface WhatsAppMessage {
  id: string;
  body: string;
  sender: "user" | "business";
  timestamp: Date;
  status: "sent" | "delivered" | "read" | "failed";
  phone: string;
  error?: string;
}

// Contact information
export interface WhatsAppContact {
  phone: string;
  name?: string;
  lastMessage?: string;
  lastMessageTime?: Date;
  unreadCount: number;
}

// Status of WhatsApp connection
export interface WhatsAppStatus {
  status: "operational" | "error" | "pending" | "loading";
  message?: string;
  provider?: string;
  whatsappNumber?: string;
}

// Complete conversation with a contact
export interface WhatsAppConversation {
  contact: WhatsAppContact;
  messages: WhatsAppMessage[];
}

// Store interface for global WhatsApp state
export interface WhatsAppStore {
  // State
  messages: Record<string, WhatsAppMessage[]>;
  activePhone: string | null;
  isLoading: boolean;
  error: string | null;
  user: User | null;
  
  // Actions
  setActivePhone: (phone: string) => void;
  sendMessage: (to: string, text: string) => Promise<void>;
  sendTemplateMessage: (to: string, template: WhatsAppTemplate) => Promise<void>;
  addMessage: (message: WhatsAppMessage) => void;
  fetchConversations: () => Promise<() => void>;
  clearError: () => void;
  setUser: (user: User | null) => void;
}

// WhatsApp template structure for sending template messages
export interface WhatsAppTemplate {
  name: string;
  language_code?: string;
  parameters?: Record<string, string>[];
}

// Message request structure for API calls
export interface WhatsAppMessageRequest {
  to_number: string;
  message?: string;
  template?: WhatsAppTemplate | null;
}

// Message response from the API
export interface WhatsAppMessageResponse {
  success: boolean;
  message_sid?: string | null;
  error?: string | null;
}

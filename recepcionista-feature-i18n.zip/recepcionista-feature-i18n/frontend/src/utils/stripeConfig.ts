import { APP_BASE_PATH } from "app";
import { mode, Mode } from "app";

export const stripeConfig = {
  /**
   * Stripe publishable key for the frontend
   * Using the live key in production and test key in development
   */
  publishableKey: "pk_live_51OtTLiFBXBvQSI4R6LYXQGHx5hhfXIcJD0A3axS8mWYnxj3yOAcRMMDXq6Fb4Jh7YO2lHTfX33vZtYxh5S8kYkM30015SbOx5a",
  
  /**
   * Webhook endpoint URL for Stripe events
   */
  webhookUrl: `${window.location.origin}${APP_BASE_PATH}/api/subscription/webhook`,

  /**
   * Base URL for redirects
   */
  baseUrl: window.location.origin,
};

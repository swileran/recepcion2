import React from 'react'
import ReactDOM from 'react-dom/client'
import { AppWrapper } from './AppWrapper'
import './index.css'
import './i18n'
import { getStoredLanguage } from './utils/languagePersistence'

// Set the document language attribute based on stored preference
document.documentElement.lang = getStoredLanguage()

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <AppWrapper />
  </React.StrictMode>,
)

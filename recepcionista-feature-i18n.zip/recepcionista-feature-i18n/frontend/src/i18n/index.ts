import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import { en } from '../locales/en';
import { es } from '../locales/es';
import { getStoredLanguage, storeLanguage } from '../utils/languagePersistence';

// Get the stored language
const storedLanguage = getStoredLanguage();

// Initialize i18next
i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      en: {
        translation: en
      },
      es: {
        translation: es
      }
    },
    lng: storedLanguage, // Use the stored language
    fallbackLng: 'es',
    debug: process.env.NODE_ENV === 'development',
    interpolation: {
      escapeValue: false // React already escapes values
    },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage']
    },
    // Add these options to prevent suspense issues
    react: {
      useSuspense: false,
      bindI18n: 'languageChanged loaded',
      bindI18nStore: 'added removed',
      transEmptyNodeValue: ''
    }
  });

// Listen for language changes and store them
i18n.on('languageChanged', (lng) => {
  storeLanguage(lng);
});

export default i18n; 
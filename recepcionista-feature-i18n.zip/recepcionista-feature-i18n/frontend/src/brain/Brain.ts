import {
  CheckHealthData,
  CheckTwilioWhatsappStatusData,
  CheckWhatsappStatusData,
  ConvertSimulationToCallData,
  ConvertSimulationToCallError,
  CreateCheckoutSessionData,
  CreateCheckoutSessionError,
  CreateCheckoutSessionRequest,
  CreateEventData,
  CreateEventError,
  CreateEventRequest,
  CreatePortalSessionData,
  CreatePortalSessionError,
  CreatePortalSessionRequest,
  DeleteEventData,
  DeleteEventError,
  DeleteEventRequest,
  ExchangeTokenData,
  ExchangeTokenError,
  ExchangeTokenParams,
  GetAuthUrlData,
  GetAuthUrlError,
  GetAuthUrlParams,
  GetConnectionStatusData,
  GetConnectionStatusError,
  GetConnectionStatusParams,
  GetCustomerSubscriptionData,
  GetCustomerSubscriptionError,
  GetCustomerSubscriptionParams,
  GetSetupGuideData,
  GetSimulationScenariosData,
  GetVoiceOptionsData,
  GetVoiceSampleData,
  GetVoiceSampleError,
  GoogleTokenRequest,
  HandleWebhookData,
  HandleWebhookError,
  HandleWebhookParams,
  ListCalendarsData,
  ListCallsData,
  ListSubscriptionPlansData,
  MetaWhatsAppConfig,
  SaveMetaWhatsappConfigData,
  SaveMetaWhatsappConfigError,
  SaveTwilioConfigData,
  SaveTwilioConfigError,
  SendTwilioWhatsappMessageData,
  SendTwilioWhatsappMessageError,
  SendWhatsappMessageData,
  SendWhatsappMessageError,
  SimulateCallData,
  SimulateCallError,
  SimulationRequest,
  SimulationToCallRequest,
  TextToSpeechData,
  TextToSpeechError,
  TextToSpeechRequest,
  TwilioConfig,
  VerifyWebhookData,
  VerifyWebhookError,
  VoiceSampleRequest,
  WebhookHandlerData,
  WhatsAppMessage,
  WhatsAppMessageRequest,
  WhatsappStatusCallbackData,
  WhatsappStatusCallbackError,
  WhatsappWebhookData,
  WhatsappWebhookError,
} from "./data-contracts";
import { ContentType, HttpClient, RequestParams } from "./http-client";

export class Brain<SecurityDataType = unknown> extends HttpClient<SecurityDataType> {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   *
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  check_health = (params: RequestParams = {}) =>
    this.request<CheckHealthData, any>({
      path: `/_healthz`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get the Google OAuth authorization URL
   *
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name get_auth_url
   * @summary Get Auth Url
   * @request GET:/routes/google-calendar/auth-url
   */
  get_auth_url = (query: GetAuthUrlParams, params: RequestParams = {}) =>
    this.request<GetAuthUrlData, GetAuthUrlError>({
      path: `/routes/google-calendar/auth-url`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Exchange authorization code for access and refresh tokens
   *
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name exchange_token
   * @summary Exchange Token
   * @request POST:/routes/google-calendar/exchange-token
   */
  exchange_token = (query: ExchangeTokenParams, data: GoogleTokenRequest, params: RequestParams = {}) =>
    this.request<ExchangeTokenData, ExchangeTokenError>({
      path: `/routes/google-calendar/exchange-token`,
      method: "POST",
      query: query,
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List the user's Google Calendars
   *
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name list_calendars
   * @summary List Calendars
   * @request GET:/routes/google-calendar/calendars
   */
  list_calendars = (params: RequestParams = {}) =>
    this.request<ListCalendarsData, any>({
      path: `/routes/google-calendar/calendars`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new event in Google Calendar
   *
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name create_event
   * @summary Create Event
   * @request POST:/routes/google-calendar/events
   */
  create_event = (data: CreateEventRequest, params: RequestParams = {}) =>
    this.request<CreateEventData, CreateEventError>({
      path: `/routes/google-calendar/events`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an event from Google Calendar
   *
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name delete_event
   * @summary Delete Event
   * @request DELETE:/routes/google-calendar/events
   */
  delete_event = (data: DeleteEventRequest, params: RequestParams = {}) =>
    this.request<DeleteEventData, DeleteEventError>({
      path: `/routes/google-calendar/events`,
      method: "DELETE",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Check if the user has connected their Google Calendar
   *
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name get_connection_status
   * @summary Get Connection Status
   * @request GET:/routes/google-calendar/connection-status
   */
  get_connection_status = (query: GetConnectionStatusParams, params: RequestParams = {}) =>
    this.request<GetConnectionStatusData, GetConnectionStatusError>({
      path: `/routes/google-calendar/connection-status`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get available Spanish voices from ElevenLabs with regional metadata
   *
   * @tags dbtn/module:voice_synthesis, dbtn/hasAuth
   * @name get_voice_options
   * @summary Get Voice Options
   * @request GET:/routes/voice-synthesis/voices
   */
  get_voice_options = (params: RequestParams = {}) =>
    this.request<GetVoiceOptionsData, any>({
      path: `/routes/voice-synthesis/voices`,
      method: "GET",
      ...params,
    });

  /**
   * @description Convert text to speech using ElevenLabs API with caching
   *
   * @tags dbtn/module:voice_synthesis, dbtn/hasAuth
   * @name text_to_speech
   * @summary Text To Speech
   * @request POST:/routes/voice-synthesis/text-to-speech
   */
  text_to_speech = (data: TextToSpeechRequest, params: RequestParams = {}) =>
    this.request<TextToSpeechData, TextToSpeechError>({
      path: `/routes/voice-synthesis/text-to-speech`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a sample of a voice saying different types of standard phrases
   *
   * @tags dbtn/module:voice_synthesis, dbtn/hasAuth
   * @name get_voice_sample
   * @summary Get Voice Sample
   * @request POST:/routes/voice-synthesis/sample
   */
  get_voice_sample = (data: VoiceSampleRequest, params: RequestParams = {}) =>
    this.request<GetVoiceSampleData, GetVoiceSampleError>({
      path: `/routes/voice-synthesis/sample`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get available call simulation scenarios
   *
   * @tags dbtn/module:call_simulation, dbtn/hasAuth
   * @name get_simulation_scenarios
   * @summary Get Simulation Scenarios
   * @request GET:/routes/call-simulation/scenarios
   */
  get_simulation_scenarios = (params: RequestParams = {}) =>
    this.request<GetSimulationScenariosData, any>({
      path: `/routes/call-simulation/scenarios`,
      method: "GET",
      ...params,
    });

  /**
   * @description Simulate a call with the AI receptionist based on the user's input and context
   *
   * @tags dbtn/module:call_simulation, dbtn/hasAuth
   * @name simulate_call
   * @summary Simulate Call
   * @request POST:/routes/call-simulation/simulate
   */
  simulate_call = (data: SimulationRequest, params: RequestParams = {}) =>
    this.request<SimulateCallData, SimulateCallError>({
      path: `/routes/call-simulation/simulate`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Save Twilio configuration for WhatsApp integration.
   *
   * @tags settings, dbtn/module:settings, dbtn/hasAuth
   * @name save_twilio_config
   * @summary Save Twilio Config
   * @request POST:/routes/settings/twilio
   */
  save_twilio_config = (data: TwilioConfig, params: RequestParams = {}) =>
    this.request<SaveTwilioConfigData, SaveTwilioConfigError>({
      path: `/routes/settings/twilio`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get available subscription plans
   *
   * @tags dbtn/module:subscription, dbtn/hasAuth
   * @name list_subscription_plans
   * @summary List Subscription Plans
   * @request GET:/routes/subscription/plans
   */
  list_subscription_plans = (params: RequestParams = {}) =>
    this.request<ListSubscriptionPlansData, any>({
      path: `/routes/subscription/plans`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a Stripe checkout session for subscription
   *
   * @tags dbtn/module:subscription, dbtn/hasAuth
   * @name create_checkout_session
   * @summary Create Checkout Session
   * @request POST:/routes/subscription/checkout
   */
  create_checkout_session = (data: CreateCheckoutSessionRequest, params: RequestParams = {}) =>
    this.request<CreateCheckoutSessionData, CreateCheckoutSessionError>({
      path: `/routes/subscription/checkout`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Create a Stripe customer portal session
   *
   * @tags dbtn/module:subscription, dbtn/hasAuth
   * @name create_portal_session
   * @summary Create Portal Session
   * @request POST:/routes/subscription/portal
   */
  create_portal_session = (data: CreatePortalSessionRequest, params: RequestParams = {}) =>
    this.request<CreatePortalSessionData, CreatePortalSessionError>({
      path: `/routes/subscription/portal`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get subscription information for a customer
   *
   * @tags dbtn/module:subscription, dbtn/hasAuth
   * @name get_customer_subscription
   * @summary Get Customer Subscription
   * @request GET:/routes/subscription/customer/{customer_id}
   */
  get_customer_subscription = ({ customerId, ...query }: GetCustomerSubscriptionParams, params: RequestParams = {}) =>
    this.request<GetCustomerSubscriptionData, GetCustomerSubscriptionError>({
      path: `/routes/subscription/customer/${customerId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Handle Stripe webhooks
   *
   * @tags dbtn/module:subscription, dbtn/hasAuth
   * @name handle_webhook
   * @summary Handle Webhook
   * @request POST:/routes/subscription/webhook
   */
  handle_webhook = (query: HandleWebhookParams, params: RequestParams = {}) =>
    this.request<HandleWebhookData, HandleWebhookError>({
      path: `/routes/subscription/webhook`,
      method: "POST",
      query: query,
      ...params,
    });

  /**
   * @description Convert a simulation result to a call record and save it to Firestore
   *
   * @tags dbtn/module:call_analytics, dbtn/hasAuth
   * @name convert_simulation_to_call
   * @summary Convert Simulation To Call
   * @request POST:/routes/call-analytics/convert-simulation
   */
  convert_simulation_to_call = (data: SimulationToCallRequest, params: RequestParams = {}) =>
    this.request<ConvertSimulationToCallData, ConvertSimulationToCallError>({
      path: `/routes/call-analytics/convert-simulation`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all call records for a business
   *
   * @tags dbtn/module:call_analytics, dbtn/hasAuth
   * @name list_calls
   * @summary List Calls
   * @request GET:/routes/call-analytics/list
   */
  list_calls = (params: RequestParams = {}) =>
    this.request<ListCallsData, any>({
      path: `/routes/call-analytics/list`,
      method: "GET",
      ...params,
    });

  /**
   * @description Webhook for incoming WhatsApp messages.
   *
   * @tags whatsapp, dbtn/module:whatsapp, dbtn/hasAuth
   * @name whatsapp_webhook
   * @summary Whatsapp Webhook
   * @request POST:/routes/whatsapp/webhook
   */
  whatsapp_webhook = (params: RequestParams = {}) =>
    this.request<WhatsappWebhookData, WhatsappWebhookError>({
      path: `/routes/whatsapp/webhook`,
      method: "POST",
      ...params,
    });

  /**
   * @description Webhook for WhatsApp message status updates.
   *
   * @tags whatsapp, dbtn/module:whatsapp, dbtn/hasAuth
   * @name whatsapp_status_callback
   * @summary Whatsapp Status Callback
   * @request POST:/routes/whatsapp/status
   */
  whatsapp_status_callback = (params: RequestParams = {}) =>
    this.request<WhatsappStatusCallbackData, WhatsappStatusCallbackError>({
      path: `/routes/whatsapp/status`,
      method: "POST",
      ...params,
    });

  /**
   * @description Check the status of the WhatsApp integration.
   *
   * @tags whatsapp, dbtn/module:whatsapp, dbtn/hasAuth
   * @name check_twilio_whatsapp_status
   * @summary Check Twilio Whatsapp Status
   * @request GET:/routes/whatsapp/status
   */
  check_twilio_whatsapp_status = (params: RequestParams = {}) =>
    this.request<CheckTwilioWhatsappStatusData, any>({
      path: `/routes/whatsapp/status`,
      method: "GET",
      ...params,
    });

  /**
   * @description Send a WhatsApp message.
   *
   * @tags whatsapp, dbtn/module:whatsapp, dbtn/hasAuth
   * @name send_twilio_whatsapp_message
   * @summary Send Twilio Whatsapp Message
   * @request POST:/routes/whatsapp/send
   */
  send_twilio_whatsapp_message = (data: WhatsAppMessageRequest, params: RequestParams = {}) =>
    this.request<SendTwilioWhatsappMessageData, SendTwilioWhatsappMessageError>({
      path: `/routes/whatsapp/send`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * No description
   *
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name save_meta_whatsapp_config
   * @summary Save Meta Whatsapp Config
   * @request POST:/routes/meta-whatsapp/config
   */
  save_meta_whatsapp_config = (data: MetaWhatsAppConfig, params: RequestParams = {}) =>
    this.request<SaveMetaWhatsappConfigData, SaveMetaWhatsappConfigError>({
      path: `/routes/meta-whatsapp/config`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Send a WhatsApp message using Meta's WhatsApp Business Cloud API.
   *
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name send_whatsapp_message
   * @summary Send Whatsapp Message
   * @request POST:/routes/meta-whatsapp/send
   */
  send_whatsapp_message = (data: WhatsAppMessage, params: RequestParams = {}) =>
    this.request<SendWhatsappMessageData, SendWhatsappMessageError>({
      path: `/routes/meta-whatsapp/send`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Check the status of the Meta WhatsApp integration.
   *
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name check_whatsapp_status
   * @summary Check Whatsapp Status
   * @request GET:/routes/meta-whatsapp/status
   */
  check_whatsapp_status = (params: RequestParams = {}) =>
    this.request<CheckWhatsappStatusData, any>({
      path: `/routes/meta-whatsapp/status`,
      method: "GET",
      ...params,
    });

  /**
   * @description Verify the webhook subscription for Meta WhatsApp Cloud API.
   *
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name verify_webhook
   * @summary Verify Webhook
   * @request GET:/routes/meta-whatsapp/verify-webhook
   */
  verify_webhook = (params: RequestParams = {}) =>
    this.request<VerifyWebhookData, VerifyWebhookError>({
      path: `/routes/meta-whatsapp/verify-webhook`,
      method: "GET",
      ...params,
    });

  /**
   * @description Handle incoming webhook events from Meta WhatsApp Cloud API.
   *
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name webhook_handler
   * @summary Webhook Handler
   * @request POST:/routes/meta-whatsapp/webhook
   */
  webhook_handler = (params: RequestParams = {}) =>
    this.request<WebhookHandlerData, any>({
      path: `/routes/meta-whatsapp/webhook`,
      method: "POST",
      ...params,
    });

  /**
   * No description
   *
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name get_setup_guide
   * @summary Get Setup Guide
   * @request GET:/routes/meta-whatsapp/setup-guide
   */
  get_setup_guide = (params: RequestParams = {}) =>
    this.request<GetSetupGuideData, any>({
      path: `/routes/meta-whatsapp/setup-guide`,
      method: "GET",
      ...params,
    });
}

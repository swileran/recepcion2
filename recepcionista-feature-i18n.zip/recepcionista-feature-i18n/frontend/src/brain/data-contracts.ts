/** CalendarListResponse */
export interface CalendarListResponse {
  /** Calendars */
  calendars: Record<string, any>[];
}

/** CallListResponse */
export interface CallListResponse {
  /** Calls */
  calls: Record<string, any>[];
}

/**
 * CheckoutSessionResponse
 * Response model for checkout session creation
 */
export interface CheckoutSessionResponse {
  /** Session Id */
  session_id: string;
  /** Url */
  url: string;
}

/**
 * CreateCheckoutSessionRequest
 * Request model for creating a checkout session
 */
export interface CreateCheckoutSessionRequest {
  /** Price Id */
  price_id: string;
  /** Business Id */
  business_id: string;
  /** Business Name */
  business_name: string;
  /** Customer Email */
  customer_email: string;
  /** Success Url */
  success_url: string;
  /** Cancel Url */
  cancel_url: string;
}

/** CreateEventRequest */
export interface CreateEventRequest {
  /** Calendar Id */
  calendar_id: string;
  /** Summary */
  summary: string;
  /** Description */
  description?: string | null;
  /** Location */
  location?: string | null;
  /** Start Datetime */
  start_datetime: string;
  /** End Datetime */
  end_datetime: string;
  /** Attendees */
  attendees?: Record<string, string>[] | null;
  /** Reminders */
  reminders?: Record<string, any> | null;
}

/** CreateEventResponse */
export interface CreateEventResponse {
  /** Event Id */
  event_id: string;
  /** Html Link */
  html_link: string;
}

/**
 * CreatePortalSessionRequest
 * Request model for creating a customer portal session
 */
export interface CreatePortalSessionRequest {
  /** Customer Id */
  customer_id: string;
  /** Return Url */
  return_url: string;
}

/**
 * CustomerPortalResponse
 * Response model for customer portal session creation
 */
export interface CustomerPortalResponse {
  /** Url */
  url: string;
}

/**
 * CustomerSubscriptionResponse
 * Response model for getting customer subscription info
 */
export interface CustomerSubscriptionResponse {
  /** Customer Id */
  customer_id: string;
  /** Subscriptions */
  subscriptions: SubscriptionInfo[];
  /** Has Active Subscription */
  has_active_subscription: boolean;
}

/** DeleteEventRequest */
export interface DeleteEventRequest {
  /** Calendar Id */
  calendar_id: string;
  /** Event Id */
  event_id: string;
}

/** GoogleTokenRequest */
export interface GoogleTokenRequest {
  /** Code */
  code: string;
  /** Redirect Uri */
  redirect_uri: string;
}

/** GoogleTokenResponse */
export interface GoogleTokenResponse {
  /** Access Token */
  access_token: string;
  /** Refresh Token */
  refresh_token?: string | null;
  /** Expires In */
  expires_in: number;
  /** Token Type */
  token_type: string;
}

/** HTTPValidationError */
export interface HTTPValidationError {
  /** Detail */
  detail?: ValidationError[];
}

/** HealthResponse */
export interface HealthResponse {
  /** Status */
  status: string;
}

/** MetaWhatsAppConfig */
export interface MetaWhatsAppConfig {
  /** Phone Number Id */
  phone_number_id: string;
  /** Business Account Id */
  business_account_id: string;
  /** Access Token */
  access_token: string;
  /** Verification Token */
  verification_token: string;
}

/**
 * PriceOption
 * Price option model
 */
export interface PriceOption {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Price Id */
  price_id: string;
  /** Price */
  price: number;
  /** Interval */
  interval: string;
  /** Currency */
  currency: string;
  /** Features */
  features: string[];
}

/** SimulationRequest */
export interface SimulationRequest {
  /** User Input */
  user_input: string;
  /** Scenario */
  scenario?: string | null;
  /** Context */
  context?: Record<string, any> | null;
}

/** SimulationResponse */
export interface SimulationResponse {
  /** Ai Response */
  ai_response: string;
  /** Suggested Next Inputs */
  suggested_next_inputs: string[];
  /** Audio Base64 */
  audio_base64?: string | null;
  /** Actions */
  actions?: Record<string, any> | null;
  /** Conversation Summary */
  conversation_summary?: string | null;
  /** Improvement Suggestions */
  improvement_suggestions?: Record<string, string>[] | null;
  /** Performance Metrics */
  performance_metrics?: Record<string, number> | null;
}

/** SimulationScenario */
export interface SimulationScenario {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Initial Context */
  initial_context: Record<string, any>;
  /** Suggested First Input */
  suggested_first_input: string;
}

/** SimulationScenariosResponse */
export interface SimulationScenariosResponse {
  /** Scenarios */
  scenarios: SimulationScenario[];
}

/** SimulationToCallRequest */
export interface SimulationToCallRequest {
  /** Simulationid */
  simulationId: string;
  /** Scenarioid */
  scenarioId: string;
  /** Scenarioname */
  scenarioName: string;
  /**
   * Date
   * @format date-time
   */
  date: string;
  /** Successful */
  successful: boolean;
  /** Conversationsummary */
  conversationSummary: string;
  /** Appointmentstatus */
  appointmentStatus?: string | null;
  /** Appointmentservice */
  appointmentService?: string | null;
  /** Faqmatched */
  faqMatched?: boolean | null;
  /** Faqtopic */
  faqTopic?: string | null;
  /** Customercomplaint */
  customerComplaint?: boolean | null;
  /** Complaintseverity */
  complaintSeverity?: string | null;
  /** Performancemetrics */
  performanceMetrics?: Record<string, number> | null;
  /** Improvementsuggestions */
  improvementSuggestions?: Record<string, string>[] | null;
  /** Duration */
  duration?: number | null;
}

/**
 * SubscriptionInfo
 * Subscription information model
 */
export interface SubscriptionInfo {
  /** Subscription Id */
  subscription_id: string;
  /** Status */
  status: string;
  /** Current Period End */
  current_period_end: number;
  /** Cancel At Period End */
  cancel_at_period_end: boolean;
  /** Plan Id */
  plan_id: string;
  /** Price Id */
  price_id: string;
  /** Amount */
  amount: number;
  /** Currency */
  currency: string;
  /** Interval */
  interval: string;
}

/**
 * SubscriptionPlan
 * Subscription plan model
 */
export interface SubscriptionPlan {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Prices */
  prices: PriceOption[];
}

/** TextToSpeechRequest */
export interface TextToSpeechRequest {
  /** Text */
  text: string;
  /** Voice Id */
  voice_id: string;
  /**
   * Model Id
   * @default "eleven_multilingual_v2"
   */
  model_id?: string | null;
}

/** TextToSpeechResponse */
export interface TextToSpeechResponse {
  /** Audio Base64 */
  audio_base64: string;
}

/** TwilioConfig */
export interface TwilioConfig {
  /**
   * Account Sid
   * @pattern ^AC[a-zA-Z0-9]{32}$
   */
  account_sid: string;
  /** Auth Token */
  auth_token: string;
  /** Whatsapp Number */
  whatsapp_number: string;
}

/** User */
export interface User {
  /** Sub */
  sub: string;
  /** User Id */
  user_id?: string | null;
  /** Name */
  name?: string | null;
  /** Picture */
  picture?: string | null;
  /** Email */
  email?: string | null;
}

/** ValidationError */
export interface ValidationError {
  /** Location */
  loc: (string | number)[];
  /** Message */
  msg: string;
  /** Error Type */
  type: string;
}

/** VoiceDetails */
export interface VoiceDetails {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Voice Id */
  voice_id: string;
  /**
   * Description
   * @default ""
   */
  description?: string;
  /**
   * Region
   * @default ""
   */
  region?: string;
  /**
   * Gender
   * @default ""
   */
  gender?: string;
  /**
   * Style
   * @default ""
   */
  style?: string;
}

/** VoiceListResponse */
export interface VoiceListResponse {
  /** Voices */
  voices: VoiceDetails[];
}

/** VoiceSampleRequest */
export interface VoiceSampleRequest {
  /** Voice Id */
  voice_id: string;
  /**
   * Sample Type
   * @default "greeting"
   */
  sample_type?: string | null;
}

/** WhatsAppMessage */
export interface WhatsAppMessage {
  /** To */
  to: string;
  /** Message */
  message: string;
}

/** WhatsAppMessageRequest */
export interface WhatsAppMessageRequest {
  /** To Number */
  to_number: string;
  /**
   * Message
   * @default ""
   */
  message?: string;
  template?: WhatsAppTemplate | null;
}

/** WhatsAppTemplate */
export interface WhatsAppTemplate {
  /** Name */
  name: string;
  /**
   * Language Code
   * @default "es"
   */
  language_code?: string;
  /**
   * Parameters
   * @default []
   */
  parameters?: Record<string, string>[];
}

/** WhatsAppMessageResponse */
export interface AppApisMetaWhatsappWhatsAppMessageResponse {
  /** Success */
  success: boolean;
  /** Message Id */
  message_id?: string | null;
  /** Error */
  error?: string | null;
}

/** WhatsAppMessageResponse */
export interface AppApisWhatsappWhatsAppMessageResponse {
  /** Success */
  success: boolean;
  /** Message Sid */
  message_sid?: string | null;
  /** Error */
  error?: string | null;
}

export type CheckHealthData = HealthResponse;

export interface GetAuthUrlParams {
  /** User */
  user?: User | null;
}

export type GetAuthUrlData = any;

export type GetAuthUrlError = HTTPValidationError;

export interface ExchangeTokenParams {
  /** User */
  user?: User | null;
}

export type ExchangeTokenData = GoogleTokenResponse;

export type ExchangeTokenError = HTTPValidationError;

export type ListCalendarsData = CalendarListResponse;

export type CreateEventData = CreateEventResponse;

export type CreateEventError = HTTPValidationError;

export type DeleteEventData = any;

export type DeleteEventError = HTTPValidationError;

export interface GetConnectionStatusParams {
  /** User */
  user?: User | null;
}

export type GetConnectionStatusData = any;

export type GetConnectionStatusError = HTTPValidationError;

export type GetVoiceOptionsData = VoiceListResponse;

export type TextToSpeechData = TextToSpeechResponse;

export type TextToSpeechError = HTTPValidationError;

export type GetVoiceSampleData = TextToSpeechResponse;

export type GetVoiceSampleError = HTTPValidationError;

export type GetSimulationScenariosData = SimulationScenariosResponse;

export type SimulateCallData = SimulationResponse;

export type SimulateCallError = HTTPValidationError;

export type SaveTwilioConfigData = any;

export type SaveTwilioConfigError = HTTPValidationError;

/** Response List Subscription Plans */
export type ListSubscriptionPlansData = SubscriptionPlan[];

export type CreateCheckoutSessionData = CheckoutSessionResponse;

export type CreateCheckoutSessionError = HTTPValidationError;

export type CreatePortalSessionData = CustomerPortalResponse;

export type CreatePortalSessionError = HTTPValidationError;

export interface GetCustomerSubscriptionParams {
  /** Customer Id */
  customerId: string;
}

export type GetCustomerSubscriptionData = CustomerSubscriptionResponse;

export type GetCustomerSubscriptionError = HTTPValidationError;

export interface HandleWebhookParams {
  /**
   * Payload
   * @format binary
   */
  payload: File;
}

export type HandleWebhookData = any;

export type HandleWebhookError = HTTPValidationError;

/** Response Convert Simulation To Call */
export type ConvertSimulationToCallData = Record<string, any>;

export type ConvertSimulationToCallError = HTTPValidationError;

export type ListCallsData = CallListResponse;

export type WhatsappWebhookData = any;

export type WhatsappWebhookError = HTTPValidationError;

export type WhatsappStatusCallbackData = any;

export type WhatsappStatusCallbackError = HTTPValidationError;

export type CheckTwilioWhatsappStatusData = any;

export type SendTwilioWhatsappMessageData = AppApisWhatsappWhatsAppMessageResponse;

export type SendTwilioWhatsappMessageError = HTTPValidationError;

export type SaveMetaWhatsappConfigData = any;

export type SaveMetaWhatsappConfigError = HTTPValidationError;

export type SendWhatsappMessageData = AppApisMetaWhatsappWhatsAppMessageResponse;

export type SendWhatsappMessageError = HTTPValidationError;

export type CheckWhatsappStatusData = any;

export type VerifyWebhookData = any;

export type VerifyWebhookError = HTTPValidationError;

export type WebhookHandlerData = any;

export type GetSetupGuideData = any;

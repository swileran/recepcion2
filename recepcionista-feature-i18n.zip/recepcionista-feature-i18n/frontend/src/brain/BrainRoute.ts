import {
  CheckHealthData,
  CheckTwilioWhatsappStatusData,
  CheckWhatsappStatusData,
  ConvertSimulationToCallData,
  CreateCheckoutSessionData,
  CreateCheckoutSessionRequest,
  CreateEventData,
  CreateEventRequest,
  CreatePortalSessionData,
  CreatePortalSessionRequest,
  DeleteEventData,
  DeleteEventRequest,
  ExchangeTokenData,
  GetAuthUrlData,
  GetConnectionStatusData,
  GetCustomerSubscriptionData,
  GetSetupGuideData,
  GetSimulationScenariosData,
  GetVoiceOptionsData,
  GetVoiceSampleData,
  GoogleTokenRequest,
  HandleWebhookData,
  ListCalendarsData,
  ListCallsData,
  ListSubscriptionPlansData,
  MetaWhatsAppConfig,
  SaveMetaWhatsappConfigData,
  SaveTwilioConfigData,
  SendTwilioWhatsappMessageData,
  SendWhatsappMessageData,
  SimulateCallData,
  SimulationRequest,
  SimulationToCallRequest,
  TextToSpeechData,
  TextToSpeechRequest,
  TwilioConfig,
  User,
  VerifyWebhookData,
  VoiceSampleRequest,
  WebhookHandlerData,
  WhatsAppMessage,
  WhatsAppMessageRequest,
  WhatsappStatusCallbackData,
  WhatsappWebhookData,
} from "./data-contracts";

export namespace Brain {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  export namespace check_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckHealthData;
  }

  /**
   * @description Get the Google OAuth authorization URL
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name get_auth_url
   * @summary Get Auth Url
   * @request GET:/routes/google-calendar/auth-url
   */
  export namespace get_auth_url {
    export type RequestParams = {};
    export type RequestQuery = {
      /** User */
      user?: User | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAuthUrlData;
  }

  /**
   * @description Exchange authorization code for access and refresh tokens
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name exchange_token
   * @summary Exchange Token
   * @request POST:/routes/google-calendar/exchange-token
   */
  export namespace exchange_token {
    export type RequestParams = {};
    export type RequestQuery = {
      /** User */
      user?: User | null;
    };
    export type RequestBody = GoogleTokenRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ExchangeTokenData;
  }

  /**
   * @description List the user's Google Calendars
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name list_calendars
   * @summary List Calendars
   * @request GET:/routes/google-calendar/calendars
   */
  export namespace list_calendars {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListCalendarsData;
  }

  /**
   * @description Create a new event in Google Calendar
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name create_event
   * @summary Create Event
   * @request POST:/routes/google-calendar/events
   */
  export namespace create_event {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateEventRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateEventData;
  }

  /**
   * @description Delete an event from Google Calendar
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name delete_event
   * @summary Delete Event
   * @request DELETE:/routes/google-calendar/events
   */
  export namespace delete_event {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = DeleteEventRequest;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteEventData;
  }

  /**
   * @description Check if the user has connected their Google Calendar
   * @tags dbtn/module:google_calendar, dbtn/hasAuth
   * @name get_connection_status
   * @summary Get Connection Status
   * @request GET:/routes/google-calendar/connection-status
   */
  export namespace get_connection_status {
    export type RequestParams = {};
    export type RequestQuery = {
      /** User */
      user?: User | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetConnectionStatusData;
  }

  /**
   * @description Get available Spanish voices from ElevenLabs with regional metadata
   * @tags dbtn/module:voice_synthesis, dbtn/hasAuth
   * @name get_voice_options
   * @summary Get Voice Options
   * @request GET:/routes/voice-synthesis/voices
   */
  export namespace get_voice_options {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetVoiceOptionsData;
  }

  /**
   * @description Convert text to speech using ElevenLabs API with caching
   * @tags dbtn/module:voice_synthesis, dbtn/hasAuth
   * @name text_to_speech
   * @summary Text To Speech
   * @request POST:/routes/voice-synthesis/text-to-speech
   */
  export namespace text_to_speech {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = TextToSpeechRequest;
    export type RequestHeaders = {};
    export type ResponseBody = TextToSpeechData;
  }

  /**
   * @description Get a sample of a voice saying different types of standard phrases
   * @tags dbtn/module:voice_synthesis, dbtn/hasAuth
   * @name get_voice_sample
   * @summary Get Voice Sample
   * @request POST:/routes/voice-synthesis/sample
   */
  export namespace get_voice_sample {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = VoiceSampleRequest;
    export type RequestHeaders = {};
    export type ResponseBody = GetVoiceSampleData;
  }

  /**
   * @description Get available call simulation scenarios
   * @tags dbtn/module:call_simulation, dbtn/hasAuth
   * @name get_simulation_scenarios
   * @summary Get Simulation Scenarios
   * @request GET:/routes/call-simulation/scenarios
   */
  export namespace get_simulation_scenarios {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSimulationScenariosData;
  }

  /**
   * @description Simulate a call with the AI receptionist based on the user's input and context
   * @tags dbtn/module:call_simulation, dbtn/hasAuth
   * @name simulate_call
   * @summary Simulate Call
   * @request POST:/routes/call-simulation/simulate
   */
  export namespace simulate_call {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SimulationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SimulateCallData;
  }

  /**
   * @description Save Twilio configuration for WhatsApp integration.
   * @tags settings, dbtn/module:settings, dbtn/hasAuth
   * @name save_twilio_config
   * @summary Save Twilio Config
   * @request POST:/routes/settings/twilio
   */
  export namespace save_twilio_config {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = TwilioConfig;
    export type RequestHeaders = {};
    export type ResponseBody = SaveTwilioConfigData;
  }

  /**
   * @description Get available subscription plans
   * @tags dbtn/module:subscription, dbtn/hasAuth
   * @name list_subscription_plans
   * @summary List Subscription Plans
   * @request GET:/routes/subscription/plans
   */
  export namespace list_subscription_plans {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSubscriptionPlansData;
  }

  /**
   * @description Create a Stripe checkout session for subscription
   * @tags dbtn/module:subscription, dbtn/hasAuth
   * @name create_checkout_session
   * @summary Create Checkout Session
   * @request POST:/routes/subscription/checkout
   */
  export namespace create_checkout_session {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateCheckoutSessionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCheckoutSessionData;
  }

  /**
   * @description Create a Stripe customer portal session
   * @tags dbtn/module:subscription, dbtn/hasAuth
   * @name create_portal_session
   * @summary Create Portal Session
   * @request POST:/routes/subscription/portal
   */
  export namespace create_portal_session {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreatePortalSessionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreatePortalSessionData;
  }

  /**
   * @description Get subscription information for a customer
   * @tags dbtn/module:subscription, dbtn/hasAuth
   * @name get_customer_subscription
   * @summary Get Customer Subscription
   * @request GET:/routes/subscription/customer/{customer_id}
   */
  export namespace get_customer_subscription {
    export type RequestParams = {
      /** Customer Id */
      customerId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCustomerSubscriptionData;
  }

  /**
   * @description Handle Stripe webhooks
   * @tags dbtn/module:subscription, dbtn/hasAuth
   * @name handle_webhook
   * @summary Handle Webhook
   * @request POST:/routes/subscription/webhook
   */
  export namespace handle_webhook {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Payload
       * @format binary
       */
      payload: File;
    };
    export type RequestBody = never;
    export type RequestHeaders = {
      /** Stripe-Signature */
      "stripe-signature"?: string;
    };
    export type ResponseBody = HandleWebhookData;
  }

  /**
   * @description Convert a simulation result to a call record and save it to Firestore
   * @tags dbtn/module:call_analytics, dbtn/hasAuth
   * @name convert_simulation_to_call
   * @summary Convert Simulation To Call
   * @request POST:/routes/call-analytics/convert-simulation
   */
  export namespace convert_simulation_to_call {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SimulationToCallRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ConvertSimulationToCallData;
  }

  /**
   * @description List all call records for a business
   * @tags dbtn/module:call_analytics, dbtn/hasAuth
   * @name list_calls
   * @summary List Calls
   * @request GET:/routes/call-analytics/list
   */
  export namespace list_calls {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListCallsData;
  }

  /**
   * @description Webhook for incoming WhatsApp messages.
   * @tags whatsapp, dbtn/module:whatsapp, dbtn/hasAuth
   * @name whatsapp_webhook
   * @summary Whatsapp Webhook
   * @request POST:/routes/whatsapp/webhook
   */
  export namespace whatsapp_webhook {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {
      /** X-Twilio-Signature */
      "x-twilio-signature"?: string;
    };
    export type ResponseBody = WhatsappWebhookData;
  }

  /**
   * @description Webhook for WhatsApp message status updates.
   * @tags whatsapp, dbtn/module:whatsapp, dbtn/hasAuth
   * @name whatsapp_status_callback
   * @summary Whatsapp Status Callback
   * @request POST:/routes/whatsapp/status
   */
  export namespace whatsapp_status_callback {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {
      /** X-Twilio-Signature */
      "x-twilio-signature"?: string;
    };
    export type ResponseBody = WhatsappStatusCallbackData;
  }

  /**
   * @description Check the status of the WhatsApp integration.
   * @tags whatsapp, dbtn/module:whatsapp, dbtn/hasAuth
   * @name check_twilio_whatsapp_status
   * @summary Check Twilio Whatsapp Status
   * @request GET:/routes/whatsapp/status
   */
  export namespace check_twilio_whatsapp_status {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckTwilioWhatsappStatusData;
  }

  /**
   * @description Send a WhatsApp message.
   * @tags whatsapp, dbtn/module:whatsapp, dbtn/hasAuth
   * @name send_twilio_whatsapp_message
   * @summary Send Twilio Whatsapp Message
   * @request POST:/routes/whatsapp/send
   */
  export namespace send_twilio_whatsapp_message {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = WhatsAppMessageRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SendTwilioWhatsappMessageData;
  }

  /**
   * No description
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name save_meta_whatsapp_config
   * @summary Save Meta Whatsapp Config
   * @request POST:/routes/meta-whatsapp/config
   */
  export namespace save_meta_whatsapp_config {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = MetaWhatsAppConfig;
    export type RequestHeaders = {};
    export type ResponseBody = SaveMetaWhatsappConfigData;
  }

  /**
   * @description Send a WhatsApp message using Meta's WhatsApp Business Cloud API.
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name send_whatsapp_message
   * @summary Send Whatsapp Message
   * @request POST:/routes/meta-whatsapp/send
   */
  export namespace send_whatsapp_message {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = WhatsAppMessage;
    export type RequestHeaders = {};
    export type ResponseBody = SendWhatsappMessageData;
  }

  /**
   * @description Check the status of the Meta WhatsApp integration.
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name check_whatsapp_status
   * @summary Check Whatsapp Status
   * @request GET:/routes/meta-whatsapp/status
   */
  export namespace check_whatsapp_status {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckWhatsappStatusData;
  }

  /**
   * @description Verify the webhook subscription for Meta WhatsApp Cloud API.
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name verify_webhook
   * @summary Verify Webhook
   * @request GET:/routes/meta-whatsapp/verify-webhook
   */
  export namespace verify_webhook {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {
      /** Hub.Mode */
      hubMode?: string;
      /** Hub.Verify Token */
      hubVerifyToken?: string;
      /** Hub.Challenge */
      hubChallenge?: string;
    };
    export type ResponseBody = VerifyWebhookData;
  }

  /**
   * @description Handle incoming webhook events from Meta WhatsApp Cloud API.
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name webhook_handler
   * @summary Webhook Handler
   * @request POST:/routes/meta-whatsapp/webhook
   */
  export namespace webhook_handler {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = WebhookHandlerData;
  }

  /**
   * No description
   * @tags dbtn/module:meta_whatsapp, dbtn/hasAuth
   * @name get_setup_guide
   * @summary Get Setup Guide
   * @request GET:/routes/meta-whatsapp/setup-guide
   */
  export namespace get_setup_guide {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSetupGuideData;
  }
}

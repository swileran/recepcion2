import { useTranslation } from 'react-i18next';
import { useCallback, useEffect, useTransition } from 'react';
import { getStoredLanguage } from '../utils/languagePersistence';

export function useLanguage() {
  const { i18n, t } = useTranslation();
  const [isPending, startTransition] = useTransition();
  
  // Initialize with stored language
  useEffect(() => {
    const storedLanguage = getStoredLanguage();
    if (storedLanguage && i18n.language !== storedLanguage) {
      startTransition(() => {
        i18n.changeLanguage(storedLanguage);
      });
    }
  }, [i18n]);
  
  // Change language function
  const changeLanguage = useCallback((language: string) => {
    startTransition(() => {
      i18n.changeLanguage(language);
    });
  }, [i18n, startTransition]);
  
  // Toggle between Spanish and English
  const toggleLanguage = useCallback(() => {
    const newLanguage = i18n.language === 'es' ? 'en' : 'es';
    startTransition(() => {
      i18n.changeLanguage(newLanguage);
    });
  }, [i18n, startTransition]);
  
  return {
    currentLanguage: i18n.language,
    changeLanguage,
    toggleLanguage,
    isPending,
    t
  };
} 
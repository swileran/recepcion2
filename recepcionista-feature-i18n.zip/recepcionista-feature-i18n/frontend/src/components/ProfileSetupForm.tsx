import { useState, useEffect } from "react";
import { useCurrentUser } from "app";
import { useProfileStore } from "../utils/store";
import { FiSave, FiX, FiPlus, FiTrash } from "react-icons/fi";

interface Service {
  name: string;
  price: string;
  description: string;
}

interface Day {
  name: string;
  key: string;
  enabled: boolean;
  start: string;
  end: string;
}

interface FormErrors {
  businessName?: string;
  businessType?: string;
  phone?: string;
  email?: string;
  address?: string;
  services?: string;
  workingHours?: string;
}

export function ProfileSetupForm() {
  const { user } = useCurrentUser();
  const { profile, createProfile, updateProfile, isLoading, error } = useProfileStore();
  
  const [formErrors, setFormErrors] = useState<FormErrors>({});
  const [formSuccess, setFormSuccess] = useState("");
  
  // Form state
  const [businessName, setBusinessName] = useState("");
  const [businessType, setBusinessType] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [zipCode, setZipCode] = useState("");
  
  // Services
  const [services, setServices] = useState<Service[]>([{ name: "", price: "", description: "" }]);
  
  // Working hours
  const [workingDays, setWorkingDays] = useState<Day[]>([
    { name: "Lunes", key: "monday", enabled: true, start: "09:00", end: "18:00" },
    { name: "Martes", key: "tuesday", enabled: true, start: "09:00", end: "18:00" },
    { name: "Miércoles", key: "wednesday", enabled: true, start: "09:00", end: "18:00" },
    { name: "Jueves", key: "thursday", enabled: true, start: "09:00", end: "18:00" },
    { name: "Viernes", key: "friday", enabled: true, start: "09:00", end: "18:00" },
    { name: "Sábado", key: "saturday", enabled: false, start: "10:00", end: "14:00" },
    { name: "Domingo", key: "sunday", enabled: false, start: "10:00", end: "14:00" },
  ]);
  
  useEffect(() => {
    if (profile) {
      setBusinessName(profile.businessName || "");
      setBusinessType(profile.businessType || "");
      setPhone(profile.phone || "");
      setEmail(profile.email || "");
      setAddress(profile.address || "");
      setCity(profile.city || "");
      setZipCode(profile.zipCode || "");
      
      if (profile.servicesOffered && profile.servicesOffered.length > 0) {
        try {
          const parsedServices = profile.servicesOffered.map(service => {
            const [name, price, description] = service.split('|');
            return { name, price, description };
          });
          setServices(parsedServices);
        } catch (e) {
          // If there's an error parsing, just start with an empty service
          setServices([{ name: "", price: "", description: "" }]);
        }
      }
      
      if (profile.workingHours) {
        const updatedDays = [...workingDays];
        for (const day of updatedDays) {
          if (profile.workingHours[day.key]) {
            day.enabled = true;
            day.start = profile.workingHours[day.key].start;
            day.end = profile.workingHours[day.key].end;
          } else {
            day.enabled = false;
          }
        }
        setWorkingDays(updatedDays);
      }
    }
  }, [profile]);
  
  useEffect(() => {
    if (user && user.email) {
      setEmail(user.email);
    }
  }, [user]);
  
  const validateForm = (): boolean => {
    const errors: FormErrors = {};
    
    if (!businessName.trim()) {
      errors.businessName = "El nombre del negocio es obligatorio";
    }
    
    if (!businessType.trim()) {
      errors.businessType = "El tipo de negocio es obligatorio";
    }
    
    if (!phone.trim()) {
      errors.phone = "El teléfono es obligatorio";
    } else if (!/^\+?[0-9]{8,15}$/.test(phone.trim())) {
      errors.phone = "El teléfono debe tener entre 8 y 15 dígitos";
    }
    
    if (!email.trim()) {
      errors.email = "El correo electrónico es obligatorio";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      errors.email = "El correo electrónico no es válido";
    }
    
    // Validate services
    const hasInvalidService = services.some(service => 
      service.name.trim() === "" || service.price.trim() === ""
    );
    
    if (hasInvalidService) {
      errors.services = "Todos los servicios deben tener nombre y precio";
    }
    
    // Check if at least one day is enabled
    const hasEnabledDay = workingDays.some(day => day.enabled);
    if (!hasEnabledDay) {
      errors.workingHours = "Debes seleccionar al menos un día de trabajo";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const handleAddService = () => {
    setServices([...services, { name: "", price: "", description: "" }]);
  };
  
  const handleRemoveService = (index: number) => {
    const updatedServices = [...services];
    updatedServices.splice(index, 1);
    setServices(updatedServices);
  };
  
  const handleServiceChange = (index: number, field: keyof Service, value: string) => {
    const updatedServices = [...services];
    updatedServices[index][field] = value;
    setServices(updatedServices);
  };
  
  const handleDayToggle = (index: number) => {
    const updatedDays = [...workingDays];
    updatedDays[index].enabled = !updatedDays[index].enabled;
    setWorkingDays(updatedDays);
  };
  
  const handleHoursChange = (index: number, field: 'start' | 'end', value: string) => {
    const updatedDays = [...workingDays];
    updatedDays[index][field] = value;
    setWorkingDays(updatedDays);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSuccess("");
    
    if (!validateForm()) {
      return;
    }
    
    if (!user) {
      return;
    }
    
    try {
      // Save form state to local variables to prevent data loss on error
      const formData = {
        userId: user.uid,
        businessName,
        businessType,
        phone,
        email,
        address,
        city,
        zipCode,
        // Convert services to string array format for storage
        servicesOffered: services.filter(s => s.name.trim() !== "").map(s => 
          `${s.name}|${s.price}|${s.description}`
        ),
        // Convert working hours to record format
        workingHours: workingDays.reduce((acc, day) => {
          if (day.enabled) {
            acc[day.key] = {
              start: day.start,
              end: day.end
            };
          }
          return acc;
        }, {} as Record<string, { start: string; end: string }>)
      };
      
      if (profile?.id) {
        await updateProfile(profile.id, formData);
        setFormSuccess("Perfil actualizado con éxito");
      } else {
        await createProfile(formData);
        setFormSuccess("Perfil creado con éxito");
      }
      
      // Clear errors on success
      setFormErrors({});
      
      // Auto-dismiss success message after 5 seconds
      setTimeout(() => setFormSuccess(""), 5000);
      
    } catch (error) {
      console.error("Error saving profile:", error);
      const errorMessage = error instanceof Error ? error.message : "Error al guardar el perfil. Inténtalo de nuevo.";
      setFormErrors({ ...formErrors, businessName: errorMessage });
    }
  };
  
  const businessTypes = [
    "Peluquería / Belleza",
    "Taller mecánico",
    "Restaurante",
    "Clínica dental",
    "Consultoría",
    "Limpieza del hogar",
    "Servicios legales",
    "Fotografía",
    "Jardinería",
    "Fontanería",
    "Electricista",
    "Construcción",
    "Gimnasio / Entrenador personal",
    "Servicio técnico",
    "Otro"
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Success message */}
        {formSuccess && (
          <div className="bg-green-50 border border-green-200 text-green-800 rounded-md p-4 flex justify-between items-center">
            <p>{formSuccess}</p>
            <button 
              type="button" 
              onClick={() => setFormSuccess("")}
              className="text-green-600 hover:text-green-800"
            >
              <FiX size={20} />
            </button>
          </div>
        )}
        
        {/* Error message from store */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4">
            <p>{error.message}</p>
          </div>
        )}
        
        {/* Basic Information */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Información Básica</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="businessName" className="block text-sm font-medium text-gray-700 mb-1">
                Nombre del negocio *
              </label>
              <input
                type="text"
                id="businessName"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                className={`w-full px-3 py-2 border ${formErrors.businessName ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
                placeholder="Ej: Peluquería Estilo"
              />
              {formErrors.businessName && (
                <p className="mt-1 text-sm text-red-600">{formErrors.businessName}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="businessType" className="block text-sm font-medium text-gray-700 mb-1">
                Tipo de negocio *
              </label>
              <select
                id="businessType"
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                className={`w-full px-3 py-2 border ${formErrors.businessType ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
              >
                <option value="">Selecciona un tipo</option>
                {businessTypes.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
              {formErrors.businessType && (
                <p className="mt-1 text-sm text-red-600">{formErrors.businessType}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Teléfono de contacto *
              </label>
              <input
                type="tel"
                id="phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className={`w-full px-3 py-2 border ${formErrors.phone ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
                placeholder="Ej: +34612345678"
              />
              {formErrors.phone && (
                <p className="mt-1 text-sm text-red-600">{formErrors.phone}</p>
              )}
              <p className="mt-1 text-xs text-gray-500">
                Este es el número que los clientes marcarán para contactarte.
              </p>
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Correo electrónico *
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`w-full px-3 py-2 border ${formErrors.email ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
                placeholder="Ej: info@tuempresa.com"
              />
              {formErrors.email && (
                <p className="mt-1 text-sm text-red-600">{formErrors.email}</p>
              )}
            </div>
          </div>
          
          <div className="mt-6 space-y-4">
            <h4 className="text-sm font-medium text-gray-700">Dirección del negocio</h4>
            
            <div>
              <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                Dirección
              </label>
              <input
                type="text"
                id="address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                placeholder="Ej: Calle Ejemplo 123"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="zipCode" className="block text-sm font-medium text-gray-700 mb-1">
                  Código Postal
                </label>
                <input
                  type="text"
                  id="zipCode"
                  value={zipCode}
                  onChange={(e) => setZipCode(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Ej: 28001"
                />
              </div>
              
              <div>
                <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                  Ciudad
                </label>
                <input
                  type="text"
                  id="city"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Ej: Madrid"
                />
              </div>
            </div>
          </div>
        </div>
        
        {/* Services */}
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-gray-900">Servicios ofrecidos</h3>
            <button
              type="button"
              onClick={handleAddService}
              className="flex items-center text-sm font-medium text-orange-600 hover:text-orange-700"
            >
              <FiPlus className="mr-1" size={16} />
              Añadir servicio
            </button>
          </div>
          
          {formErrors.services && (
            <div className="mb-4 text-sm text-red-600">{formErrors.services}</div>
          )}
          
          <div className="space-y-4">
            {services.map((service, index) => (
              <div key={index} className="grid grid-cols-12 gap-4 items-start border-b border-gray-200 pb-4">
                <div className="col-span-5">
                  <label htmlFor={`service-name-${index}`} className="block text-sm font-medium text-gray-700 mb-1">
                    Nombre del servicio *
                  </label>
                  <input
                    type="text"
                    id={`service-name-${index}`}
                    value={service.name}
                    onChange={(e) => handleServiceChange(index, 'name', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Ej: Corte de pelo"
                  />
                </div>
                
                <div className="col-span-3">
                  <label htmlFor={`service-price-${index}`} className="block text-sm font-medium text-gray-700 mb-1">
                    Precio *
                  </label>
                  <input
                    type="text"
                    id={`service-price-${index}`}
                    value={service.price}
                    onChange={(e) => handleServiceChange(index, 'price', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Ej: 30€"
                  />
                </div>
                
                <div className="col-span-3">
                  <label htmlFor={`service-description-${index}`} className="block text-sm font-medium text-gray-700 mb-1">
                    Descripción
                  </label>
                  <input
                    type="text"
                    id={`service-description-${index}`}
                    value={service.description}
                    onChange={(e) => handleServiceChange(index, 'description', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Ej: 30 min"
                  />
                </div>
                
                <div className="col-span-1 pt-7">
                  {services.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveService(index)}
                      className="text-red-500 hover:text-red-700"
                      aria-label="Eliminar servicio"
                    >
                      <FiTrash size={18} />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Working Hours */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Horario de atención</h3>
          
          {formErrors.workingHours && (
            <div className="mb-4 text-sm text-red-600">{formErrors.workingHours}</div>
          )}
          
          <div className="space-y-4">
            {workingDays.map((day, index) => (
              <div key={day.key} className="grid grid-cols-12 gap-4 items-center">
                <div className="col-span-3 md:col-span-2">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id={`day-${day.key}`}
                      checked={day.enabled}
                      onChange={() => handleDayToggle(index)}
                      className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                    />
                    <label htmlFor={`day-${day.key}`} className="ml-2 block text-sm text-gray-700">
                      {day.name}
                    </label>
                  </div>
                </div>
                
                <div className="col-span-4 md:col-span-5">
                  <div className="flex items-center space-x-2">
                    <label htmlFor={`start-${day.key}`} className="block text-sm text-gray-700">
                      De
                    </label>
                    <input
                      type="time"
                      id={`start-${day.key}`}
                      value={day.start}
                      onChange={(e) => handleHoursChange(index, 'start', e.target.value)}
                      disabled={!day.enabled}
                      className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500 disabled:bg-gray-100 disabled:text-gray-500"
                    />
                  </div>
                </div>
                
                <div className="col-span-4 md:col-span-5">
                  <div className="flex items-center space-x-2">
                    <label htmlFor={`end-${day.key}`} className="block text-sm text-gray-700">
                      Hasta
                    </label>
                    <input
                      type="time"
                      id={`end-${day.key}`}
                      value={day.end}
                      onChange={(e) => handleHoursChange(index, 'end', e.target.value)}
                      disabled={!day.enabled}
                      className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500 disabled:bg-gray-100 disabled:text-gray-500"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Submit Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isLoading}
            className="px-6 py-3 bg-orange-600 text-white font-medium rounded-md shadow hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 flex items-center disabled:bg-gray-400"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Guardando...
              </>
            ) : (
              <>
                <FiSave className="mr-2" size={18} />
                Guardar perfil
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}

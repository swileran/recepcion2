import React, { useState, useEffect } from "react";
import { useCurrentUser } from "app";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, Check, AlertCircle } from "lucide-react";
import { doc, getDoc, setDoc, getFirestore } from "firebase/firestore";
import { firebaseApp } from "app";
import { toast } from "sonner";
import brain from "brain";

// Initialize Firestore
const db = getFirestore(firebaseApp);

export interface Props {
  onConfigured?: () => void;
}

export const WhatsAppConfig: React.FC<Props> = ({ onConfigured }) => {
  const { user } = useCurrentUser();
  const [twilioAccountSid, setTwilioAccountSid] = useState("");
  const [twilioAuthToken, setTwilioAuthToken] = useState("");
  const [twilioWhatsAppNumber, setTwilioWhatsAppNumber] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [configStatus, setConfigStatus] = useState<"unconfigured" | "pending" | "success" | "error">("unconfigured");
  const [errorMessage, setErrorMessage] = useState("");
  
  // Load existing configuration from Firestore
  useEffect(() => {
    if (!user) return;
    
    const loadConfig = async () => {
      try {
        setIsLoading(true);
        const configDoc = await getDoc(doc(db, `users/${user.uid}/config/whatsapp`));
        
        if (configDoc.exists()) {
          const data = configDoc.data();
          if (data.twilioAccountSid) setTwilioAccountSid(data.twilioAccountSid);
          if (data.twilioWhatsAppNumber) setTwilioWhatsAppNumber(data.twilioWhatsAppNumber);
          // We don't load the auth token for security reasons
          
          // Check if credentials are complete
          if (data.twilioAccountSid && data.twilioWhatsAppNumber) {
            setConfigStatus("success");
          }
        }
      } catch (error) {
        console.error("Error loading WhatsApp configuration:", error);
        setErrorMessage(String(error));
      } finally {
        setIsLoading(false);
      }
    };
    
    loadConfig();
  }, [user]);
  
  // Save configuration to Firestore and check connection
  const handleSaveConfig = async () => {
    if (!user) {
      toast.error("Debes iniciar sesión para guardar la configuración");
      return;
    }
    
    if (!twilioAccountSid || !twilioAuthToken || !twilioWhatsAppNumber) {
      toast.error("Por favor completa todos los campos");
      return;
    }
    
    setIsLoading(true);
    setConfigStatus("pending");
    
    try {
      // Format WhatsApp number
      let formattedNumber = twilioWhatsAppNumber.trim();
      if (!formattedNumber.startsWith("whatsapp:")) {
        formattedNumber = `whatsapp:${formattedNumber}`;
      }
      
      // Save to Firestore
      await setDoc(doc(db, `users/${user.uid}/config/whatsapp`), {
        twilioAccountSid,
        twilioWhatsAppNumber: formattedNumber,
        updatedAt: new Date(),
      });
      
// Call admin API to update server configuration
      try {
        const response = await fetch("/api/settings/twilio", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            account_sid: twilioAccountSid,
            auth_token: twilioAuthToken,
            whatsapp_number: formattedNumber
          })
        });
        
        const data = await response.json();
        
        if (data.success) {
          setConfigStatus("success");
          await checkWhatsAppStatus();
        } else {
          throw new Error(data.message || "Error saving configuration");
        }
      } catch (error) {
        console.error("Error updating server configuration:", error);
        setErrorMessage(String(error));
        setConfigStatus("error");
        throw error; // Re-throw to be caught by the outer try/catch block
      }
      
      toast.success("Configuración de WhatsApp guardada correctamente");
      
      if (onConfigured) {
        onConfigured();
      }
    } catch (error) {
      console.error("Error saving WhatsApp configuration:", error);
      setErrorMessage(String(error));
      setConfigStatus("error");
      toast.error("Error al guardar la configuración de WhatsApp");
    } finally {
      setIsLoading(false);
    }
  };
  
  // Test the WhatsApp connection
  const checkWhatsAppStatus = async () => {
    setIsTesting(true);
    try {
      const response = await brain.check_whatsapp_status();
      const data = await response.json();
      
      if (data.status === "connected") {
        setConfigStatus("success");
      } else {
        setConfigStatus("error");
        setErrorMessage(data.message || "No se pudo conectar con WhatsApp");
      }
    } catch (error) {
      setConfigStatus("error");
      setErrorMessage(String(error));
    } finally {
      setIsTesting(false);
    }
  };
  
  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Configuración de WhatsApp</CardTitle>
        <CardDescription>
          Configura tus credenciales de Twilio para habilitar la integración con WhatsApp Business API.
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {configStatus === "success" && (
          <Alert className="bg-green-50 border-green-500">
            <Check className="h-4 w-4 text-green-500" />
            <AlertTitle>Configuración exitosa</AlertTitle>
            <AlertDescription>
              Tu conexión con WhatsApp está configurada correctamente.
            </AlertDescription>
          </Alert>
        )}
        
        {configStatus === "error" && (
          <Alert className="bg-red-50 border-red-500">
            <AlertCircle className="h-4 w-4 text-red-500" />
            <AlertTitle>Error de configuración</AlertTitle>
            <AlertDescription>
              {errorMessage || "No se pudo establecer la conexión con WhatsApp. Verifica tus credenciales."}
            </AlertDescription>
          </Alert>
        )}
        
        <div className="space-y-2">
          <Label htmlFor="twilioAccountSid">Twilio Account SID</Label>
          <Input
            id="twilioAccountSid"
            placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
            value={twilioAccountSid}
            onChange={(e) => setTwilioAccountSid(e.target.value)}
            disabled={isLoading}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="twilioAuthToken">Twilio Auth Token</Label>
          <Input
            id="twilioAuthToken"
            type="password"
            placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
            value={twilioAuthToken}
            onChange={(e) => setTwilioAuthToken(e.target.value)}
            disabled={isLoading}
          />
          <p className="text-xs text-muted-foreground">
            Nota: El token no se guarda en la base de datos por razones de seguridad.
            Deberás proporcionarlo cada vez que actualices la configuración.
          </p>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="twilioWhatsAppNumber">Número de WhatsApp</Label>
          <Input
            id="twilioWhatsAppNumber"
            placeholder="whatsapp:+14155238886"
            value={twilioWhatsAppNumber}
            onChange={(e) => setTwilioWhatsAppNumber(e.target.value)}
            disabled={isLoading}
          />
          <p className="text-xs text-muted-foreground">
            Formato: whatsapp:+14155238886 (con el prefijo "whatsapp:" y código de país)
          </p>
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button 
          variant="outline" 
          onClick={checkWhatsAppStatus} 
          disabled={isLoading || isTesting || !twilioAccountSid || !twilioWhatsAppNumber}
        >
          {isTesting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Probando...
            </>
          ) : "Probar conexión"}
        </Button>
        
        <Button 
          onClick={handleSaveConfig} 
          disabled={isLoading || !twilioAccountSid || !twilioAuthToken || !twilioWhatsAppNumber}
          className="bg-orange-500 hover:bg-orange-600"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Guardando...
            </>
          ) : "Guardar configuración"}
        </Button>
      </CardFooter>
    </Card>
  );
};

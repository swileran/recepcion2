import React, { useEffect, useTransition } from 'react';
import { useTranslation } from 'react-i18next';
import { FiGlobe } from 'react-icons/fi';
import { getStoredLanguage } from '../utils/languagePersistence';

interface LanguageSwitcherProps {
  className?: string;
}

export function LanguageSwitcher({ className = '' }: LanguageSwitcherProps) {
  const { i18n } = useTranslation();
  const [isPending, startTransition] = useTransition();
  
  // Initialize with stored language on component mount
  useEffect(() => {
    const storedLanguage = getStoredLanguage();
    if (storedLanguage && i18n.language !== storedLanguage) {
      startTransition(() => {
        i18n.changeLanguage(storedLanguage);
      });
    }
  }, [i18n]);
  
  const toggleLanguage = () => {
    const newLanguage = i18n.language === 'es' ? 'en' : 'es';
    startTransition(() => {
      i18n.changeLanguage(newLanguage);
    });
  };
  
  return (
    <button
      onClick={toggleLanguage}
      className={`flex items-center space-x-1 text-gray-700 hover:text-orange-600 transition-colors ${className} ${isPending ? 'opacity-70' : ''}`}
      aria-label="Toggle language"
      disabled={isPending}
    >
      <FiGlobe size={18} />
      <span>{i18n.language === 'es' ? 'EN' : 'ES'}</span>
      {isPending && <span className="ml-1 animate-pulse">...</span>}
    </button>
  );
} 
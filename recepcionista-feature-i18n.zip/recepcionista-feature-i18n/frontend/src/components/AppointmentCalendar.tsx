import { useState, useEffect } from "react";
import { useAppointmentStore, Appointment } from "../utils/appointmentStore";
import { useProfileStore } from "../utils/store";
import { FiChevronLeft, FiChevronRight, FiPlus, FiClock, FiUser, FiPhone, FiInfo, FiX } from "react-icons/fi";
import { AppointmentForm } from "./AppointmentForm";

interface CalendarDay {
  date: Date;
  isCurrentMonth: boolean;
  isToday: boolean;
  appointments: Appointment[];
}

export function AppointmentCalendar() {
  const { profile } = useProfileStore();
  const { 
    appointments, 
    fetchAppointments, 
    subscribeToAppointments, 
    unsubscribeFromAppointments,
    isLoading 
  } = useAppointmentStore();
  
  const [currentDate, setCurrentDate] = useState(new Date());
  const [calendarDays, setCalendarDays] = useState<CalendarDay[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [showAppointmentForm, setShowAppointmentForm] = useState(false);
  const [editAppointmentId, setEditAppointmentId] = useState<string | undefined>(undefined);
  
  // Format options for dates
  const monthYearFormat = { month: 'long', year: 'numeric' } as Intl.DateTimeFormatOptions;
  const dayFormat = { day: 'numeric' } as Intl.DateTimeFormatOptions;
  const timeFormat = { hour: '2-digit', minute: '2-digit', hour12: true } as Intl.DateTimeFormatOptions;
  
  // Generate calendar days for the current month view
  useEffect(() => {
    if (!profile?.id) return;
    
    // Calculate first day of the month
    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    
    // Calculate last day of the month
    const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    
    // Calculate the day of the week of the first day (0 = Sunday, 6 = Saturday)
    const firstDayOfWeek = firstDayOfMonth.getDay();
    
    // Calculate days from previous month to display
    const daysFromPrevMonth = firstDayOfWeek;
    
    // Calculate total days needed (previous month + current month + next month to fill grid)
    const totalDays = 42; // 6 rows of 7 days
    
    const days: CalendarDay[] = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Add days from previous month
    for (let i = daysFromPrevMonth - 1; i >= 0; i--) {
      const date = new Date(firstDayOfMonth);
      date.setDate(firstDayOfMonth.getDate() - (i + 1));
      days.push({
        date,
        isCurrentMonth: false,
        isToday: date.getTime() === today.getTime(),
        appointments: []
      });
    }
    
    // Add days from current month
    for (let i = 1; i <= lastDayOfMonth.getDate(); i++) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), i);
      days.push({
        date,
        isCurrentMonth: true,
        isToday: date.getTime() === today.getTime(),
        appointments: []
      });
    }
    
    // Add days from next month to fill the grid
    const remainingDays = totalDays - days.length;
    for (let i = 1; i <= remainingDays; i++) {
      const date = new Date(lastDayOfMonth);
      date.setDate(lastDayOfMonth.getDate() + i);
      days.push({
        date,
        isCurrentMonth: false,
        isToday: date.getTime() === today.getTime(),
        appointments: []
      });
    }
    
    // Load appointments for the current view
    const viewStartDate = days[0].date;
    const viewEndDate = days[days.length - 1].date;
    
    // Subscribe to appointments for the current date range
    subscribeToAppointments(profile.id, viewStartDate, viewEndDate);
    
    // Match appointments to calendar days
    days.forEach(day => {
      const dayAppointments = appointments.filter(apt => {
        const aptDate = new Date(apt.date);
        return aptDate.getDate() === day.date.getDate() && 
               aptDate.getMonth() === day.date.getMonth() && 
               aptDate.getFullYear() === day.date.getFullYear();
      });
      day.appointments = dayAppointments;
    });
    
    setCalendarDays(days);
    
    // Cleanup subscription when component unmounts or date changes
    return () => unsubscribeFromAppointments();
  }, [currentDate, profile?.id, appointments, subscribeToAppointments, unsubscribeFromAppointments]);
  
  // Go to previous month
  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    setSelectedDate(null);
    setSelectedAppointment(null);
  };
  
  // Go to next month
  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    setSelectedDate(null);
    setSelectedAppointment(null);
  };
  
  // Go to today
  const goToToday = () => {
    setCurrentDate(new Date());
    setSelectedDate(new Date());
    setSelectedAppointment(null);
  };
  
  // Handle day click
  const handleDayClick = (day: CalendarDay) => {
    setSelectedDate(day.date);
    setSelectedAppointment(null);
  };
  
  // Handle appointment click
  const handleAppointmentClick = (appointment: Appointment) => {
    setSelectedAppointment(appointment);
  };
  
  // Handle new appointment click
  const handleNewAppointment = () => {
    setEditAppointmentId(undefined);
    setShowAppointmentForm(true);
  };
  
  // Handle edit appointment
  const handleEditAppointment = () => {
    if (selectedAppointment?.id) {
      setEditAppointmentId(selectedAppointment.id);
      setShowAppointmentForm(true);
      setSelectedAppointment(null);
    }
  };
  
  // Handle form close
  const handleFormClose = () => {
    setShowAppointmentForm(false);
    setEditAppointmentId(undefined);
  };
  
  // Handle appointment saved
  const handleAppointmentSaved = () => {
    // Refresh the calendar view if needed
    // Our subscription should handle this automatically
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      {/* Calendar Header */}
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <h2 className="text-lg font-semibold text-gray-800">
            {currentDate.toLocaleDateString('es', monthYearFormat)}
          </h2>
          <div className="hidden md:flex ml-4">
            <button 
              onClick={goToToday}
              className="px-3 py-1 text-xs border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Hoy
            </button>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <button 
            onClick={prevMonth}
            className="p-2 rounded-full hover:bg-gray-100"
            aria-label="Mes anterior"
          >
            <FiChevronLeft size={20} />
          </button>
          <button 
            onClick={nextMonth}
            className="p-2 rounded-full hover:bg-gray-100"
            aria-label="Mes siguiente"
          >
            <FiChevronRight size={20} />
          </button>
          <button
            onClick={handleNewAppointment}
            className="ml-2 px-3 py-1 bg-orange-600 text-white text-sm rounded-md flex items-center hover:bg-orange-700"
          >
            <FiPlus className="mr-1" size={16} />
            <span className="hidden md:inline">Nueva Cita</span>
          </button>
        </div>
      </div>
      
      {/* Calendar Grid */}
      <div className="flex flex-col">
        {/* Day headers */}
        <div className="grid grid-cols-7 border-b border-gray-200">
          {['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'].map((day, index) => (
            <div 
              key={day} 
              className="px-2 py-3 text-center text-sm font-medium text-gray-500"
            >
              {day}
            </div>
          ))}
        </div>
        
        {/* Calendar days */}
        {isLoading ? (
          <div className="h-96 flex items-center justify-center">
            <svg className="animate-spin h-8 w-8 text-orange-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          </div>
        ) : (
          <div className="grid grid-cols-7 auto-rows-fr" style={{ minHeight: '500px' }}>
            {calendarDays.map((day, index) => (
              <div 
                key={index}
                className={`border-b border-r border-gray-200 min-h-[100px] ${day.isCurrentMonth ? '' : 'bg-gray-50'} ${day.isToday ? 'bg-orange-50' : ''} ${selectedDate && day.date.getTime() === selectedDate.getTime() ? 'bg-orange-100' : ''}`}
                onClick={() => handleDayClick(day)}
              >
                <div className="flex flex-col h-full">
                  {/* Day number */}
                  <div className={`px-2 pt-2 pb-1 text-right ${day.isCurrentMonth ? 'text-gray-900' : 'text-gray-400'} ${day.isToday ? 'font-bold' : ''}`}>
                    {day.date.toLocaleDateString('es', dayFormat)}
                  </div>
                  
                  {/* Appointments for the day */}
                  <div className="flex-grow px-1 overflow-y-auto">
                    {day.appointments.length > 0 ? (
                      <div className="space-y-1">
                        {day.appointments.map((apt) => (
                          <div 
                            key={apt.id}
                            className={`p-1 text-xs rounded truncate cursor-pointer ${selectedAppointment && selectedAppointment.id === apt.id ? 'bg-orange-500 text-white' : 'bg-orange-100 text-orange-800 hover:bg-orange-200'}`}
                            onClick={(e) => { e.stopPropagation(); handleAppointmentClick(apt); }}
                          >
                            <div className="flex items-center">
                              <FiClock className="mr-1" size={10} />
                              <span className="font-semibold">{apt.startTime}</span>
                            </div>
                            <div className="truncate">{apt.clientName}</div>
                          </div>
                        ))}
                      </div>
                    ) : null}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Appointment Detail Panel */}
      {selectedAppointment && (
        <div className="border-t border-gray-200 p-4 bg-gray-50">
          <div className="flex justify-between items-start">
            <h3 className="text-lg font-semibold text-gray-800">
              Detalles de la Cita
            </h3>
            <button 
              onClick={() => setSelectedAppointment(null)}
              className="text-gray-400 hover:text-gray-500"
            >
              <FiX size={20} />
            </button>
          </div>
          
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center text-gray-700 mb-2">
                <FiClock className="mr-2" size={16} />
                <span className="font-medium">Horario:</span>
                <span className="ml-2">
                  {selectedAppointment.startTime} - {selectedAppointment.endTime}
                </span>
              </div>
              
              <div className="flex items-center text-gray-700 mb-2">
                <FiUser className="mr-2" size={16} />
                <span className="font-medium">Cliente:</span>
                <span className="ml-2">{selectedAppointment.clientName}</span>
              </div>
              
              <div className="flex items-center text-gray-700 mb-2">
                <FiPhone className="mr-2" size={16} />
                <span className="font-medium">Teléfono:</span>
                <span className="ml-2">{selectedAppointment.clientPhone}</span>
              </div>
            </div>
            
            <div>
              <div className="flex items-start text-gray-700 mb-2">
                <FiInfo className="mr-2 mt-1" size={16} />
                <div>
                  <span className="font-medium">Servicio:</span>
                  <span className="ml-2 block">{selectedAppointment.serviceName}</span>
                </div>
              </div>
              
              {selectedAppointment.notes && (
                <div className="mt-2">
                  <span className="font-medium text-gray-700">Notas:</span>
                  <p className="mt-1 text-sm text-gray-600">{selectedAppointment.notes}</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="mt-4 flex justify-end space-x-3">
            <button
              onClick={handleEditAppointment}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              Editar
            </button>
            <button
              className="px-4 py-2 border border-red-300 rounded-md shadow-sm text-sm font-medium text-red-700 bg-white hover:bg-red-50"
            >
              Cancelar Cita
            </button>
          </div>
        </div>
      )}
      
      {/* Appointment Form Modal */}
      {showAppointmentForm && (
        <AppointmentForm
          date={selectedDate || undefined}
          appointmentId={editAppointmentId}
          onClose={handleFormClose}
          onSaved={handleAppointmentSaved}
        />
      )}
    </div>
  );
}

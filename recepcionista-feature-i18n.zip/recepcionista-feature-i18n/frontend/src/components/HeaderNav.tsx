import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { FiUser, FiLogIn, FiMenu, FiX, FiGlobe } from "react-icons/fi";
import { useCurrentUser, APP_BASE_PATH } from "app";
import { useTranslation } from 'react-i18next';

interface Props {
  onCtaClick: () => void;
}

export function HeaderNav({ onCtaClick }: Props) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, loading } = useCurrentUser();
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleAuthClick = () => {
    if (user) {
      navigate('/logout');
    } else {
      navigate('/login');
    }
  };

  const toggleLanguage = () => {
    const newLanguage = i18n.language === 'es' ? 'en' : 'es';
    i18n.changeLanguage(newLanguage);
  };

  return (
    <header className="w-full py-4 bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-orange-600">{t('brand.name')}</h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#beneficios" className="text-gray-700 hover:text-orange-600 transition-colors font-medium">
              {t('nav.benefits')}
            </a>
            <a href="#como-funciona" className="text-gray-700 hover:text-orange-600 transition-colors font-medium">
              {t('nav.howItWorks')}
            </a>
            <a href="#precios" className="text-gray-700 hover:text-orange-600 transition-colors font-medium">
              {t('nav.pricing')}
            </a>
            <button
              onClick={handleAuthClick}
              className="px-5 py-2 border border-orange-500 text-orange-600 font-medium rounded-full hover:bg-orange-50 transition-all duration-300 flex items-center space-x-2"
            >
              {loading ? (
                <span>{t('nav.loading')}</span>
              ) : user ? (
                <>
                  <FiUser size={18} />
                  <span>{t('nav.myAccount')}</span>
                </>
              ) : (
                <>
                  <FiLogIn size={18} />
                  <span>{t('nav.login')}</span>
                </>
              )}
            </button>
            <a
              href={`/login?signup=true`}
              className="inline-block px-5 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white font-medium rounded-full hover:shadow-md transition-all duration-300"
            >
              {t('nav.startNow')}
            </a>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 text-gray-700 hover:text-orange-600 transition-colors"
              aria-label="Toggle language"
            >
              <FiGlobe size={18} />
              <span>{i18n.language === 'es' ? 'EN' : 'ES'}</span>
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-4">
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 text-gray-700 hover:text-orange-600 transition-colors"
              aria-label="Toggle language"
            >
              <FiGlobe size={18} />
              <span>{i18n.language === 'es' ? 'EN' : 'ES'}</span>
            </button>
            <button
              onClick={toggleMobileMenu}
              className="text-gray-700 hover:text-orange-600 transition-colors"
              aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
            >
              {mobileMenuOpen ? <FiX size={24} /> : <FiMenu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-white shadow-lg py-4 px-6 z-50">
          <nav className="flex flex-col space-y-4">
            <a 
              href="#beneficios" 
              className="text-gray-700 hover:text-orange-600 transition-colors font-medium"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('nav.benefits')}
            </a>
            <a 
              href="#como-funciona" 
              className="text-gray-700 hover:text-orange-600 transition-colors font-medium"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('nav.howItWorks')}
            </a>
            <a 
              href="#precios" 
              className="text-gray-700 hover:text-orange-600 transition-colors font-medium"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('nav.pricing')}
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                handleAuthClick();
              }}
              className="px-5 py-2 border border-orange-500 text-orange-600 font-medium rounded-full hover:bg-orange-50 transition-all duration-300 flex items-center space-x-2"
            >
              {loading ? (
                <span>{t('nav.loading')}</span>
              ) : user ? (
                <>
                  <FiUser size={18} />
                  <span>{t('nav.myAccount')}</span>
                </>
              ) : (
                <>
                  <FiLogIn size={18} />
                  <span>{t('nav.login')}</span>
                </>
              )}
            </button>
            <a
              href={`/login?signup=true`}
              className="inline-block px-5 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white font-medium rounded-full hover:shadow-md transition-all duration-300 mt-4"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('nav.startNow')}
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}

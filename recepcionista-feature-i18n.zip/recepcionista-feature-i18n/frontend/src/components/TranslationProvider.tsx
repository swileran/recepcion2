import React, { createContext, useContext, ReactNode } from 'react';
import { useTranslation } from 'react-i18next';

interface TranslationContextType {
  translate: (key: string, defaultValue?: string) => string;
  translateWithVars: (key: string, variables: Record<string, string | number>, defaultValue?: string) => string;
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

interface TranslationProviderProps {
  namespace?: string;
  children: ReactNode;
}

export const TranslationProvider: React.FC<TranslationProviderProps> = ({ 
  namespace, 
  children 
}) => {
  const { t } = useTranslation();
  
  const translate = (key: string, defaultValue?: string): string => {
    const fullKey = namespace ? `${namespace}.${key}` : key;
    return t(fullKey, defaultValue);
  };
  
  const translateWithVars = (
    key: string, 
    variables: Record<string, string | number>, 
    defaultValue?: string
  ): string => {
    const fullKey = namespace ? `${namespace}.${key}` : key;
    return t(fullKey, { ...variables, defaultValue });
  };
  
  const value = {
    translate,
    translateWithVars
  };
  
  return (
    <TranslationContext.Provider value={value}>
      {children}
    </TranslationContext.Provider>
  );
};

export const useComponentTranslation = (): TranslationContextType => {
  const context = useContext(TranslationContext);
  if (!context) {
    throw new Error('useComponentTranslation must be used within a TranslationProvider');
  }
  return context;
}; 
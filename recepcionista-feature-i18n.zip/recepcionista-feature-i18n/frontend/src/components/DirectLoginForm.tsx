import React, { useState } from 'react';
import { signInWithEmailAndPassword, fetchSignInMethodsForEmail } from 'firebase/auth';
import { firebaseAuth } from 'app';
import { FiMail, FiLock, FiAlertCircle } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';

interface Props {
  onSuccess?: () => void;
  initialEmail?: string;
}

export function DirectLoginForm({ onSuccess, initialEmail = '' }: Props) {
  const navigate = useNavigate();
  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const checkEmailExists = async (email: string): Promise<boolean> => {
    try {
      const methods = await fetchSignInMethodsForEmail(firebaseAuth, email);
      console.log('Sign in methods for email:', methods);
      return methods.length > 0;
    } catch (error) {
      console.error('Error checking email existence:', error);
      return false;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Form validation
    if (!email || !password) {
      setError('Por favor, completa todos los campos');
      return;
    }
    
    try {
      setLoading(true);
      console.log('DirectLoginForm: Attempting to sign in with:', email);
      
      // Add a small delay to ensure network stability
      await new Promise(resolve => setTimeout(resolve, 500));
      
      try {
        // Check if email exists first
        const emailExists = await checkEmailExists(email);
        console.log('DirectLoginForm: Email exists check result:', emailExists);
        
        if (!emailExists) {
          console.log('DirectLoginForm: Email does not exist:', email);
          setError('No existe una cuenta con este correo. Por favor regístrate.');
          setLoading(false);
          return;
        }
      } catch (checkErr) {
        console.error('DirectLoginForm: Error checking email:', checkErr);
        // Continue with sign in attempt even if email check fails
      }
      
      console.log('DirectLoginForm: Proceeding with sign in attempt');
      const userCredential = await signInWithEmailAndPassword(firebaseAuth, email, password);
      console.log('DirectLoginForm: Sign in successful for user:', userCredential.user.uid);
      
      // Add a small delay to ensure Firebase auth state is updated
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Call the success callback if provided
      if (onSuccess) {
        onSuccess();
      } else {
        // Redirect to dashboard
        console.log('DirectLoginForm: Redirecting to dashboard');
        navigate('/dashboard');
      }
    } catch (err: any) {
      console.error('DirectLoginForm: Error during sign in:', err);
      console.log('DirectLoginForm: Error code:', err.code, 'Error message:', err.message);
      
      // Network related errors
      if (err.code === 'auth/network-request-failed') {
        setError('Error de conexión. Por favor, verifica tu conexión a internet e inténtalo de nuevo.');
      }
      // Translate Firebase errors to user-friendly Spanish messages
      else if (err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password') {
        setError('Correo electrónico o contraseña incorrectos');
      } else if (err.code === 'auth/user-not-found') {
        setError('No existe una cuenta con este correo. Por favor regístrate.');
      } else if (err.code === 'auth/invalid-email') {
        setError('El correo electrónico no es válido');
      } else if (err.code === 'auth/too-many-requests') {
        setError('Demasiados intentos fallidos. Por favor, inténtalo de nuevo más tarde.');
      } else {
        setError(`Error al iniciar sesión: ${err.message || 'Desconocido'}. Por favor, inténtalo de nuevo.`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4 mb-4 flex items-start">
          <FiAlertCircle className="flex-shrink-0 mr-2 mt-0.5" />
          <p>{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
            Correo Electrónico
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FiMail className="text-gray-400" />
            </div>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
              placeholder="tu@email.com"
              required
            />
          </div>
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
            Contraseña
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FiLock className="text-gray-400" />
            </div>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-10 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
              placeholder="Contraseña"
              required
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50"
        >
          {loading ? 'Iniciando sesión...' : 'Iniciar sesión'}
        </button>
      </form>
    </div>
  );
}
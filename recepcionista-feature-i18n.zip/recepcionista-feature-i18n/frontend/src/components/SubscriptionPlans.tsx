import { useState, useEffect } from "react";
import { useProfileStore } from "utils/profileStore";
import { useSubscriptionStore, SubscriptionPlan, PriceOption } from "utils/subscriptionStore";
import { useCurrentUser } from "app";
import { toast } from "sonner";
import { CheckoutForm } from "./CheckoutForm";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";

interface SubscriptionPlansProps {
  onClose?: () => void;
}

export function SubscriptionPlans({ onClose }: SubscriptionPlansProps) {
  const { user } = useCurrentUser();
  const { profile } = useProfileStore();
  const { 
    plans, 
    isLoading, 
    error, 
    fetchPlans,
  } = useSubscriptionStore();
  
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [selectedPrice, setSelectedPrice] = useState<PriceOption | null>(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [placeholderPlans, setPlaceholderPlans] = useState<SubscriptionPlan[]>([]);
  
  // Stripe setup
  // The stripe instance is already provided by the StripeProvider component
  // so we don't need to initialize it here
  
  // Combine actual plans with placeholder plans if needed
  const displayPlans = plans.length > 0 ? plans : placeholderPlans;
  
  useEffect(() => {
    fetchPlans();
  }, [fetchPlans]);
  
  // Add placeholder plans if no plans are returned from Stripe
  useEffect(() => {
    if (!isLoading && !error && plans.length === 0) {
      // Create placeholder plans for testing
      const placeholderPlans = [
        {
          id: 'plan_basico',
          name: 'Plan Básico',
          description: 'Perfecto para pequeños negocios que están comenzando',
          prices: [
            {
              id: 'price_basico_mensual',
              name: 'Mensual',
              price_id: 'price_basic_monthly',
              price: 2900,
              interval: 'month',
              currency: 'eur',
              features: [
                'Recepcionista virtual con IA',
                '1 línea de teléfono',
                '100 minutos de llamadas al mes',
                'Gestión básica de citas'
              ]
            },
            {
              id: 'price_basico_anual',
              name: 'Anual',
              price_id: 'price_basic_yearly',
              price: 29900,
              interval: 'year',
              currency: 'eur',
              features: [
                'Recepcionista virtual con IA',
                '1 línea de teléfono',
                '100 minutos de llamadas al mes',
                'Gestión básica de citas',
                '2 meses gratis'
              ]
            }
          ]
        },
        {
          id: 'plan_profesional',
          name: 'Plan Profesional',
          description: 'Ideal para negocios establecidos con volumen medio de llamadas',
          prices: [
            {
              id: 'price_profesional_mensual',
              name: 'Mensual',
              price_id: 'price_pro_monthly',
              price: 4900,
              interval: 'month',
              currency: 'eur',
              features: [
                'Recepcionista virtual con IA',
                '3 líneas de teléfono',
                '300 minutos de llamadas al mes',
                'Gestión avanzada de citas',
                'Personalización de voz'
              ]
            },
            {
              id: 'price_profesional_anual',
              name: 'Anual',
              price_id: 'price_pro_yearly',
              price: 49900,
              interval: 'year',
              currency: 'eur',
              features: [
                'Recepcionista virtual con IA',
                '3 líneas de teléfono',
                '300 minutos de llamadas al mes',
                'Gestión avanzada de citas',
                'Personalización de voz',
                '2 meses gratis'
              ]
            }
          ]
        },
        {
          id: 'plan_empresa',
          name: 'Plan Empresa',
          description: 'Para negocios con alto volumen de llamadas y necesidades avanzadas',
          prices: [
            {
              id: 'price_empresa_mensual',
              name: 'Mensual',
              price_id: 'price_business_monthly',
              price: 9900,
              interval: 'month',
              currency: 'eur',
              features: [
                'Recepcionista virtual con IA',
                'Líneas ilimitadas',
                '1000 minutos de llamadas al mes',
                'Sistema completo de gestión de citas',
                'Personalización total',
                'Integración con CRM',
                'Soporte prioritario'
              ]
            },
            {
              id: 'price_empresa_anual',
              name: 'Anual',
              price_id: 'price_business_yearly',
              price: 99900,
              interval: 'year',
              currency: 'eur',
              features: [
                'Recepcionista virtual con IA',
                'Líneas ilimitadas',
                '1000 minutos de llamadas al mes',
                'Sistema completo de gestión de citas',
                'Personalización total',
                'Integración con CRM',
                'Soporte prioritario',
                '2 meses gratis'
              ]
            }
          ]
        }
      ];
      
      // We don't have the set function from useSubscriptionStore in this component
      // Instead we'll use the plans directly in the component state
      setPlaceholderPlans(placeholderPlans);
    }
  }, [isLoading, error, plans]);
  
  useEffect(() => {
    // If there's only one plan, preselect it
    if (displayPlans.length === 1) {
      setSelectedPlan(displayPlans[0]);
    }
  }, [displayPlans]);
  
  const handleSelectPlan = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan);
    // If there's only one price option, preselect it
    if (plan.prices.length === 1) {
      setSelectedPrice(plan.prices[0]);
    } else {
      setSelectedPrice(null);
    }
  };
  
  const handleSelectPrice = (price: PriceOption) => {
    setSelectedPrice(price);
  };
  
  const handleContinue = () => {
    if (!user) {
      toast.error("Debe iniciar sesión para suscribirse");
      return;
    }
    
    if (!selectedPrice) {
      toast.error("Por favor seleccione un plan y período de facturación");
      return;
    }
    
    setShowCheckout(true);
  };
  
  const handleCheckoutSuccess = () => {
    toast.success("¡Suscripción completada con éxito!");
    setShowCheckout(false);
    // The user will be redirected to the success URL by the CheckoutForm
  };
  
  const handleCheckoutCancel = () => {
    setShowCheckout(false);
  };
  
  const formatPrice = (amount: number, currency: string) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0
    }).format(amount / 100);
  };
  
  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500 mx-auto"></div>
        <p className="mt-4 text-gray-600">Cargando planes de suscripción...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="p-6 text-center">
        <div className="text-red-500 text-xl mb-4">⚠️</div>
        <h3 className="text-lg font-medium">Error al cargar los planes</h3>
        <p className="mt-2 text-gray-600">No pudimos cargar los planes de suscripción. Por favor intente nuevamente más tarde.</p>
        <button
          onClick={() => fetchPlans()}
          className="mt-4 px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors"
        >
          Reintentar
        </button>
      </div>
    );
  }
  
  if (displayPlans.length === 0 && !isLoading) {
    return (
      <div className="p-6 text-center">
        <h3 className="text-lg font-medium">No hay planes disponibles</h3>
        <p className="mt-2 text-gray-600">Actualmente no hay planes de suscripción disponibles. Por favor intente más tarde.</p>
      </div>
    );
  }
  
  return (
    <div className="max-w-4xl mx-auto py-4">
      <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Planes de suscripción</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {displayPlans.map((plan) => (
          <div 
            key={plan.id}
            className={`border rounded-lg p-6 transition-all ${selectedPlan?.id === plan.id ? 'border-orange-500 ring-2 ring-orange-200' : 'border-gray-200 hover:border-orange-200'}`}
            onClick={() => handleSelectPlan(plan)}
          >
            <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
            <p className="text-gray-600 mb-4">{plan.description}</p>
            
            {plan.prices.map((price) => (
              <div key={price.id} className="mb-4">
                <div 
                  className={`flex items-center justify-between p-3 border rounded-md cursor-pointer transition-colors ${selectedPrice?.id === price.id ? 'bg-orange-50 border-orange-400' : 'bg-white border-gray-200 hover:bg-orange-50'}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSelectPrice(price);
                  }}
                >
                  <div>
                    <span className="font-medium">{price.name}</span>
                    <span className="block text-sm text-gray-500 capitalize">
                      {price.interval === 'month' ? 'Mensual' : price.interval === 'year' ? 'Anual' : price.interval}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-bold">{formatPrice(price.price, price.currency)}</span>
                    <span className="block text-xs text-gray-500">
                      {price.interval === 'month' ? '/mes' : price.interval === 'year' ? '/año' : `/${price.interval}`}
                    </span>
                  </div>
                </div>
              </div>
            ))}
            
            <ul className="mt-4 space-y-2">
              {(plan.prices[0]?.features.length > 0 ? plan.prices[0]?.features : [
                'Recepcionista virtual con IA',
                'Gestión de llamadas automática',
                'Personalización básica',
                '14 días de prueba gratis'
              ]).map((feature, index) => (
                <li key={index} className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      
      <div className="text-center">
        <button
          disabled={!selectedPrice}
          onClick={handleContinue}
          className={`px-6 py-3 rounded-md text-white font-medium transition-colors ${selectedPrice ? 'bg-orange-500 hover:bg-orange-600' : 'bg-gray-300 cursor-not-allowed'}`}
        >
          {isLoading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Procesando...
            </span>
          ) : (
            'Continuar con la suscripción'
          )}
        </button>
        
        <p className="mt-4 text-sm text-gray-500">
          Al continuar, podrás completar tu suscripción de forma segura.
          <span className="text-orange-600 font-medium block mt-1">Incluye 14 días de prueba gratis.</span>
        </p>
      </div>
      
      {/* Checkout Dialog */}
      <Dialog open={showCheckout} onOpenChange={setShowCheckout}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Complete su suscripción</DialogTitle>
            <DialogDescription>
              {selectedPlan && selectedPrice && (
                <div className="mt-2 text-sm">
                  <p className="font-semibold">{selectedPlan.name} - {selectedPrice.name}</p>
                  <p className="text-orange-600 font-medium">
                    {formatPrice(selectedPrice.price, selectedPrice.currency)}
                    <span className="text-gray-500 font-normal">/{selectedPrice.interval === 'month' ? 'mes' : 'año'}</span>
                  </p>
                  {['price_basic_monthly', 'price_basic_yearly',
                    'price_pro_monthly', 'price_pro_yearly',
                    'price_business_monthly', 'price_business_yearly'].includes(selectedPrice.price_id) && (
                    <p className="text-sm text-orange-500 mt-1 font-medium">Modo demostración</p>
                  )}
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          
          {selectedPrice && (
            <CheckoutForm
              price={selectedPrice}
              isDemo={['price_basic_monthly', 'price_basic_yearly',
                'price_pro_monthly', 'price_pro_yearly',
                'price_business_monthly', 'price_business_yearly'].includes(selectedPrice.price_id)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

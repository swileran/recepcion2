import React from 'react';
import { useTranslation } from 'react-i18next';

interface ErrorMessageProps {
  error?: string;
  onRetry?: () => void;
}

export function ErrorMessage({ error, onRetry }: ErrorMessageProps) {
  const { t } = useTranslation();
  
  return (
    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md my-4">
      <p>{error || t('common.error')}</p>
      {onRetry && (
        <button 
          onClick={onRetry}
          className="mt-2 text-sm font-medium text-red-600 hover:text-red-800"
        >
          {t('common.retry')}
        </button>
      )}
    </div>
  );
} 
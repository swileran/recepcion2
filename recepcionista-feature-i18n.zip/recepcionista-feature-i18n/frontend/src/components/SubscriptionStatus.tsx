import { useState, useEffect } from "react";
import { useProfileStore } from "../utils/store";
import { useSubscriptionStore } from "../utils/subscriptionStore";
import { useCurrentUser } from "app";
import { toast } from "sonner";

export function SubscriptionStatus() {
  const { user } = useCurrentUser();
  const { profile, updateProfile } = useProfileStore();
  const { 
    customerSubscription, 
    isLoading, 
    error, 
    fetchCustomerSubscription,
    createCustomerPortal,
    getCustomerIdForUser
  } = useSubscriptionStore();
  
  const [portalUrl, setPortalUrl] = useState<string | null>(null);
  const [loadingPortal, setLoadingPortal] = useState(false);
  
  useEffect(() => {
    const loadSubscriptionData = async () => {
      if (!user || !profile) return;
      
      // Check if we have a customer ID in the profile
      const customerId = profile.subscription?.stripeCustomerId || await getCustomerIdForUser(user.uid);
      
      if (customerId) {
        // If we have a customer ID, fetch subscription data
        await fetchCustomerSubscription(customerId);
        
        // If it's not already in the profile, update it
        if (!profile.subscription?.stripeCustomerId && profile.id) {
          await updateProfile(profile.id, {
            subscription: {
              ...profile.subscription,
              stripeCustomerId: customerId
            }
          });
        }
      }
    };
    
    loadSubscriptionData();
  }, [user, profile, fetchCustomerSubscription, getCustomerIdForUser, updateProfile]);
  
  const handleManageSubscription = async () => {
    if (!user || !profile || !customerSubscription) return;
    
    try {
      setLoadingPortal(true);
      
      // Create a customer portal session
      const result = await createCustomerPortal({
        customer_id: customerSubscription.customer_id,
        return_url: window.location.origin + "/dashboard?tab=suscripcion"
      });
      
      // Store the portal URL
      setPortalUrl(result.url);
      
      // Redirect to Stripe customer portal
      window.location.href = result.url;
    } catch (error) {
      console.error("Error creating customer portal:", error);
      toast.error("Error al abrir el portal de gestión. Por favor intente nuevamente.");
    } finally {
      setLoadingPortal(false);
    }
  };
  
  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  const formatPrice = (amount: number, currency: string) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0
    }).format(amount / 100);
  };
  
  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string, color: string }> = {
      active: { label: 'Activa', color: 'bg-green-100 text-green-800' },
      trialing: { label: 'Período de prueba', color: 'bg-blue-100 text-blue-800' },
      canceled: { label: 'Cancelada', color: 'bg-red-100 text-red-800' },
      incomplete: { label: 'Incompleta', color: 'bg-yellow-100 text-yellow-800' },
      incomplete_expired: { label: 'Expirada', color: 'bg-gray-100 text-gray-800' },
      past_due: { label: 'Pago pendiente', color: 'bg-orange-100 text-orange-800' },
      unpaid: { label: 'No pagada', color: 'bg-red-100 text-red-800' },
    };
    
    const statusInfo = statusMap[status] || { label: 'Desconocido', color: 'bg-gray-100 text-gray-800' };
    
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusInfo.color}`}>
        {statusInfo.label}
      </span>
    );
  };
  
  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500 mx-auto"></div>
        <p className="mt-4 text-gray-600">Cargando información de suscripción...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="p-6 text-center">
        <div className="text-red-500 text-xl mb-4">⚠️</div>
        <h3 className="text-lg font-medium">Error al cargar la suscripción</h3>
        <p className="mt-2 text-gray-600">No pudimos cargar la información de su suscripción. Por favor intente nuevamente más tarde.</p>
        <button
          onClick={() => customerSubscription && fetchCustomerSubscription(customerSubscription.customer_id)}
          className="mt-4 px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors"
        >
          Reintentar
        </button>
      </div>
    );
  }
  
  if (!customerSubscription || customerSubscription.subscriptions.length === 0) {
    return (
      <div className="p-6 bg-white rounded-lg shadow-sm">
        <div className="text-center py-8">
          <div className="text-orange-500 text-4xl mb-4">🔔</div>
          <h3 className="text-xl font-semibold text-gray-800">Sin suscripción activa</h3>
          <p className="mt-2 text-gray-600">Actualmente no tienes ninguna suscripción activa. Elige un plan para comenzar a usar todos los beneficios de Recepcionista AI.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-800">Estado de suscripción</h3>
      </div>
      
      <div className="p-6">
        {customerSubscription.subscriptions.map((subscription) => (
          <div key={subscription.subscription_id} className="mb-8 last:mb-0">
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="flex items-center">
                  <h4 className="text-lg font-medium">
                    Suscripción {subscription.subscription_id.slice(-8)}
                  </h4>
                  <div className="ml-3">
                    {getStatusBadge(subscription.status)}
                  </div>
                </div>
                <p className="text-gray-500 mt-1">
                  {formatPrice(subscription.amount, subscription.currency)}/{subscription.interval === 'month' ? 'mes' : 'año'}
                </p>
              </div>
              
              <div className="text-right">
                <div className="text-sm text-gray-500">Próxima facturación</div>
                <div className="font-medium">
                  {subscription.cancel_at_period_end ? 'Cancelado - ' : ''}
                  {formatDate(subscription.current_period_end)}
                </div>
              </div>
            </div>
            
            {subscription.status === 'active' && (
              <div className="mt-6">
                <button
                  onClick={handleManageSubscription}
                  disabled={loadingPortal}
                  className="inline-flex items-center px-4 py-2 border border-orange-500 rounded-md shadow-sm text-sm font-medium text-orange-600 bg-white hover:bg-orange-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 transition-colors"
                >
                  {loadingPortal ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-orange-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Cargando...
                    </>
                  ) : (
                    'Administrar suscripción'
                  )}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

import React, { useState, useEffect, useRef } from "react";
import { useWhatsAppStore, WhatsAppMessage } from "utils/whatsappStore";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Phone, Send, User, Check, CheckCheck, AlertCircle, Loader2, Settings } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import { WhatsAppTemplateSelector } from "./WhatsAppTemplateSelector";
import { WhatsAppConfig } from "./WhatsAppConfig";
import { useCurrentUser } from "app";

export interface WhatsAppMessageProps {
  message: WhatsAppMessage;
}

// Individual message component
const MessageBubble: React.FC<WhatsAppMessageProps> = ({ message }) => {
  const isBusinessSender = message.sender === "business";

  return (
    <div className={`flex ${isBusinessSender ? "justify-end" : "justify-start"} mb-4`}>
      <div className={`flex items-start max-w-[70%]`}>
        {!isBusinessSender && (
          <Avatar className="h-8 w-8 mr-2">
            <User className="h-4 w-4" />
          </Avatar>
        )}
        <div className="flex flex-col">
          <div 
            className={`px-4 py-2 rounded-lg ${isBusinessSender 
              ? "bg-primary text-primary-foreground rounded-tr-none" 
              : "bg-muted text-muted-foreground rounded-tl-none"}`}
          >
            <p className="whitespace-pre-wrap">{message.body}</p>
          </div>
          <div className={`text-xs text-muted-foreground mt-1 flex items-center ${isBusinessSender ? "justify-end" : "justify-start"}`}>
            <span className="mr-1">{formatDistanceToNow(message.timestamp, { addSuffix: true, locale: es })}</span>
            {isBusinessSender && (
              <>
                {message.status === "sent" && <Check className="h-3 w-3" />}
                {message.status === "delivered" && <CheckCheck className="h-3 w-3" />}
                {message.status === "read" && <CheckCheck className="h-3 w-3 text-blue-500" />}
                {message.status === "failed" && <AlertCircle className="h-3 w-3 text-destructive" />}
              </>
            )}
          </div>
        </div>
        {isBusinessSender && (
          <Avatar className="h-8 w-8 ml-2 bg-primary">
            <Phone className="h-4 w-4" />
          </Avatar>
        )}
      </div>
    </div>
  );
};

// Conversation component
export interface ConversationProps {
  phoneNumber?: string;
}

const ConversationView: React.FC<ConversationProps> = ({ phoneNumber }) => {
  const [messageText, setMessageText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { 
    messages, 
    activePhone, 
    isLoading, 
    sendMessage,
    setActivePhone 
  } = useWhatsAppStore();

  const activePhoneNumber = phoneNumber || activePhone;
  const currentMessages = activePhoneNumber ? (messages[activePhoneNumber] || []) : [];

  // Set active phone if provided via props
  useEffect(() => {
    if (phoneNumber && phoneNumber !== activePhone) {
      setActivePhone(phoneNumber);
    }
  }, [phoneNumber, activePhone, setActivePhone]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [currentMessages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !activePhoneNumber) return;

    sendMessage(activePhoneNumber, messageText);
    setMessageText("");
  };

  if (!activePhoneNumber) {
    return (
      <Card className="h-full flex flex-col">
        <CardContent className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Phone className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Seleccione una conversación o inicie una nueva</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2 pt-4">
        <div className="flex items-center">
          <Avatar className="h-8 w-8 mr-2">
            <User className="h-4 w-4" />
          </Avatar>
          <div>
            <CardTitle className="text-base">{activePhoneNumber}</CardTitle>
            <p className="text-xs text-muted-foreground">WhatsApp</p>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
        {currentMessages.length === 0 ? (
          <div className="h-full flex items-center justify-center">
            <p className="text-muted-foreground">No hay mensajes todavía</p>
          </div>
        ) : (
          currentMessages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))
        )}
        <div ref={messagesEndRef} />
      </CardContent>
      
      <CardFooter className="p-4 pt-2">
        <form onSubmit={handleSendMessage} className="flex w-full gap-2">
          <Input
            placeholder="Escribe un mensaje..."
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            className="flex-1"
            disabled={isLoading}
          />
          <WhatsAppTemplateSelector phoneNumber={activePhoneNumber} />
          <Button type="submit" size="icon" disabled={isLoading || !messageText.trim()}>
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
};

// Contact list component
export interface ContactListProps {
  onSelectContact: (phone: string) => void;
}

const ContactList: React.FC<ContactListProps> = ({ onSelectContact }) => {
  const { messages, activePhone, setActivePhone } = useWhatsAppStore();
  
  const contacts = Object.keys(messages).map(phone => {
    const conversationMessages = messages[phone];
    const lastMessage = conversationMessages[conversationMessages.length - 1];
    const unreadCount = conversationMessages.filter(m => 
      m.sender === "user" && m.status !== "read"
    ).length;
    
    return { phone, lastMessage, unreadCount };
  });

  const handleSelectContact = (phone: string) => {
    setActivePhone(phone);
    onSelectContact(phone);
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-2 pt-4">
        <CardTitle className="text-lg">Conversaciones</CardTitle>
      </CardHeader>
      <CardContent className="p-2">
        {contacts.length === 0 ? (
          <div className="text-center py-8">
            <Phone className="mx-auto h-10 w-10 text-muted-foreground mb-2" />
            <p className="text-muted-foreground">No hay conversaciones activas</p>
          </div>
        ) : (
          <div className="space-y-1">
            {contacts.map(({ phone, lastMessage, unreadCount }) => (
              <div 
                key={phone} 
                className={`p-3 rounded-lg cursor-pointer flex items-center ${phone === activePhone ? "bg-muted" : "hover:bg-accent"}`}
                onClick={() => handleSelectContact(phone)}
              >
                <Avatar className="h-10 w-10 mr-3">
                  <User className="h-5 w-5" />
                </Avatar>
                <div className="flex-1 overflow-hidden">
                  <div className="flex justify-between items-center">
                    <p className="font-medium truncate">{phone}</p>
                    <p className="text-xs text-muted-foreground">
                      {lastMessage ? 
                        formatDistanceToNow(lastMessage.timestamp, { addSuffix: false, locale: es }) : ""}
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground truncate">
                    {lastMessage?.body || "No hay mensajes"}
                  </p>
                </div>
                {unreadCount > 0 && (
                  <Badge variant="default" className="ml-2">
                    {unreadCount}
                  </Badge>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// New chat component
export interface NewChatProps {
  onStartChat: (phone: string) => void;
}

const NewChat: React.FC<NewChatProps> = ({ onStartChat }) => {
  const [phoneNumber, setPhoneNumber] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber.trim()) return;
    
    onStartChat(phoneNumber);
    setPhoneNumber("");
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Nuevo Chat</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="phone-number" className="text-sm font-medium">
              Número de teléfono
            </label>
            <Input
              id="phone-number"
              placeholder="+1XXXXXXXXXX"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Introduce el número completo con el código de país (ej. +1 para EE.UU/Canadá, +52 para México)
            </p>
          </div>
          <Button type="submit" className="w-full" disabled={!phoneNumber.trim()}>
            Iniciar conversación
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

// Main WhatsApp component that combines all the above
export interface Props {
  defaultPhoneNumber?: string;
}

export const WhatsAppInterface: React.FC<Props> = ({ defaultPhoneNumber }) => {
  const [selectedPhone, setSelectedPhone] = useState<string | undefined>(defaultPhoneNumber);
  const { fetchConversations, setActivePhone } = useWhatsAppStore();
  const [showConfig, setShowConfig] = useState(false);
  const { user } = useCurrentUser();
  
  useEffect(() => {
    if (user) {
      useWhatsAppStore.getState().setUser(user);
      fetchConversations();
    }
    
    if (defaultPhoneNumber) {
      setActivePhone(defaultPhoneNumber);
      setSelectedPhone(defaultPhoneNumber);
    }
  }, [fetchConversations, defaultPhoneNumber, setActivePhone, user]);
  
  const handleSelectContact = (phone: string) => {
    setSelectedPhone(phone);
  };
  
  const handleStartChat = (phone: string) => {
    setSelectedPhone(phone);
    setActivePhone(phone);
  };
  
  return (
    <div className="h-full">
      {showConfig ? (
        <div className="mb-4">
          <div className="flex justify-end mb-4">
            <Button variant="outline" onClick={() => setShowConfig(false)}>
              Volver a mensajes
            </Button>
          </div>
          <WhatsAppConfig onConfigured={() => setShowConfig(false)} />
        </div>
      ) : (
        <Tabs defaultValue="chats" className="h-full flex flex-col">
          <div className="flex justify-between items-center mb-4">
            <TabsList className="mx-auto">
              <TabsTrigger value="chats">Conversaciones</TabsTrigger>
              <TabsTrigger value="new">Nuevo chat</TabsTrigger>
            </TabsList>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setShowConfig(true)}
              className="ml-auto"
            >
              <Settings className="h-4 w-4 mr-2" />
              Configurar
            </Button>
          </div>
          
          <div className="flex-1 overflow-hidden">
            <TabsContent value="chats" className="h-full">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-full">
                <div className="hidden md:block">
                  <ContactList onSelectContact={handleSelectContact} />
                </div>
                <div className="md:col-span-2 h-full">
                  <ConversationView phoneNumber={selectedPhone} />
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="new">
              <div className="max-w-md mx-auto">
                <NewChat onStartChat={handleStartChat} />
              </div>
            </TabsContent>
          </div>
        </Tabs>
      )}
    </div>
  );
};

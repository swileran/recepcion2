import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useWhatsAppStore, formatPhone } from "utils/whatsappStore";
import { WhatsAppTemplate } from "types";
import { toast } from "sonner";

interface TemplateParam {
  name: string;
  value: string;
}

const defaultTemplates = [
  {
    id: "appointment_reminder",
    name: "cita_recordatorio",
    description: "Recordatorio de cita",
    params: [
      { name: "1", label: "Nombre del cliente", value: "" },
      { name: "2", label: "Fecha de la cita", value: "" },
      { name: "3", label: "Hora de la cita", value: "" },
    ]
  },
  {
    id: "service_confirmation",
    name: "servicio_confirmacion",
    description: "Confirmación de servicio",
    params: [
      { name: "1", label: "Nombre del cliente", value: "" },
      { name: "2", label: "Tipo de servicio", value: "" },
      { name: "3", label: "Fecha del servicio", value: "" },
    ]
  },
  {
    id: "welcome_message",
    name: "bienvenida",
    description: "Mensaje de bienvenida",
    params: [
      { name: "1", label: "Nombre del cliente", value: "" },
      { name: "2", label: "Nombre del negocio", value: "" },
    ]
  },
  {
    id: "follow_up",
    name: "seguimiento",
    description: "Mensaje de seguimiento",
    params: [
      { name: "1", label: "Nombre del cliente", value: "" },
      { name: "2", label: "Servicio previo", value: "" },
    ]
  }
];

export interface Props {
  phoneNumber: string;
  onMessageSent?: () => void;
}

export const WhatsAppTemplateSelector: React.FC<Props> = ({ phoneNumber, onMessageSent }) => {
  const { sendTemplateMessage } = useWhatsAppStore();
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [templateParams, setTemplateParams] = useState<TemplateParam[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isSending, setIsSending] = useState(false);
  
  const handleTemplateChange = (templateId: string) => {
    setSelectedTemplate(templateId);
    
    const template = defaultTemplates.find(t => t.id === templateId);
    if (template) {
      setTemplateParams(template.params.map(p => ({ name: p.name, value: p.value })));
    } else {
      setTemplateParams([]);
    }
  };
  
  const handleParamChange = (index: number, value: string) => {
    const newParams = [...templateParams];
    newParams[index].value = value;
    setTemplateParams(newParams);
  };
  
  const handleSendTemplate = async () => {
    if (!selectedTemplate) {
      toast.error("Por favor seleccione una plantilla");
      return;
    }
    
    const template = defaultTemplates.find(t => t.id === selectedTemplate);
    if (!template) {
      toast.error("Plantilla no encontrada");
      return;
    }
    
    // Check if all required parameters are filled
    const missingParams = templateParams.filter(p => !p.value.trim());
    if (missingParams.length > 0) {
      toast.error("Por favor complete todos los parámetros de la plantilla");
      return;
    }
    
    setIsSending(true);
    
    try {
      // Format parameters as required by the WhatsApp API
      const formattedParams = templateParams.reduce((acc, curr) => {
        acc[curr.name] = curr.value;
        return acc;
      }, {} as Record<string, string>);
      
      const whatsappTemplate: WhatsAppTemplate = {
        name: template.name,
        language_code: "es",
        parameters: [formattedParams]
      };
      
      await sendTemplateMessage(phoneNumber, whatsappTemplate);
      toast.success("Plantilla enviada con éxito");
      
      // Reset form and close dialog
      setSelectedTemplate("");
      setTemplateParams([]);
      setIsDialogOpen(false);
      
      if (onMessageSent) {
        onMessageSent();
      }
    } catch (error) {
      toast.error("Error al enviar la plantilla: " + String(error));
    } finally {
      setIsSending(false);
    }
  };
  
  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          Usar plantilla
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Enviar mensaje de plantilla</DialogTitle>
          <DialogDescription>
            Seleccione una plantilla y complete los parámetros para enviar un mensaje estructurado a WhatsApp.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="template">Tipo de plantilla</Label>
            <Select
              value={selectedTemplate}
              onValueChange={handleTemplateChange}
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar plantilla" />
              </SelectTrigger>
              <SelectContent>
                {defaultTemplates.map(template => (
                  <SelectItem key={template.id} value={template.id}>
                    {template.description}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {selectedTemplate && templateParams.length > 0 && (
            <div className="space-y-3">
              <Label>Parámetros</Label>
              {templateParams.map((param, index) => {
                const templateParam = defaultTemplates
                  .find(t => t.id === selectedTemplate)?.params[index];
                
                return (
                  <div key={index} className="space-y-1">
                    <Label htmlFor={`param-${index}`} className="text-sm text-muted-foreground">
                      {templateParam?.label || `Parámetro ${index + 1}`}
                    </Label>
                    <Input
                      id={`param-${index}`}
                      value={param.value}
                      onChange={(e) => handleParamChange(index, e.target.value)}
                      placeholder={`Ingrese ${templateParam?.label || `parámetro ${index + 1}`}`}
                    />
                  </div>
                );
              })}
            </div>
          )}
        </div>
        
        <DialogFooter className="sm:justify-between">
          <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
            Cancelar
          </Button>
          <Button 
            onClick={handleSendTemplate} 
            disabled={!selectedTemplate || isSending}
            className="bg-orange-500 hover:bg-orange-600"
          >
            {isSending ? "Enviando..." : "Enviar plantilla"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

import { useState, useEffect } from "react";
import { useCurrentUser } from "app";
import { useProfileStore } from "../utils/store";
import { FiSave, FiX, FiPlus, FiTrash, FiPlay, FiPause } from "react-icons/fi";
import brain from "brain";

interface FAQ {
  question: string;
  answer: string;
}

interface FormErrors {
  greetingMessage?: string;
  farewellMessage?: string;
  confirmationMessage?: string;
  faqs?: string;
  voice?: string;
}

interface Voice {
  id: string;
  name: string;
  voice_id: string;
  region?: string;
  description?: string;
  gender?: string;
  style?: string;
}

export function VoiceAgentConfigForm() {
  const { user } = useCurrentUser();
  const { profile, updateProfile, isLoading, error } = useProfileStore();
  
  const [formErrors, setFormErrors] = useState<FormErrors>({});
  const [formSuccess, setFormSuccess] = useState("");
  
  // Voice options state
  const [voiceOptions, setVoiceOptions] = useState<Voice[]>([]);
  const [voicesByRegion, setVoicesByRegion] = useState<Record<string, Voice[]>>({});
  const [voicesLoading, setVoicesLoading] = useState(true);
  const [playingVoice, setPlayingVoice] = useState<string | null>(null);
  const [audioRef, setAudioRef] = useState<HTMLAudioElement | null>(null);
  const [sampleType, setSampleType] = useState<string>("greeting");
  
  // Form state
  const [voice, setVoice] = useState("");
  const [greetingMessage, setGreetingMessage] = useState("");
  const [farewellMessage, setFarewellMessage] = useState("");
  const [confirmationMessage, setConfirmationMessage] = useState("");
  const [faqs, setFaqs] = useState<FAQ[]>([{ question: "", answer: "" }]);
  
  useEffect(() => {
    // Fetch voice options from the API
    const fetchVoices = async () => {
      try {
        setVoicesLoading(true);
        const response = await brain.get_voice_options();
        const data = await response.json();
        setVoiceOptions(data.voices);
        
        // Group voices by region
        const groupedVoices: Record<string, Voice[]> = {};
        data.voices.forEach((voice: Voice) => {
          if (voice.region) {
            if (!groupedVoices[voice.region]) {
              groupedVoices[voice.region] = [];
            }
            groupedVoices[voice.region].push(voice);
          }
        });
        setVoicesByRegion(groupedVoices);
      } catch (error) {
        console.error("Error fetching voice options:", error);
      } finally {
        setVoicesLoading(false);
      }
    };
    
    fetchVoices();
    
    // Create audio element for voice samples
    const audio = new Audio();
    setAudioRef(audio);
    
    // Cleanup audio on unmount
    return () => {
      if (audioRef) {
        audioRef.pause();
        audioRef.src = "";
      }
    };
  }, []);
  
  // Set default voice when voice options are loaded
  useEffect(() => {
    if (!voice && voiceOptions.length > 0 && !profile?.voiceAgent?.voice) {
      // Default to the first voice
      setVoice(voiceOptions[0].id);
    }
  }, [voiceOptions, voice, profile]);
  
  useEffect(() => {
    if (profile?.voiceAgent) {
      setVoice(profile.voiceAgent.voice || "");
      setGreetingMessage(profile.voiceAgent.greetingMessage || "");
      setFarewellMessage(profile.voiceAgent.farewellMessage || "");
      setConfirmationMessage(profile.voiceAgent.confirmationMessage || "");
      
      if (profile.voiceAgent.faqs && profile.voiceAgent.faqs.length > 0) {
        setFaqs(profile.voiceAgent.faqs);
      }
    } else {
      // Set defaults if no voice agent configuration exists
      // We'll set the voice after the voice options are loaded
      
      // Default greeting for specific business types
      if (profile?.businessType) {
        if (profile.businessType.includes("Peluquería")) {
          setGreetingMessage(`Hola, has llamado a ${profile.businessName}. Soy la recepcionista virtual. ¿En qué puedo ayudarte hoy? ¿Deseas agendar una cita para un corte de pelo o quieres información sobre nuestros servicios?`);
        } else if (profile.businessType.includes("Restaurante")) {
          setGreetingMessage(`Gracias por llamar a ${profile.businessName}. Soy la recepcionista virtual. ¿Deseas hacer una reserva o quieres información sobre nuestro menú?`);
        } else if (profile.businessType.includes("Taller")) {
          setGreetingMessage(`Bienvenido a ${profile.businessName}. Soy la recepcionista virtual. ¿Necesitas agendar una cita para tu vehículo o tienes alguna consulta sobre nuestros servicios?`);
        } else {
          setGreetingMessage(`Bienvenido a ${profile.businessName}. Soy la recepcionista virtual. ¿Cómo puedo ayudarte hoy?`);
        }
      } else {
        setGreetingMessage("Bienvenido a nuestra empresa. Soy la recepcionista virtual. ¿Cómo puedo ayudarte hoy?");
      }
      
      setFarewellMessage("Gracias por contactarnos. Esperamos verte pronto. ¡Que tengas un excelente día!");
      setConfirmationMessage("He agendado tu cita. Te enviaré una confirmación por mensaje de texto. ¿Hay algo más en lo que pueda ayudarte?");
    }
  }, [profile]);
  
  const validateForm = (): boolean => {
    const errors: FormErrors = {};
    
    if (!voice) {
      errors.voice = "Debes seleccionar una voz";
    }
    
    if (!greetingMessage.trim()) {
      errors.greetingMessage = "El mensaje de bienvenida es obligatorio";
    }
    
    if (!farewellMessage.trim()) {
      errors.farewellMessage = "El mensaje de despedida es obligatorio";
    }
    
    if (!confirmationMessage.trim()) {
      errors.confirmationMessage = "El mensaje de confirmación es obligatorio";
    }
    
    // Validate FAQs - each FAQ should have both question and answer
    const hasIncompleteFaq = faqs.some(faq => 
      (faq.question.trim() !== "" && faq.answer.trim() === "") || 
      (faq.question.trim() === "" && faq.answer.trim() !== "")
    );
    
    if (hasIncompleteFaq) {
      errors.faqs = "Todas las preguntas frecuentes deben tener pregunta y respuesta";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const handleAddFaq = () => {
    setFaqs([...faqs, { question: "", answer: "" }]);
  };
  
  const handleRemoveFaq = (index: number) => {
    const updatedFaqs = [...faqs];
    updatedFaqs.splice(index, 1);
    setFaqs(updatedFaqs);
  };
  
  const handleFaqChange = (index: number, field: keyof FAQ, value: string) => {
    const updatedFaqs = [...faqs];
    updatedFaqs[index][field] = value;
    setFaqs(updatedFaqs);
  };
  
  const handlePlayVoice = async (voiceId: string) => {
    try {
      // If already playing this voice, stop it
      if (playingVoice === voiceId && audioRef) {
        audioRef.pause();
        setPlayingVoice(null);
        return;
      }
      
      // If playing another voice, stop it
      if (audioRef && audioRef.src) {
        audioRef.pause();
      }
      
      setPlayingVoice(voiceId);
      
      // Request voice sample from API with the current sample type
      const response = await brain.get_voice_sample({
        voice_id: voiceId,
        sample_type: sampleType
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        if (response.status === 401 && errorData.detail && errorData.detail.includes("invalid_api_key")) {
          throw new Error("No se pudo reproducir la muestra de voz: API key de ElevenLabs inválida. Por favor, configure una API key válida en la sección de Secretos.");
        } else {
          throw new Error(`Error al reproducir la muestra de voz: ${errorData.detail || response.statusText}`);
        }
      }
      
      const data = await response.json();
      
      // Convert base64 to audio
      const audioBlob = base64ToBlob(data.audio_base64, "audio/mpeg");
      const audioUrl = URL.createObjectURL(audioBlob);
      
      if (audioRef) {
        audioRef.src = audioUrl;
        audioRef.onended = () => {
          setPlayingVoice(null);
          URL.revokeObjectURL(audioUrl);
        };
        audioRef.play();
      }
    } catch (error) {
      console.error("Error playing voice sample:", error);
      setPlayingVoice(null);
      // Show error message to user
      const errorMessage = error instanceof Error ? error.message : "Error al reproducir la muestra de voz";
      setFormErrors({
        ...formErrors,
        voice: errorMessage
      });
      
      // Auto-dismiss error after 8 seconds
      setTimeout(() => {
        setFormErrors({
          ...formErrors,
          voice: undefined
        });
      }, 8000);
    }
  };
  
  // Helper function to convert base64 to blob
  const base64ToBlob = (base64: string, mimeType: string) => {
    const byteCharacters = atob(base64);
    const byteArrays = [];
    
    for (let i = 0; i < byteCharacters.length; i += 512) {
      const slice = byteCharacters.slice(i, i + 512);
      
      const byteNumbers = new Array(slice.length);
      for (let j = 0; j < slice.length; j++) {
        byteNumbers[j] = slice.charCodeAt(j);
      }
      
      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    
    return new Blob(byteArrays, { type: mimeType });
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSuccess("");
    
    if (!validateForm()) {
      return;
    }
    
    if (!profile?.id || !user) {
      return;
    }
    
    try {
      // Only include non-empty FAQs
      const filteredFaqs = faqs.filter(faq => faq.question.trim() !== "" && faq.answer.trim() !== "");
      
      // Find the selected voice option to get the voice_id
      const selectedVoice = voiceOptions.find(v => v.id === voice);
      
      // Prepare voice agent data
      const voiceAgentData = {
        voice,
        voice_id: selectedVoice?.voice_id, // Store ElevenLabs voice ID
        greetingMessage,
        farewellMessage,
        confirmationMessage,
        faqs: filteredFaqs
      };
      
      // Update profile with voice agent configuration
      await updateProfile(profile.id, {
        voiceAgent: voiceAgentData
      });
      
      setFormSuccess("Configuración de voz guardada con éxito");
      
      // Clear errors on success
      setFormErrors({});
      
      // Auto-dismiss success message after 5 seconds
      setTimeout(() => setFormSuccess(""), 5000);
      
    } catch (error) {
      console.error("Error saving voice agent configuration:", error);
      const errorMessage = error instanceof Error ? error.message : "Error al guardar la configuración. Inténtalo de nuevo.";
      setFormErrors({ ...formErrors, voice: errorMessage });
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Success message */}
        {formSuccess && (
          <div className="bg-green-50 border border-green-200 text-green-800 rounded-md p-4 flex justify-between items-center">
            <p>{formSuccess}</p>
            <button 
              type="button" 
              onClick={() => setFormSuccess("")}
              className="text-green-600 hover:text-green-800"
            >
              <FiX size={20} />
            </button>
          </div>
        )}
        
        {/* Error message from store */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4">
            <p>{error.message}</p>
          </div>
        )}
        
          {/* Voice Selection */}
          <div className="bg-white shadow rounded-lg p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Selección de Voz</h3>
              
              <div className="flex items-center space-x-2">
                <label htmlFor="sampleType" className="text-sm font-medium text-gray-700">Ejemplo:</label>
                <select 
                  id="sampleType" 
                  value={sampleType} 
                  onChange={(e) => setSampleType(e.target.value)}
                  className="text-sm border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500"
                >
                  <option value="greeting">Saludo</option>
                  <option value="farewell">Despedida</option>
                  <option value="confirmation">Confirmación</option>
                  <option value="businessInfo">Info del negocio</option>
                </select>
              </div>
            </div>
            
            {formErrors.voice && (
              <div className="mb-4 p-3 border border-red-300 bg-red-50 rounded-md text-sm text-red-700">
                {formErrors.voice}
                {formErrors.voice.includes("API key") && (
                  <p className="mt-1">
                    Para configurar la API key, ve a la sección de Config y Secrets y añade una clave válida de ElevenLabs.
                  </p>
                )}
              </div>
            )}
            
            {voicesLoading ? (
              <div className="flex justify-center p-6">
                <svg className="animate-spin h-8 w-8 text-orange-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              </div>
            ) : (
              <div className="space-y-8">
                {Object.keys(voicesByRegion).length > 0 ? (
                  // Group voices by region
                  Object.entries(voicesByRegion).map(([region, regionVoices]) => (
                    <div key={region} className="space-y-4">
                      <h4 className="text-md font-semibold text-gray-800 border-b pb-2">{region}</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {regionVoices.map((voiceOption) => (
                          <div 
                            key={voiceOption.id}
                            className={`border rounded-lg p-4 flex flex-col ${voice === voiceOption.id ? 'border-orange-500 bg-orange-50' : 'border-gray-200'}`}
                          >
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center">
                                <input
                                  type="radio"
                                  id={`voice-${voiceOption.id}`}
                                  name="voice"
                                  value={voiceOption.id}
                                  checked={voice === voiceOption.id}
                                  onChange={() => setVoice(voiceOption.id)}
                                  className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300"
                                />
                                <label htmlFor={`voice-${voiceOption.id}`} className="ml-3 block text-sm font-medium text-gray-700">
                                  {voiceOption.name}
                                </label>
                              </div>
                              
                              <button
                                type="button"
                                onClick={() => handlePlayVoice(voiceOption.id)}
                                className="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md text-orange-700 bg-orange-100 hover:bg-orange-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
                                disabled={playingVoice !== null && playingVoice !== voiceOption.id}
                              >
                                {playingVoice === voiceOption.id ? (
                                  <>
                                    <svg className="animate-spin -ml-1 mr-1 h-4 w-4 text-orange-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    Reproduciendo...
                                  </>
                                ) : (
                                  <>
                                    <FiPlay className="mr-1" />
                                    Escuchar
                                  </>
                                )}
                              </button>
                            </div>
                            
                            {voiceOption.description && (
                              <p className="text-xs text-gray-500 mt-1">{voiceOption.description}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                ) : (
                  // Fallback to flat list if no regions
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {voiceOptions.map((voiceOption) => (
                      <div 
                        key={voiceOption.id}
                        className={`border rounded-lg p-4 flex items-center justify-between ${
                          voice === voiceOption.id ? 'border-orange-500 bg-orange-50' : 'border-gray-200'
                        }`}
                      >
                        <div className="flex items-center">
                          <input
                            type="radio"
                            id={`voice-${voiceOption.id}`}
                            name="voice"
                            value={voiceOption.id}
                            checked={voice === voiceOption.id}
                            onChange={() => setVoice(voiceOption.id)}
                            className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300"
                          />
                          <label htmlFor={`voice-${voiceOption.id}`} className="ml-3 block text-sm font-medium text-gray-700">
                            {voiceOption.name}
                          </label>
                        </div>
                        
                        <button
                          type="button"
                          onClick={() => handlePlayVoice(voiceOption.id)}
                          className="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md text-orange-700 bg-orange-100 hover:bg-orange-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
                          disabled={playingVoice !== null && playingVoice !== voiceOption.id}
                        >
                          {playingVoice === voiceOption.id ? (
                            <>
                              <svg className="animate-spin -ml-1 mr-1 h-4 w-4 text-orange-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              Reproduciendo...
                            </>
                          ) : (
                            <>
                              <FiPlay className="mr-1" />
                              Escuchar
                            </>
                          )}
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        
        {/* Greeting Message */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Mensaje de Bienvenida</h3>
          <p className="text-sm text-gray-500 mb-4">
            Este es el primer mensaje que escuchará el cliente cuando llame. Debe ser amable y explicar brevemente quién eres y cómo puedes ayudar.
          </p>
          
          <textarea
            id="greetingMessage"
            value={greetingMessage}
            onChange={(e) => setGreetingMessage(e.target.value)}
            rows={4}
            className={`w-full px-3 py-2 border ${formErrors.greetingMessage ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
            placeholder="Ej: Bienvenido a [Nombre de tu negocio]. Soy la recepcionista virtual. ¿Cómo puedo ayudarte hoy?"
          />
          {formErrors.greetingMessage && (
            <p className="mt-1 text-sm text-red-600">{formErrors.greetingMessage}</p>
          )}
        </div>
        
        {/* FAQs */}
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-gray-900">Preguntas Frecuentes</h3>
            <button
              type="button"
              onClick={handleAddFaq}
              className="flex items-center text-sm font-medium text-orange-600 hover:text-orange-700"
            >
              <FiPlus className="mr-1" size={16} />
              Añadir pregunta
            </button>
          </div>
          
          <p className="text-sm text-gray-500 mb-4">
            Configura las preguntas frecuentes que tu recepcionista virtual debe conocer para responder a tus clientes.
          </p>
          
          {formErrors.faqs && (
            <div className="mb-4 text-sm text-red-600">{formErrors.faqs}</div>
          )}
          
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-gray-200 rounded-md p-4">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="text-sm font-medium text-gray-700">Pregunta y Respuesta #{index + 1}</h4>
                  
                  {faqs.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveFaq(index)}
                      className="text-red-500 hover:text-red-700"
                      aria-label="Eliminar pregunta"
                    >
                      <FiTrash size={16} />
                    </button>
                  )}
                </div>
                
                <div className="space-y-3">
                  <div>
                    <label htmlFor={`faq-question-${index}`} className="block text-sm font-medium text-gray-700 mb-1">
                      Pregunta
                    </label>
                    <input
                      type="text"
                      id={`faq-question-${index}`}
                      value={faq.question}
                      onChange={(e) => handleFaqChange(index, 'question', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                      placeholder="Ej: ¿Cuáles son sus horarios de atención?"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor={`faq-answer-${index}`} className="block text-sm font-medium text-gray-700 mb-1">
                      Respuesta
                    </label>
                    <textarea
                      id={`faq-answer-${index}`}
                      value={faq.answer}
                      onChange={(e) => handleFaqChange(index, 'answer', e.target.value)}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                      placeholder="Ej: Nuestro horario de atención es de lunes a viernes de 9:00 a 18:00 y sábados de 10:00 a 14:00."
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Confirmation Message */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Mensaje de Confirmación de Cita</h3>
          <p className="text-sm text-gray-500 mb-4">
            Este mensaje se reproduce cuando un cliente agenda una cita. Debe confirmar los detalles y explicar los siguientes pasos.
          </p>
          
          <textarea
            id="confirmationMessage"
            value={confirmationMessage}
            onChange={(e) => setConfirmationMessage(e.target.value)}
            rows={3}
            className={`w-full px-3 py-2 border ${formErrors.confirmationMessage ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
            placeholder="Ej: Perfecto, he agendado tu cita. Recibirás una confirmación por mensaje de texto. ¿Hay algo más en lo que pueda ayudarte?"
          />
          {formErrors.confirmationMessage && (
            <p className="mt-1 text-sm text-red-600">{formErrors.confirmationMessage}</p>
          )}
        </div>
        
        {/* Farewell Message */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Mensaje de Despedida</h3>
          <p className="text-sm text-gray-500 mb-4">
            Este es el último mensaje que escuchará el cliente antes de finalizar la llamada. Debe ser cordial y agradecer por contactar.
          </p>
          
          <textarea
            id="farewellMessage"
            value={farewellMessage}
            onChange={(e) => setFarewellMessage(e.target.value)}
            rows={3}
            className={`w-full px-3 py-2 border ${formErrors.farewellMessage ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
            placeholder="Ej: Gracias por contactarnos. Esperamos verte pronto. ¡Que tengas un excelente día!"
          />
          {formErrors.farewellMessage && (
            <p className="mt-1 text-sm text-red-600">{formErrors.farewellMessage}</p>
          )}
        </div>
        
        {/* Submit Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isLoading}
            className="px-6 py-3 bg-orange-600 text-white font-medium rounded-md shadow hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 flex items-center disabled:bg-gray-400"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Guardando...
              </>
            ) : (
              <>
                <FiSave className="mr-2" size={18} />
                Guardar configuración
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
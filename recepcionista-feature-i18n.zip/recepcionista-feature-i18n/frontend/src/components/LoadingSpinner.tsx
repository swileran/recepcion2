import React from 'react';
import { useTranslation } from 'react-i18next';

interface LoadingSpinnerProps {
  size?: 'small' | 'medium' | 'large';
  showText?: boolean;
}

export function LoadingSpinner({ size = 'medium', showText = true }: LoadingSpinnerProps) {
  const { t } = useTranslation();
  
  const sizeClasses = {
    small: 'w-4 h-4',
    medium: 'w-8 h-8',
    large: 'w-12 h-12'
  };
  
  return (
    <div className="flex flex-col items-center justify-center py-4">
      <div className={`${sizeClasses[size]} border-4 border-gray-200 border-t-orange-500 rounded-full animate-spin`}></div>
      {showText && <p className="mt-2 text-gray-600">{t('common.loading')}</p>}
    </div>
  );
} 
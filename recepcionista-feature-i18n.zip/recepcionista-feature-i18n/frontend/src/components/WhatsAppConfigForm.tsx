import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Check, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import brain from "brain";

interface FormErrors {
  accountSid?: string;
  authToken?: string;
  phoneNumber?: string;
}

interface WhatsAppConfig {
  accountSid: string;
  authToken: string;
  phoneNumber: string;
}

interface ConfigStatus {
  status: "operational" | "error" | "pending" | "loading";
  message?: string;
  provider?: string;
  whatsappNumber?: string;
}

export interface Props {
  onConfigured?: () => void;
}

export const WhatsAppConfigForm: React.FC<Props> = ({ onConfigured }) => {
  const [formData, setFormData] = useState<WhatsAppConfig>({
    accountSid: "",
    authToken: "",
    phoneNumber: "",
  });
  
  const [formErrors, setFormErrors] = useState<FormErrors>({});
  const [isLoading, setIsLoading] = useState(false);
  const [configStatus, setConfigStatus] = useState<ConfigStatus>({
    status: "loading"
  });
  
  // Check the current status of the WhatsApp integration
  const checkStatus = async () => {
    try {
      setConfigStatus({ status: "loading" });
      const response = await brain.check_whatsapp_status();
      const data = await response.json();
      
      if (data.status === "operational") {
        setConfigStatus({
          status: "operational",
          message: "WhatsApp API conectada y operativa",
          provider: data.provider,
          whatsappNumber: data.whatsapp_number
        });
      } else {
        setConfigStatus({
          status: "error",
          message: data.message || "Error en la configuración de WhatsApp"
        });
      }
    } catch (error) {
      setConfigStatus({
        status: "error",
        message: "No se pudo verificar el estado de la API de WhatsApp"
      });
    }
  };
  
  // Load status on component mount
  useEffect(() => {
    checkStatus();
  }, []);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    
    // Clear error when user types
    if (formErrors[name as keyof FormErrors]) {
      setFormErrors({ ...formErrors, [name]: undefined });
    }
  };
  
  const validateForm = () => {
    const errors: FormErrors = {};
    
    if (!formData.accountSid.trim()) {
      errors.accountSid = "El Account SID es requerido";
    } else if (!formData.accountSid.startsWith("AC")) {
      errors.accountSid = "El Account SID debe comenzar con 'AC'";
    }
    
    if (!formData.authToken.trim()) {
      errors.authToken = "El Auth Token es requerido";
    }
    
    if (!formData.phoneNumber.trim()) {
      errors.phoneNumber = "El número de teléfono de WhatsApp es requerido";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      // In a real implementation, we would store these credentials securely
      // For now, we'll simulate successful configuration
      
      // Request to store TWILIO_ACCOUNT_SID
      await fetch("/api/settings/twilio", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          account_sid: formData.accountSid,
          auth_token: formData.authToken,
          whatsapp_number: formData.phoneNumber
        })
      });
      
      toast.success("Configuración de WhatsApp guardada exitosamente");
      
      // Check status again to confirm it's working
      await checkStatus();
      
      if (onConfigured) {
        onConfigured();
      }
    } catch (error) {
      toast.error("Error al guardar la configuración de WhatsApp");
      console.error("Error saving WhatsApp configuration:", error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const renderStatusIndicator = () => {
    switch (configStatus.status) {
      case "operational":
        return (
          <Alert className="bg-green-50 border-green-200 mb-6">
            <Check className="h-4 w-4 text-green-500 mr-2" />
            <AlertDescription className="text-green-700">
              {configStatus.message}
              {configStatus.whatsappNumber && (
                <span className="block mt-1 text-sm">Número: {configStatus.whatsappNumber}</span>
              )}
            </AlertDescription>
          </Alert>
        );
      case "error":
        return (
          <Alert className="bg-red-50 border-red-200 mb-6">
            <AlertCircle className="h-4 w-4 text-red-500 mr-2" />
            <AlertDescription className="text-red-700">
              {configStatus.message}
            </AlertDescription>
          </Alert>
        );
      case "loading":
        return (
          <div className="flex items-center justify-center py-4 mb-6">
            <Loader2 className="h-5 w-5 text-orange-500 animate-spin mr-2" />
            <span>Verificando estado de la configuración...</span>
          </div>
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="space-y-6">
      {renderStatusIndicator()}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="accountSid">Twilio Account SID</Label>
          <Input
            id="accountSid"
            name="accountSid"
            type="text"
            placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
            value={formData.accountSid}
            onChange={handleChange}
            className={formErrors.accountSid ? "border-red-300" : ""}
          />
          {formErrors.accountSid && (
            <p className="text-sm text-red-500">{formErrors.accountSid}</p>
          )}
          <p className="text-xs text-muted-foreground mt-1">
            Encuentra esto en tu <a href="https://console.twilio.com/" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">Dashboard de Twilio</a>
          </p>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="authToken">Twilio Auth Token</Label>
          <Input
            id="authToken"
            name="authToken"
            type="password"
            placeholder="••••••••••••••••••••••••••••••"
            value={formData.authToken}
            onChange={handleChange}
            className={formErrors.authToken ? "border-red-300" : ""}
          />
          {formErrors.authToken && (
            <p className="text-sm text-red-500">{formErrors.authToken}</p>
          )}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="phoneNumber">Número de WhatsApp</Label>
          <Input
            id="phoneNumber"
            name="phoneNumber"
            type="text"
            placeholder="+1234567890"
            value={formData.phoneNumber}
            onChange={handleChange}
            className={formErrors.phoneNumber ? "border-red-300" : ""}
          />
          {formErrors.phoneNumber && (
            <p className="text-sm text-red-500">{formErrors.phoneNumber}</p>
          )}
          <p className="text-xs text-muted-foreground mt-1">
            El número de teléfono completo con código de país (formato E.164)
          </p>
        </div>
        
        <Button type="submit" className="w-full bg-orange-500 hover:bg-orange-600" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Guardando...
            </>
          ) : (
            "Guardar configuración"
          )}
        </Button>
      </form>
    </div>
  );
};

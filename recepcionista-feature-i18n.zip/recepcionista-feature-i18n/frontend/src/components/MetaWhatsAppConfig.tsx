import React, { useState, useEffect } from "react";
import { useCurrentUser } from "app";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, Check, AlertCircle, ExternalLink } from "lucide-react";
import { doc, getDoc, setDoc, getFirestore } from "firebase/firestore";
import { firebaseApp } from "app";
import { toast } from "sonner";
import brain from "brain";

// Initialize Firestore
const db = getFirestore(firebaseApp);

export interface Props {
  onConfigured?: () => void;
}

export const MetaWhatsAppConfig: React.FC<Props> = ({ onConfigured }) => {
  const { user } = useCurrentUser();
  const [phoneNumberId, setPhoneNumberId] = useState("");
  const [accessToken, setAccessToken] = useState("");
  const [businessAccountId, setBusinessAccountId] = useState("");
  const [verifyToken, setVerifyToken] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [configStatus, setConfigStatus] = useState<"unconfigured" | "pending" | "success" | "error">("unconfigured");
  const [errorMessage, setErrorMessage] = useState("");
  const [setupGuide, setSetupGuide] = useState<Array<{title: string, description: string}>>([]);
  
  // Load existing configuration from Firestore
  useEffect(() => {
    if (!user) return;
    
    const loadConfig = async () => {
      try {
        setIsLoading(true);
        const configDoc = await getDoc(doc(db, `users/${user.uid}/config/meta_whatsapp`));
        
        if (configDoc.exists()) {
          const data = configDoc.data();
          if (data.phoneNumberId) setPhoneNumberId(data.phoneNumberId);
          if (data.businessAccountId) setBusinessAccountId(data.businessAccountId);
          if (data.verifyToken) setVerifyToken(data.verifyToken);
          // We don't load the access token for security reasons
          
          // Check if credentials are complete
          if (data.phoneNumberId && data.businessAccountId) {
            setConfigStatus("success");
          }
        }
        
        // Load setup guide
        try {
          const response = await fetch("/api/meta-whatsapp/setup-guide");
          const data = await response.json();
          setSetupGuide(data.steps || []);
        } catch (error) {
          console.error("Error loading setup guide:", error);
        }
      } catch (error) {
        console.error("Error loading WhatsApp configuration:", error);
        setErrorMessage(String(error));
      } finally {
        setIsLoading(false);
      }
    };
    
    loadConfig();
  }, [user]);
  
  // Save configuration to Firestore
  const handleSaveConfig = async () => {
    if (!user) {
      toast.error("Debes iniciar sesión para guardar la configuración");
      return;
    }
    
    if (!phoneNumberId || !accessToken || !businessAccountId) {
      toast.error("Por favor completa todos los campos");
      return;
    }
    
    setIsLoading(true);
    setConfigStatus("pending");
    
    try {
      // Generate a random verify token if none is provided
      const finalVerifyToken = verifyToken || Math.random().toString(36).substring(2, 15);
      
      // Save to Firestore (excluding the access token for security)
      await setDoc(doc(db, `users/${user.uid}/config/meta_whatsapp`), {
        phoneNumberId,
        businessAccountId,
        verifyToken: finalVerifyToken,
        updatedAt: new Date(),
      });
      
      // Update secrets through an admin API (would need to be implemented)
      // For now, we'll assume this is handled manually or through a different mechanism
      
      // Check if the connection works
      await checkWhatsAppStatus();
      
      toast.success("Configuración de WhatsApp guardada correctamente");
      
      if (onConfigured) {
        onConfigured();
      }
    } catch (error) {
      console.error("Error saving WhatsApp configuration:", error);
      setErrorMessage(String(error));
      setConfigStatus("error");
      toast.error("Error al guardar la configuración de WhatsApp");
    } finally {
      setIsLoading(false);
    }
  };
  
  // Test the WhatsApp connection
  const checkWhatsAppStatus = async () => {
    setIsTesting(true);
    try {
      // For now, we'll use a mock endpoint
      // This should be updated to call the actual Meta WhatsApp status endpoint
      const response = await fetch("/api/meta-whatsapp/status");
      const data = await response.json();
      
      if (data.status === "operational") {
        setConfigStatus("success");
      } else {
        setConfigStatus("error");
        setErrorMessage(data.message || "No se pudo conectar con WhatsApp");
      }
    } catch (error) {
      setConfigStatus("error");
      setErrorMessage(String(error));
    } finally {
      setIsTesting(false);
    }
  };
  
  return (
    <div className="space-y-6">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Configuración de WhatsApp Business API</CardTitle>
          <CardDescription>
            Configura Meta WhatsApp Business Cloud API para habilitar la integración con tu cuenta de WhatsApp Business.
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {configStatus === "success" && (
            <Alert className="bg-green-50 border-green-500">
              <Check className="h-4 w-4 text-green-500" />
              <AlertTitle>Configuración exitosa</AlertTitle>
              <AlertDescription>
                Tu conexión con WhatsApp está configurada correctamente.
              </AlertDescription>
            </Alert>
          )}
          
          {configStatus === "error" && (
            <Alert className="bg-red-50 border-red-500">
              <AlertCircle className="h-4 w-4 text-red-500" />
              <AlertTitle>Error de configuración</AlertTitle>
              <AlertDescription>
                {errorMessage || "No se pudo establecer la conexión con WhatsApp. Verifica tus credenciales."}
              </AlertDescription>
            </Alert>
          )}
          
          <div className="space-y-2">
            <Label htmlFor="phoneNumberId">Phone Number ID</Label>
            <Input
              id="phoneNumberId"
              placeholder="1234567890"
              value={phoneNumberId}
              onChange={(e) => setPhoneNumberId(e.target.value)}
              disabled={isLoading}
            />
            <p className="text-xs text-muted-foreground">
              El ID de tu número de teléfono de WhatsApp Business. Se encuentra en el panel de Meta for Developers.
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="accessToken">Access Token</Label>
            <Input
              id="accessToken"
              type="password"
              placeholder="EAABcQ..."
              value={accessToken}
              onChange={(e) => setAccessToken(e.target.value)}
              disabled={isLoading}
            />
            <p className="text-xs text-muted-foreground">
              El token de acceso para tu aplicación de Meta. Por razones de seguridad, deberás proporcionarlo cada vez que actualices la configuración.
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="businessAccountId">Business Account ID</Label>
            <Input
              id="businessAccountId"
              placeholder="1234567890"
              value={businessAccountId}
              onChange={(e) => setBusinessAccountId(e.target.value)}
              disabled={isLoading}
            />
            <p className="text-xs text-muted-foreground">
              El ID de tu cuenta de negocio de WhatsApp. Se encuentra en el panel de WhatsApp Manager.
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="verifyToken">Verify Token (opcional)</Label>
            <Input
              id="verifyToken"
              placeholder="token-secreto-para-webhooks"
              value={verifyToken}
              onChange={(e) => setVerifyToken(e.target.value)}
              disabled={isLoading}
            />
            <p className="text-xs text-muted-foreground">
              Token de verificación para webhooks. Si no proporcionas uno, se generará automáticamente.
            </p>
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={checkWhatsAppStatus} 
            disabled={isLoading || isTesting || !phoneNumberId || !accessToken || !businessAccountId}
          >
            {isTesting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Probando...
              </>
            ) : "Probar conexión"}
          </Button>
          
          <Button 
            onClick={handleSaveConfig} 
            disabled={isLoading || !phoneNumberId || !accessToken || !businessAccountId}
            className="bg-orange-500 hover:bg-orange-600"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : "Guardar configuración"}
          </Button>
        </CardFooter>
      </Card>
      
      {setupGuide.length > 0 && (
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Guía de Configuración</CardTitle>
            <CardDescription>
              Sigue estos pasos para configurar WhatsApp Business Cloud API
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <ol className="space-y-4 list-decimal list-inside">
              {setupGuide.map((step, index) => (
                <li key={index} className="pl-2">
                  <span className="font-medium">{step.title}</span>
                  <p className="text-sm text-muted-foreground mt-1 ml-6">{step.description}</p>
                </li>
              ))}
            </ol>
            
            <div className="mt-6">
              <a 
                href="https://developers.facebook.com/docs/whatsapp/cloud-api/get-started"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-orange-500 hover:text-orange-600"
              >
                Ver documentación oficial
                <ExternalLink className="ml-1 h-4 w-4" />
              </a>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

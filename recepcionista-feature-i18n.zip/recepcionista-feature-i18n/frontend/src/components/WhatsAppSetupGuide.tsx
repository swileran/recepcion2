import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ExternalLink, Info } from "lucide-react";

export const WhatsAppSetupGuide: React.FC = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Guía de configuración de WhatsApp Business</CardTitle>
        <CardDescription>
          Sigue estos pasos para configurar tu integración con WhatsApp Business API
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <Info className="h-4 w-4" />
          <AlertTitle>Configuración inicial</AlertTitle>
          <AlertDescription>
            Para usar WhatsApp Business API, necesitarás una cuenta de Twilio y acceso a Twilio Messaging API.
          </AlertDescription>
        </Alert>
        
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Paso 1: Crea una cuenta en Twilio</h3>
          <p className="text-sm text-muted-foreground">
            Visita <a href="https://www.twilio.com/try-twilio" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">Twilio <ExternalLink className="inline h-3 w-3" /></a> y crea una cuenta. Completa el proceso de verificación.
          </p>
        </div>
        
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Paso 2: Accede a la API de WhatsApp</h3>
          <p className="text-sm text-muted-foreground">
            En tu panel de Twilio, ve a "Messaging" &gt; "Try it out" &gt; "Send a WhatsApp message".
            Sigue las instrucciones para obtener acceso al sandbox de WhatsApp.
          </p>
        </div>
        
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Paso 3: Obtener credenciales</h3>
          <p className="text-sm text-muted-foreground">
            Necesitarás tres datos importantes de tu cuenta de Twilio:
          </p>
          <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-2">
            <li>
              <strong>Account SID</strong>: Encuentralo en el dashboard principal de Twilio.
            </li>
            <li>
              <strong>Auth Token</strong>: También en el dashboard principal, junto al Account SID.
            </li>
            <li>
              <strong>Número de WhatsApp</strong>: El número proporcionado por Twilio para WhatsApp con formato <code>whatsapp:+14155238886</code>.
            </li>
          </ul>
        </div>
        
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Paso 4: Configurar en Recepcionista AI</h3>
          <p className="text-sm text-muted-foreground">
            Una vez tengas las credenciales, ingrésalas en la pestaña de "Configuración" en la sección de WhatsApp.
          </p>
        </div>
        
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Para producción (opcional)</h3>
          <p className="text-sm text-muted-foreground">
            Para usar WhatsApp en producción con tu número oficial de negocio, deberás completar el proceso de
            aprobación de Facebook Business Manager. Consulta la
            <a href="https://www.twilio.com/docs/whatsapp/tutorial/connect-number-business-profile" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline"> documentación de Twilio <ExternalLink className="inline h-3 w-3" /></a>.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

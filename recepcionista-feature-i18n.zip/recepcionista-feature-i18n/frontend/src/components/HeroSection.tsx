import React from "react";
import { useNavigate } from "react-router-dom";
import { APP_BASE_PATH } from "app";
import { useTranslation } from 'react-i18next';

interface Props {
  title: string;
  subtitle: string;
  ctaText: string;
  onCtaClick: () => void;
}

export function HeroSection({ title, subtitle, ctaText, onCtaClick }: Props) {
  const navigate = useNavigate();
  const { t } = useTranslation();
  
  return (
    <div className="w-full max-w-7xl py-20 bg-gradient-to-br from-amber-50 to-orange-100 rounded-lg">
      <div className="max-w-4xl mx-auto text-center px-6">
        <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
          {t('home.hero.title')}
        </h1>
        <p className="text-xl md:text-2xl text-gray-700 mb-10 leading-relaxed mx-auto max-w-3xl">
          {t('home.hero.subtitle')}
        </p>
        <a
          href={`/login?signup=true`}
          className="inline-block px-8 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white text-lg font-medium rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
        >
          {t('home.hero.cta')}
        </a>
      </div>
    </div>
  );
}

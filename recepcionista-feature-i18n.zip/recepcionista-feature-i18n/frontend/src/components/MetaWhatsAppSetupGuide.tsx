import React, { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { ExternalLink, Info, CheckCircle2, ArrowRight } from "lucide-react";

export interface Step {
  title: string;
  description: string;
}

export interface Props {
  onComplete?: () => void;
}

export const MetaWhatsAppSetupGuide: React.FC<Props> = ({ onComplete }) => {
  const [steps, setSteps] = useState<Step[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentStep, setCurrentStep] = useState(0);
  
  // Fetch setup guide from API
  useEffect(() => {
    const fetchSetupGuide = async () => {
      try {
        setIsLoading(true);
        const response = await fetch("/api/meta-whatsapp/setup-guide");
        const data = await response.json();
        
        if (data.steps && Array.isArray(data.steps)) {
          setSteps(data.steps);
        } else {
          // Fallback steps if API fails
          setSteps([
            {
              title: "Crear una cuenta de Facebook Developer",
              description: "Regístrate en https://developers.facebook.com y crea una cuenta de desarrollador."
            },
            {
              title: "Crea una App de Meta",
              description: "En el panel de desarrollador, crea una nueva aplicación seleccionando 'Empresa' como tipo de aplicación."
            },
            {
              title: "Configurar WhatsApp",
              description: "Añade el producto WhatsApp a tu aplicación y configura un número de teléfono de prueba."
            },
            {
              title: "Obtener credenciales",
              description: "Obtén el Phone Number ID, Access Token y Business Account ID desde el panel de WhatsApp."
            },
            {
              title: "Configurar tu cuenta",
              description: "Introduce las credenciales en nuestra plataforma para conectar tu cuenta de WhatsApp Business."
            },
            {
              title: "Probar la conexión",
              description: "Envía un mensaje de prueba para verificar que la integración funciona correctamente."
            }
          ]);
        }
      } catch (error) {
        console.error("Error fetching setup guide:", error);
        // Set fallback steps here too
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchSetupGuide();
  }, []);
  
  const handleNextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else if (onComplete) {
      onComplete();
    }
  };
  
  const handlePreviousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Cargando guía de configuración...</CardTitle>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Guía de Configuración de WhatsApp Business API</CardTitle>
        <CardDescription>
          Sigue estos pasos para configurar la integración con WhatsApp Business Cloud API
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-6">
          <Alert className="bg-orange-50 border-orange-200">
            <Info className="h-4 w-4 text-orange-500" />
            <AlertTitle>Información importante</AlertTitle>
            <AlertDescription>
              La API de WhatsApp Business Cloud es significativamente más fácil de configurar que la solución Twilio. No necesitas un número de teléfono activo ni aprobar plantillas de mensaje para comenzar.
            </AlertDescription>
          </Alert>
          
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm font-medium">
                Paso {currentStep + 1} de {steps.length}
              </span>
              <span className="text-sm text-muted-foreground">
                {Math.round(((currentStep + 1) / steps.length) * 100)}% completado
              </span>
            </div>
            <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-2 bg-orange-500 rounded-full transition-all duration-300 ease-in-out" 
                style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
              />
            </div>
          </div>
          
          {steps.length > 0 && (
            <div className="p-6 border rounded-lg">
              <h3 className="text-lg font-semibold flex items-center">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-orange-100 text-orange-500 mr-2 text-sm">
                  {currentStep + 1}
                </span>
                {steps[currentStep].title}
              </h3>
              
              <p className="mt-2 text-gray-600">
                {steps[currentStep].description}
              </p>
              
              {currentStep === 0 && (
                <div className="mt-4">
                  <a 
                    href="https://developers.facebook.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-orange-500 hover:text-orange-600 font-medium"
                  >
                    Ir a Facebook for Developers
                    <ExternalLink className="ml-1 h-4 w-4" />
                  </a>
                </div>
              )}
              
              {currentStep === 3 && (
                <div className="mt-4 space-y-2">
                  <div className="flex">
                    <div className="w-40 font-medium">Phone Number ID:</div>
                    <div>Se encuentra en la pestaña de WhatsApp en tu aplicación de Meta</div>
                  </div>
                  <div className="flex">
                    <div className="w-40 font-medium">Business Account ID:</div>
                    <div>Visible en la sección de WhatsApp Business Account</div>
                  </div>
                  <div className="flex">
                    <div className="w-40 font-medium">Access Token:</div>
                    <div>Genera un token de larga duración para tu aplicación</div>
                  </div>
                </div>
              )}
            </div>
          )}
          
          <div className="flex justify-between pt-4">
            <Button
              variant="outline"
              onClick={handlePreviousStep}
              disabled={currentStep === 0}
            >
              Anterior
            </Button>
            
            <Button 
              onClick={handleNextStep} 
              className="bg-orange-500 hover:bg-orange-600 text-white"
            >
              {currentStep === steps.length - 1 ? "Finalizar" : "Siguiente"}
              {currentStep < steps.length - 1 && <ArrowRight className="ml-1 h-4 w-4" />}
              {currentStep === steps.length - 1 && <CheckCircle2 className="ml-1 h-4 w-4" />}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

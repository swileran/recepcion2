import { useState, useEffect } from "react";
import { useProfileStore } from "../utils/store";
import { useAppointmentStore, Appointment } from "../utils/appointmentStore";
import { FiSave, FiTrash, FiX, FiCalendar } from "react-icons/fi";
import { useTranslation } from 'react-i18next';

interface AppointmentFormProps {
  date?: Date;
  appointmentId?: string;
  onClose: () => void;
  onSaved: () => void;
}

interface FormErrors {
  clientName?: string;
  clientPhone?: string;
  serviceId?: string;
  date?: string;
  startTime?: string;
  endTime?: string;
}

export function AppointmentForm({ date, appointmentId, onClose, onSaved }: AppointmentFormProps) {
  const { t } = useTranslation();
  const { profile } = useProfileStore();
  const { 
    appointments, 
    createAppointment, 
    updateAppointment, 
    deleteAppointment,
    getAppointmentById,
    isLoading, 
    error 
  } = useAppointmentStore();
  
  const [formErrors, setFormErrors] = useState<FormErrors>({});
  const [formSuccess, setFormSuccess] = useState("");
  
  // Form state
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [serviceId, setServiceId] = useState("");
  const [notes, setNotes] = useState("");
  const [appointmentDate, setAppointmentDate] = useState<Date | null>(date || null);
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [isNewAppointment, setIsNewAppointment] = useState(true);
  const [appointmentStatus, setAppointmentStatus] = useState<Appointment["status"]>("scheduled");
  
  // Derived values
  const formattedDate = appointmentDate ? appointmentDate.toISOString().split('T')[0] : "";
  
  // Initialize form for editing existing appointment
  useEffect(() => {
    if (appointmentId) {
      const appointment = getAppointmentById(appointmentId);
      if (appointment) {
        setIsNewAppointment(false);
        setClientName(appointment.clientName);
        setClientPhone(appointment.clientPhone);
        setClientEmail(appointment.clientEmail || "");
        setServiceId(appointment.serviceId || "");
        setNotes(appointment.notes || "");
        setAppointmentDate(appointment.date);
        setStartTime(appointment.startTime);
        setEndTime(appointment.endTime);
        setAppointmentStatus(appointment.status);
      }
    } else {
      // Set default values for new appointment
      setIsNewAppointment(true);
      setAppointmentStatus("scheduled");
      
      // Default time based on business settings
      if (profile?.calendarSettings?.appointmentDuration) {
        // Get current hour rounded to nearest half hour
        const now = new Date();
        const hours = now.getHours();
        const minutes = now.getMinutes() >= 30 ? 30 : 0;
        const defaultStart = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
        
        setStartTime(defaultStart);
        
        // Calculate end time based on duration
        const duration = profile.calendarSettings.appointmentDuration;
        const startDate = new Date();
        startDate.setHours(hours);
        startDate.setMinutes(minutes);
        
        const endDate = new Date(startDate.getTime() + duration * 60000);
        const endHours = endDate.getHours();
        const endMinutes = endDate.getMinutes();
        const defaultEnd = `${endHours.toString().padStart(2, '0')}:${endMinutes.toString().padStart(2, '0')}`;
        
        setEndTime(defaultEnd);
      } else {
        // Default 1-hour appointment
        setStartTime("09:00");
        setEndTime("10:00");
      }
    }
  }, [appointmentId, getAppointmentById, profile]);
  
  // Calculate end time when start time or duration changes
  useEffect(() => {
    if (!isNewAppointment || !startTime || !profile?.calendarSettings?.appointmentDuration) {
      return;
    }
    
    // Calculate end time based on start time and duration
    const [hours, minutes] = startTime.split(':').map(Number);
    const startDate = new Date();
    startDate.setHours(hours);
    startDate.setMinutes(minutes);
    
    const duration = profile.calendarSettings.appointmentDuration;
    const endDate = new Date(startDate.getTime() + duration * 60000);
    const endHours = endDate.getHours();
    const endMinutes = endDate.getMinutes();
    const newEndTime = `${endHours.toString().padStart(2, '0')}:${endMinutes.toString().padStart(2, '0')}`;
    
    setEndTime(newEndTime);
  }, [startTime, profile?.calendarSettings?.appointmentDuration, isNewAppointment]);
  
  const validateForm = (): boolean => {
    const errors: FormErrors = {};
    
    if (!clientName.trim()) {
      errors.clientName = "El nombre del cliente es obligatorio";
    }
    
    if (!clientPhone.trim()) {
      errors.clientPhone = "El teléfono del cliente es obligatorio";
    } else if (!/^\+?[0-9]{8,15}$/.test(clientPhone.trim())) {
      errors.clientPhone = "El teléfono debe tener entre 8 y 15 dígitos";
    }
    
    if (!serviceId) {
      errors.serviceId = "Debes seleccionar un servicio";
    }
    
    if (!appointmentDate) {
      errors.date = "La fecha de la cita es obligatoria";
    }
    
    if (!startTime) {
      errors.startTime = "La hora de inicio es obligatoria";
    }
    
    if (!endTime) {
      errors.endTime = "La hora de fin es obligatoria";
    }
    
    // Check if end time is after start time
    if (startTime && endTime) {
      const [startHour, startMinute] = startTime.split(':').map(Number);
      const [endHour, endMinute] = endTime.split(':').map(Number);
      
      if (endHour < startHour || (endHour === startHour && endMinute <= startMinute)) {
        errors.endTime = "La hora de fin debe ser posterior a la hora de inicio";
      }
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const getServiceName = (serviceId: string): string => {
    if (!profile?.servicesOffered) return "";
    
    // Find the service in the profile's services
    const serviceIndex = parseInt(serviceId, 10);
    if (isNaN(serviceIndex) || serviceIndex < 0 || serviceIndex >= profile.servicesOffered.length) {
      return "";
    }
    
    // Services are stored as strings in format: name|price|description
    const serviceString = profile.servicesOffered[serviceIndex];
    const parts = serviceString.split('|');
    return parts[0] || "";
  };
  
  const calculateDuration = (): number => {
    if (!startTime || !endTime) return 60; // Default to 60 minutes
    
    const [startHour, startMinute] = startTime.split(':').map(Number);
    const [endHour, endMinute] = endTime.split(':').map(Number);
    
    // Calculate duration in minutes
    let durationMinutes = (endHour - startHour) * 60 + (endMinute - startMinute);
    
    // If end time is on the next day (unlikely for appointments but possible)
    if (durationMinutes < 0) {
      durationMinutes += 24 * 60;
    }
    
    return durationMinutes;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSuccess("");
    
    if (!validateForm() || !appointmentDate || !profile?.id) {
      return;
    }
    
    try {
      const duration = calculateDuration();
      const serviceName = getServiceName(serviceId);
      
      if (isNewAppointment) {
        // Create new appointment
        const newAppointmentId = await createAppointment({
          businessId: profile.id,
          clientName,
          clientPhone,
          clientEmail: clientEmail || undefined,
          serviceId,
          serviceName,
          date: appointmentDate,
          startTime,
          endTime,
          duration,
          status: appointmentStatus,
          notes: notes || undefined
        });
        
        if (profile?.calendarSettings?.googleCalendarIntegrated) {
          setFormSuccess("Cita creada con éxito y sincronizada con Google Calendar");
        } else {
          setFormSuccess("Cita creada con éxito");
        }
      } else if (appointmentId) {
        // Update existing appointment
        await updateAppointment(appointmentId, {
          clientName,
          clientPhone,
          clientEmail: clientEmail || undefined,
          serviceId,
          serviceName,
          date: appointmentDate,
          startTime,
          endTime,
          duration,
          status: appointmentStatus,
          notes: notes || undefined
        });
        
        if (profile?.calendarSettings?.googleCalendarIntegrated) {
          setFormSuccess("Cita actualizada con éxito y sincronizada con Google Calendar");
        } else {
          setFormSuccess("Cita actualizada con éxito");
        }
      }
      
      // Clear errors on success
      setFormErrors({});
      
      // Signal success and close the form after a delay
      setTimeout(() => {
        onSaved();
        onClose();
      }, 1500);
      
    } catch (error) {
      console.error("Error saving appointment:", error);
      const errorMessage = error instanceof Error ? error.message : "Error al guardar la cita. Inténtalo de nuevo.";
      setFormErrors({ ...formErrors, clientName: errorMessage });
    }
  };
  
  const handleDelete = async () => {
    if (!appointmentId || !confirm("\u00BFEstás seguro de que deseas eliminar esta cita? Esta acción no se puede deshacer.")) {
      return;
    }
    
    try {
      await deleteAppointment(appointmentId);
      
      if (profile?.calendarSettings?.googleCalendarIntegrated) {
        setFormSuccess("Cita eliminada con éxito y removida de Google Calendar");
      } else {
        setFormSuccess("Cita eliminada con éxito");
      }
      
      // Signal success and close the form after a delay
      setTimeout(() => {
        onSaved();
        onClose();
      }, 1500);
      
    } catch (error) {
      console.error("Error deleting appointment:", error);
      const errorMessage = error instanceof Error ? error.message : "Error al eliminar la cita. Inténtalo de nuevo.";
      setFormErrors({ ...formErrors, clientName: errorMessage });
    }
  };

  // Extract services from profile
  const services = profile?.servicesOffered?.map((service, index) => {
    const parts = service.split('|');
    return {
      id: index.toString(),
      name: parts[0],
      price: parts[1] || ""
    };
  }) || [];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">
            {isNewAppointment 
              ? t('components.appointmentForm.newAppointment')
              : t('components.appointmentForm.editAppointment')
            }
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <FiX size={24} />
          </button>
        </div>
        
        <div className="overflow-y-auto p-6">
          {/* Success message */}
          {formSuccess && (
            <div className="mb-4 bg-green-50 border border-green-200 text-green-800 rounded-md p-4">
              <p>{formSuccess}</p>
            </div>
          )}
          
          {/* Error message from store */}
          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 text-red-800 rounded-md p-4">
              <p>{error.message}</p>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Client Information */}
            <div className="space-y-4">
              <h4 className="font-medium text-gray-700">Información del Cliente</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="clientName" className="block text-sm font-medium text-gray-700 mb-1">
                    Nombre del cliente *
                  </label>
                  <input
                    type="text"
                    id="clientName"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className={`w-full px-3 py-2 border ${formErrors.clientName ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
                    placeholder="Nombre completo"
                  />
                  {formErrors.clientName && (
                    <p className="mt-1 text-sm text-red-600">{formErrors.clientName}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="clientPhone" className="block text-sm font-medium text-gray-700 mb-1">
                    Teléfono *
                  </label>
                  <input
                    type="tel"
                    id="clientPhone"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    className={`w-full px-3 py-2 border ${formErrors.clientPhone ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
                    placeholder="+34 XXX XXX XXX"
                  />
                  {formErrors.clientPhone && (
                    <p className="mt-1 text-sm text-red-600">{formErrors.clientPhone}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="clientEmail" className="block text-sm font-medium text-gray-700 mb-1">
                    Correo electrónico (opcional)
                  </label>
                  <input
                    type="email"
                    id="clientEmail"
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    placeholder="ejemplo@email.com"
                  />
                </div>
              </div>
            </div>
            
            {/* Appointment Details */}
            <div className="space-y-4 pt-4 border-t border-gray-200">
              <h4 className="font-medium text-gray-700">Detalles de la Cita</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="serviceId" className="block text-sm font-medium text-gray-700 mb-1">
                    Servicio *
                  </label>
                  <select
                    id="serviceId"
                    value={serviceId}
                    onChange={(e) => setServiceId(e.target.value)}
                    className={`w-full px-3 py-2 border ${formErrors.serviceId ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
                  >
                    <option value="">Selecciona un servicio</option>
                    {services.map((service) => (
                      <option key={service.id} value={service.id}>
                        {service.name} {service.price ? `- ${service.price}` : ''}
                      </option>
                    ))}
                  </select>
                  {formErrors.serviceId && (
                    <p className="mt-1 text-sm text-red-600">{formErrors.serviceId}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="appointmentDate" className="block text-sm font-medium text-gray-700 mb-1">
                    Fecha *
                  </label>
                  <input
                    type="date"
                    id="appointmentDate"
                    value={formattedDate}
                    onChange={(e) => setAppointmentDate(e.target.value ? new Date(e.target.value) : null)}
                    className={`w-full px-3 py-2 border ${formErrors.date ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
                  />
                  {formErrors.date && (
                    <p className="mt-1 text-sm text-red-600">{formErrors.date}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="startTime" className="block text-sm font-medium text-gray-700 mb-1">
                    Hora de inicio *
                  </label>
                  <input
                    type="time"
                    id="startTime"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className={`w-full px-3 py-2 border ${formErrors.startTime ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
                  />
                  {formErrors.startTime && (
                    <p className="mt-1 text-sm text-red-600">{formErrors.startTime}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="endTime" className="block text-sm font-medium text-gray-700 mb-1">
                    Hora de fin *
                  </label>
                  <input
                    type="time"
                    id="endTime"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className={`w-full px-3 py-2 border ${formErrors.endTime ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
                  />
                  {formErrors.endTime && (
                    <p className="mt-1 text-sm text-red-600">{formErrors.endTime}</p>
                  )}
                </div>
                
                {!isNewAppointment && (
                  <div>
                    <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
                      Estado
                    </label>
                    <select
                      id="status"
                      value={appointmentStatus}
                      onChange={(e) => setAppointmentStatus(e.target.value as Appointment["status"])}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    >
                      <option value="scheduled">Programada</option>
                      <option value="confirmed">Confirmada</option>
                      <option value="completed">Completada</option>
                      <option value="cancelled">Cancelada</option>
                      <option value="noShow">No asistió</option>
                    </select>
                  </div>
                )}
              </div>
              
              {/* Google Calendar Integration Info */}
              {profile?.calendarSettings?.googleCalendarIntegrated && (
                <div className="mt-4 bg-blue-50 border border-blue-200 rounded-md p-3 flex items-center">
                  <FiCalendar className="text-blue-500 mr-2" />
                  <p className="text-sm text-blue-700">
                    Esta cita se sincronizará automáticamente con tu Google Calendar
                  </p>
                </div>
              )}
              
              <div>
                <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">
                  Notas (opcional)
                </label>
                <textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Información adicional o peticiones especiales"
                />
              </div>
            </div>
          </form>
        </div>
        
        <div className="px-6 py-4 border-t border-gray-200 flex justify-between">
          {!isNewAppointment && (
            <button
              type="button"
              onClick={handleDelete}
              disabled={isLoading}
              className="px-4 py-2 border border-red-300 rounded-md shadow-sm text-sm font-medium text-red-700 bg-white hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 flex items-center disabled:opacity-50"
            >
              <FiTrash className="mr-2" size={16} />
              {t('components.appointmentForm.delete')}
            </button>
          )}
          
          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
            >
              {t('components.appointmentForm.cancel')}
            </button>
            
            <button
              type="submit"
              onClick={handleSubmit}
              disabled={isLoading}
              className="px-4 py-2 bg-orange-600 text-white font-medium rounded-md shadow hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 flex items-center disabled:bg-gray-400"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  {t('components.appointmentForm.saving')}
                </>
              ) : (
                <>
                  <FiSave className="mr-2" size={16} />
                  {isNewAppointment 
                    ? t('components.appointmentForm.createAppointment') 
                    : t('components.appointmentForm.saveChanges')
                  }
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

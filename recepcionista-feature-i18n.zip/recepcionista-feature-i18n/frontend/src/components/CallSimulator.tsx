import { useState, useEffect } from "react";
import brain from "brain";
import { SimulationScenario, SimulateCallData, SimulationRequest } from "types";
import { FiPlay, FiSend, FiRotateCcw, FiCheckCircle, FiXCircle, FiBarChart } from "react-icons/fi";
import { useProfileStore } from "../utils/store";
import { saveSimulationResult, calculateSimulationStats } from "../utils/simulationHistory";
import { Button } from "@/components/ui/button";
import { SimulationHistoryModal } from "./SimulationHistoryModal";
import { format } from "date-fns";

export function CallSimulator() {
  const { profile } = useProfileStore();
  
  const [scenarios, setScenarios] = useState<SimulationScenario[]>([]);
  const [selectedScenario, setSelectedScenario] = useState<string>("");
  const [loadingScenarios, setLoadingScenarios] = useState(true);
  const [scenarioDescription, setScenarioDescription] = useState("");
  
  const [userInput, setUserInput] = useState("");
  const [conversationContext, setConversationContext] = useState<Record<string, any> | null>(null);
  const [testResults, setTestResults] = useState<{
    scenariosTested: number;
    successfulScenarios: number;
    lastTested: Date | null;
  }>({ scenariosTested: 0, successfulScenarios: 0, lastTested: null });
  const [showStatsModal, setShowStatsModal] = useState(false);
  const [conversationHistory, setConversationHistory] = useState<Array<{ role: string; content: string }>([]);
  const [suggestedInputs, setSuggestedInputs] = useState<string[]>([]);
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [simulationSuccess, setSimulationSuccess] = useState<string | null>(null);
  
  const [audioPlaying, setAudioPlaying] = useState(false);
  const [audioRef, setAudioRef] = useState<HTMLAudioElement | null>(null);
  const [improvementSuggestions, setImprovementSuggestions] = useState<Array<{category: string; suggestion: string; priority: string}>>([]);
  const [performanceMetrics, setPerformanceMetrics] = useState<Record<string, number>>({});
  
  useEffect(() => {
    // Fetch available scenarios
    const fetchScenarios = async () => {
      try {
        setLoadingScenarios(true);
        const response = await brain.get_simulation_scenarios();
        const data = await response.json();
        setScenarios(data.scenarios);
        
        // Select the first scenario by default
        if (data.scenarios && data.scenarios.length > 0) {
          setSelectedScenario(data.scenarios[0].id);
          setScenarioDescription(data.scenarios[0].description);
        }
      } catch (error) {
        console.error("Error fetching simulation scenarios:", error);
        setError("No se pudieron cargar los escenarios de simulación. Por favor, inténtalo de nuevo.");
      } finally {
        setLoadingScenarios(false);
      }
    };
    
    fetchScenarios();
    
    // Create audio element for voice playback
    const audio = new Audio();
    setAudioRef(audio);
    
    // Cleanup audio on unmount
    return () => {
      if (audioRef) {
        audioRef.pause();
        audioRef.src = "";
      }
    };
  }, []);
  
  // Helper function to save simulation results to the analytics system
  const saveSimulationToAnalytics = async (simulation: any) => {
    try {
      const response = await brain.convert_simulation_to_call(simulation);
      console.log('Simulation saved to analytics system:', await response.json());
      return true;
    } catch (error) {
      console.error('Error saving simulation to analytics:', error);
      return false;
    }
  };
  
  const handleScenarioChange = (scenarioId: string) => {
    setSelectedScenario(scenarioId);
    
    // Find the selected scenario to display its description
    const scenario = scenarios.find(s => s.id === scenarioId);
    if (scenario) {
      setScenarioDescription(scenario.description);
      
      // Set suggested initial input
      setSuggestedInputs([scenario.suggested_first_input]);
      
      // Reset conversation for new scenario
      resetConversation();
      
      // Set initial context based on scenario type
      if (scenario.initial_context) {
        setConversationContext(scenario.initial_context);
      }
    }
  };
  
  const resetConversation = () => {
    setConversationHistory([]);
    setConversationContext(null);
    setError(null);
    setSimulationSuccess(null);
    setUserInput("");
  };
  
  const playAudio = async (text: string) => {
    if (!profile?.voiceAgent?.voice_id) {
      setError("No se ha configurado una voz para el asistente. Por favor, configura una voz en la sección de Asistente de Voz.");
      return;
    }
    
    try {
      setAudioPlaying(true);
      
      // Request text-to-speech conversion
      const response = await brain.text_to_speech({
        text,
        voice_id: profile.voiceAgent.voice_id,
      });
      
      if (!response.ok) {
        throw new Error(`Error al generar voz: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Convert base64 to audio
      const audioBlob = base64ToBlob(data.audio_base64, "audio/mpeg");
      const audioUrl = URL.createObjectURL(audioBlob);
      
      if (audioRef) {
        audioRef.src = audioUrl;
        audioRef.onended = () => {
          setAudioPlaying(false);
          URL.revokeObjectURL(audioUrl);
        };
        audioRef.play();
      }
    } catch (error) {
      console.error("Error playing audio:", error);
      setError("No se pudo reproducir el audio. Por favor, inténtalo de nuevo.");
      setAudioPlaying(false);
    }
  };
  
  // Helper function to convert base64 to blob
  const base64ToBlob = (base64: string, mimeType: string) => {
    const byteCharacters = atob(base64);
    const byteArrays = [];
    
    for (let i = 0; i < byteCharacters.length; i += 512) {
      const slice = byteCharacters.slice(i, i + 512);
      
      const byteNumbers = new Array(slice.length);
      for (let j = 0; j < slice.length; j++) {
        byteNumbers[j] = slice.charCodeAt(j);
      }
      
      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    
    return new Blob(byteArrays, { type: mimeType });
  };
  
  const handleSubmitMessage = async (input: string = userInput) => {
    if (!input.trim() && !suggestedInputs.length) {
      return;
    }
    
    const messageToSend = input.trim() || (suggestedInputs.length > 0 ? suggestedInputs[0] : "");
    
    if (!messageToSend) {
      return;
    }
    
    // Add user message to conversation history
    const updatedHistory = [...conversationHistory, { role: "user", content: messageToSend }];
    setConversationHistory(updatedHistory);
    
    // Clear input field and error
    setUserInput("");
    setError(null);
    
    try {
      setIsLoading(true);
      setImprovementSuggestions([]);
      setPerformanceMetrics({});
      
      // Prepare request data
      const requestData: SimulationRequest = {
        user_input: messageToSend,
        scenario: selectedScenario,
        context: conversationContext || undefined
      };
      
      // Send simulation request
      const response = await brain.simulate_call(requestData);
      const data = await response.json() as SimulateCallData;
      
      // Update conversation context with actions and add conversation summary for analysis
      setConversationContext({
        ...data.actions || {},
        conversation_summary: data.conversation_summary || null
      });
      
      // Track test results
      setTestResults(prev => {
        const isSuccessful = 
          (data.actions?.appointment?.status === 'confirmed') || 
          (data.actions?.faq_matched) || 
          (data.actions?.conversation_ended);
        
        const newResults = {
          scenariosTested: prev.scenariosTested + 1,
          successfulScenarios: isSuccessful ? prev.successfulScenarios + 1 : prev.successfulScenarios,
          lastTested: new Date()
        };
        
        // Save simulation result to history
        const selectedScenarioObj = scenarios.find(s => s.id === selectedScenario);
        if (selectedScenarioObj) {
          // Save to local storage for immediate statistics
          saveSimulationResult({
            scenarioId: selectedScenario,
            scenarioName: selectedScenarioObj.name,
            date: new Date().toISOString(),
            successful: isSuccessful,
            conversationSummary: data.conversation_summary || '',
            appointmentStatus: data.actions?.appointment?.status,
            appointmentService: data.actions?.appointment?.service,
            appointmentMultiplePeople: data.actions?.appointment?.multiple_people,
            faqMatched: !!data.actions?.faq_matched,
            faqTopic: data.actions?.faq_matched?.question,
            customerComplaint: !!data.actions?.customer_complaint,
            complaintSeverity: data.actions?.customer_complaint?.severity,
            performanceMetrics: data.performance_metrics,
            improvementSuggestions: data.improvement_suggestions
          });
          
          // Also save to Firestore via API for analytics
          saveSimulationToAnalytics({
            simulationId: `sim_${Date.now()}`,
            scenarioId: selectedScenario,
            scenarioName: selectedScenarioObj.name,
            date: new Date(),
            successful: isSuccessful,
            conversationSummary: data.conversation_summary || '',
            appointmentStatus: data.actions?.appointment?.status,
            appointmentService: data.actions?.appointment?.service,
            duration: Math.floor(Math.random() * 120) + 60, // Random duration between 60-180 seconds
            faqMatched: !!data.actions?.faq_matched,
            faqTopic: data.actions?.faq_matched?.question,
            customerComplaint: !!data.actions?.customer_complaint,
            complaintSeverity: data.actions?.customer_complaint?.severity,
            performanceMetrics: data.performance_metrics,
            improvementSuggestions: data.improvement_suggestions?.map(item => ({
              category: item.category || 'general',
              suggestion: item.suggestion || item.text || '',
              priority: item.priority || 'media'
            }))
          });
        }
        
        return newResults;
      });
      
      // Update conversation history with AI response
      setConversationHistory([...updatedHistory, { role: "assistant", content: data.ai_response }]);
      
      // Update suggested inputs
      setSuggestedInputs(data.suggested_next_inputs || []);
      
      // Check for actions that indicate success
      if (data.actions && data.actions.appointment && data.actions.appointment.status === "confirmed") {
        setSimulationSuccess("¡Cita agendada correctamente!");
      } else if (data.actions && data.actions.faq_matched) {
        setSimulationSuccess("Pregunta respondida correctamente.");
      } else if (data.actions && data.actions.conversation_ended) {
        setSimulationSuccess("Conversación finalizada correctamente.");
      } else {
        setSimulationSuccess(null);
      }
      
      // Process improvement suggestions and performance metrics if available
      if (data.improvement_suggestions) {
        setImprovementSuggestions(data.improvement_suggestions.map(item => ({
          category: item.category || 'general',
          suggestion: item.suggestion || item.text || '',
          priority: item.priority || 'media'
        })));
      }
      
      if (data.performance_metrics) {
        setPerformanceMetrics(data.performance_metrics);
      }
      
      // Auto-play the audio response
      playAudio(data.ai_response);
      
    } catch (error) {
      console.error("Error in call simulation:", error);
      setError("Ocurrió un error al procesar la simulación. Por favor, inténtalo de nuevo.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSuggestedInput = (input: string) => {
    setUserInput(input);
    handleSubmitMessage(input);
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      {/* Statistics/Performance Overview */}
      <div className="bg-white shadow rounded-lg p-6 mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-900">Estadísticas de Simulación</h3>
          <Button variant="outline" size="sm" onClick={() => { setShowStatsModal(true); }}>
            <FiBarChart className="mr-1" /> Ver Historial
          </Button>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-orange-50 p-3 rounded-lg text-center">
            <div className="text-3xl font-bold text-orange-600 mb-1">
              {calculateSimulationStats().totalSimulations}
            </div>
            <div className="text-xs text-gray-600">Total de Simulaciones</div>
          </div>
          
          <div className="bg-green-50 p-3 rounded-lg text-center">
            <div className="text-3xl font-bold text-green-600 mb-1">
              {calculateSimulationStats().appointmentsBooked}
            </div>
            <div className="text-xs text-gray-600">Citas Confirmadas</div>
          </div>
          
          <div className="bg-blue-50 p-3 rounded-lg text-center">
            <div className="text-3xl font-bold text-blue-600 mb-1">
              {calculateSimulationStats().faqsAnswered}
            </div>
            <div className="text-xs text-gray-600">Preguntas Respondidas</div>
          </div>
          
          <div className="bg-purple-50 p-3 rounded-lg text-center">
            <div className="text-3xl font-bold text-purple-600 mb-1">
              {Math.round((calculateSimulationStats().successfulSimulations / Math.max(calculateSimulationStats().totalSimulations, 1)) * 100)}%
            </div>
            <div className="text-xs text-gray-600">Tasa de Éxito</div>
          </div>
          
          <div className="col-span-2 md:col-span-4 text-center mt-2 text-sm">
            <Button 
              variant="link" 
              size="sm" 
              onClick={() => window.location.href = 'Dashboard?tab=analitica'}
              className="text-orange-600">
              Ver análisis detallado de llamadas
            </Button>
          </div>
        </div>
      </div>
      
      <div className="bg-white shadow rounded-lg p-4 mb-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Simulador de Llamadas</h2>
        <p className="text-gray-600 mb-4">
          Prueba cómo responderá tu asistente de voz en diferentes situaciones y escenarios. 
          Esto te ayudará a refinar tus respuestas y mejorar la experiencia de tus clientes.
        </p>
      </div>
      
      {/* Scenario Selection */}
      <div className="bg-white shadow rounded-lg p-6 mb-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Seleccionar Escenario</h3>
        
        {loadingScenarios ? (
          <div className="flex justify-center p-4">
            <svg className="animate-spin h-8 w-8 text-orange-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          </div>
        ) : (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              {scenarios.map((scenario) => (
                <div 
                  key={scenario.id}
                  className={`border rounded-lg p-4 cursor-pointer transition-all ${selectedScenario === scenario.id ? 'border-orange-500 bg-orange-50 shadow' : 'border-gray-200 hover:border-orange-300 hover:shadow'}`}
                  onClick={() => handleScenarioChange(scenario.id)}
                >
                  <div className="flex items-start mb-2">
                    <input
                      type="radio"
                      id={`scenario-${scenario.id}`}
                      name="scenario"
                      value={scenario.id}
                      checked={selectedScenario === scenario.id}
                      onChange={() => handleScenarioChange(scenario.id)}
                      className="h-4 w-4 mt-1 text-orange-600 focus:ring-orange-500 border-gray-300"
                    />
                    <label htmlFor={`scenario-${scenario.id}`} className="ml-3 block font-medium text-gray-800">
                      {scenario.name}
                    </label>
                  </div>
                  <div className="ml-7 text-xs text-gray-500 line-clamp-2" title={scenario.description}>
                    {scenario.description}
                  </div>
                </div>
              ))}
            </div>
            
            {scenarioDescription && (
              <div className="p-4 bg-gray-50 rounded-md text-sm text-gray-700">
                <strong>Descripción:</strong> {scenarioDescription}
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Conversation Interface */}
      <div className="bg-white shadow rounded-lg p-6 mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-900">Simulación de Llamada</h3>
          
          <button
            type="button"
            onClick={resetConversation}
            className="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md text-orange-700 bg-orange-100 hover:bg-orange-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
          >
            <FiRotateCcw className="mr-1" size={16} />
            Reiniciar
          </button>
        </div>
        
        {/* Error message */}
        {error && (
          <div className="mb-4 p-3 border border-red-300 bg-red-50 rounded-md text-sm text-red-700">
            {error}
          </div>
        )}
        
        {/* Success message */}
        {simulationSuccess && (
          <div className="mb-4 p-3 border border-green-300 bg-green-50 rounded-md text-sm text-green-700 flex items-center">
            <FiCheckCircle className="mr-2" size={16} />
            {simulationSuccess}
          </div>
        )}
        
        {/* Conversation Summary */}
        {conversationContext && conversationContext.conversation_summary && conversationHistory.length > 0 && (
          <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-md text-sm">
            <h4 className="font-medium text-blue-800 mb-1">Resumen de la conversación:</h4>
            <p className="text-blue-700">{conversationContext.conversation_summary}</p>
            
            {/* Outcome indicators */}
            <div className="mt-2 flex flex-wrap gap-2">
              {conversationContext.appointment && (
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${conversationContext.appointment.status === 'confirmed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                  {conversationContext.appointment.status === 'confirmed' ? (
                    <>
                      <FiCheckCircle className="mr-1" size={12} />
                      Cita confirmada
                    </>
                  ) : (
                    <>Cita pendiente</>  
                  )}
                </span>
              )}
              
              {conversationContext.faq_matched && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  <FiCheckCircle className="mr-1" size={12} />
                  Pregunta respondida
                </span>
              )}
              
              {conversationContext.customer_complaint && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                  Queja registrada
                </span>
              )}
              
              {conversationContext.conversation_ended && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  Conversación finalizada
                </span>
              )}
            </div>
          </div>
        )}
        
        {/* Conversation History */}
        <div className="mb-6 p-4 border border-gray-200 rounded-lg bg-gray-50 h-96 overflow-y-auto">
          {conversationHistory.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
              <p className="mb-2">La conversación aparecerá aquí.</p>
              <p className="text-sm">Selecciona un escenario y comienza a simular una llamada.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {conversationHistory.map((message, index) => (
                <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div 
                    className={`max-w-3/4 p-3 rounded-lg ${message.role === 'user' ? 'bg-orange-100 text-gray-800' : 'bg-white border border-gray-200 text-gray-700'}`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex items-start">
                        <span className="inline-block mr-2 text-xs font-medium text-gray-500 mt-0.5">
                          {message.role === 'user' ? 'Cliente:' : 'Asistente:'}
                        </span>
                        <div className="text-sm">{message.content}</div>
                      </div>
                      
                      {message.role === 'assistant' && (
                        <button
                          onClick={() => playAudio(message.content)}
                          className="ml-2 text-orange-500 hover:text-orange-700"
                          disabled={audioPlaying}
                          title="Reproducir audio"
                        >
                          <FiPlay size={16} />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Suggested Inputs */}
        {suggestedInputs.length > 0 && (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Sugerencias de respuesta:
            </label>
            <div className="flex flex-wrap gap-2">
              {suggestedInputs.map((input, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestedInput(input)}
                  className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-800 text-sm rounded-md transition-colors"
                  disabled={isLoading}
                >
                  {input}
                </button>
              ))}
            </div>
          </div>
        )}
        
        {/* Input Form */}
        <form onSubmit={(e) => {
          e.preventDefault();
          handleSubmitMessage();
        }} className="flex items-end">
          <div className="flex-grow">
            <label htmlFor="user-input" className="block text-sm font-medium text-gray-700 mb-1">
              Tu mensaje:
            </label>
            <textarea
              id="user-input"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              placeholder="Escribe tu mensaje aquí o selecciona una sugerencia..."
              disabled={isLoading}
            />
          </div>
          
          <button
            type="submit"
            disabled={isLoading || (!userInput.trim() && !suggestedInputs.length)}
            className="ml-3 px-4 py-2 bg-orange-600 text-white font-medium rounded-md shadow hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 flex items-center disabled:bg-gray-400 mb-1"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Procesando...
              </>
            ) : (
              <>
                <FiSend className="mr-2" size={18} />
                Enviar
              </>
            )}
          </button>
        </form>
      </div>
      
      {/* Simulation Results/Analysis */}
      {conversationHistory.length > 0 && (
        <div className="bg-white shadow rounded-lg p-6 mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Análisis de la Simulación</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-800 mb-2">Rendimiento del Asistente</h4>
              
              {/* Performance Metrics */}
              {Object.keys(performanceMetrics).length > 0 ? (
                <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                  {performanceMetrics.overall !== undefined && (
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-gray-700">Rendimiento general</span>
                        <span className="text-sm font-medium text-gray-900">{Math.round(performanceMetrics.overall * 100)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ width: `${Math.round(performanceMetrics.overall * 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  )}
                  
                  {performanceMetrics.clarity !== undefined && (
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-gray-600">Claridad de respuestas</span>
                        <span className="text-sm font-medium">{Math.round(performanceMetrics.clarity * 100)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full" 
                          style={{ width: `${Math.round(performanceMetrics.clarity * 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  )}
                  
                  {performanceMetrics.efficiency !== undefined && (
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-gray-600">Eficiencia de conversación</span>
                        <span className="text-sm font-medium">{Math.round(performanceMetrics.efficiency * 100)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-orange-600 h-2 rounded-full" 
                          style={{ width: `${Math.round(performanceMetrics.efficiency * 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  )}
                  
                  {performanceMetrics.helpfulness !== undefined && (
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-gray-600">Utilidad para el cliente</span>
                        <span className="text-sm font-medium">{Math.round(performanceMetrics.helpfulness * 100)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-purple-600 h-2 rounded-full" 
                          style={{ width: `${Math.round(performanceMetrics.helpfulness * 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  )}
                  
                  {performanceMetrics.personalization !== undefined && (
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-gray-600">Personalización</span>
                        <span className="text-sm font-medium">{Math.round(performanceMetrics.personalization * 100)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-pink-600 h-2 rounded-full" 
                          style={{ width: `${Math.round(performanceMetrics.personalization * 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Respuesta a consulta:</span>
                    <span className="text-sm font-medium">
                      {conversationContext?.faq_matched ? (
                        <span className="text-green-600 flex items-center">
                          <FiCheckCircle className="mr-1" size={14} />
                          Exitosa
                        </span>
                      ) : (
                        <span className="text-gray-600">N/A</span>
                      )}
                    </span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Gestión de cita:</span>
                    <span className="text-sm font-medium">
                      {conversationContext?.appointment ? (
                        conversationContext.appointment.status === 'confirmed' ? (
                          <span className="text-green-600 flex items-center">
                            <FiCheckCircle className="mr-1" size={14} />
                            Confirmada
                          </span>
                        ) : (
                          <span className="text-yellow-600">Pendiente</span>
                        )
                      ) : (
                        <span className="text-gray-600">N/A</span>
                      )}
                    </span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Manejo de queja:</span>
                    <span className="text-sm font-medium">
                      {conversationContext?.customer_complaint ? (
                        <span className="text-orange-600">Registrada</span>
                      ) : (
                        <span className="text-gray-600">N/A</span>
                      )}
                    </span>
                  </div>
                </div>
              )}
            </div>
            
            <div>
              <h4 className="font-medium text-gray-800 mb-2">Sugerencias de Mejora</h4>
              <div className="bg-gray-50 p-4 rounded-lg space-y-2 max-h-60 overflow-y-auto">
                {/* AI-generated improvement suggestions */}
                {improvementSuggestions.length > 0 ? (
                  improvementSuggestions.map((suggestion, index) => (
                    <div key={index} className="flex items-start">
                      <div className={`mt-0.5 mr-2 flex-shrink-0 w-4 h-4 rounded-full flex items-center justify-center 
                      ${suggestion.priority === 'alta' ? 'bg-red-100 text-red-600' : 
                        suggestion.priority === 'media' ? 'bg-amber-100 text-amber-600' : 
                        'bg-blue-100 text-blue-600'}`}>
                        <div className="w-1.5 h-1.5 rounded-full bg-current"></div>
                      </div>
                      <div>
                        <span className="font-medium text-sm text-gray-900 capitalize">{suggestion.category}: </span>
                        <span className="text-sm text-gray-700">{suggestion.suggestion}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  // Default suggestions based on context
                  <>
                    {!profile?.voiceAgent?.voice_id && (
                      <div className="text-sm text-orange-600">
                        <FiXCircle className="inline-block mr-1" size={14} />
                        Configura una voz para tu asistente en la sección de Asistente de Voz para una experiencia completa.
                      </div>
                    )}
                    
                    {conversationContext?.appointment?.status === 'pending_confirmation' && (
                      <div className="text-sm text-blue-600">
                        • Considera añadir más detalles a tu mensaje de confirmación de citas.
                      </div>
                    )}
                    
                    {conversationContext?.faq_matched && (
                      <div className="text-sm text-blue-600">
                        • Las respuestas a preguntas frecuentes fueron claras y concisas.
                      </div>
                    )}
                    
                    {conversationContext?.customer_complaint && (
                      <div className="text-sm text-blue-600">
                        • Asegúrate de tener un proceso para escalamiento de quejas en situaciones reales.
                      </div>
                    )}
                    
                    {!conversationContext?.faq_matched && !conversationContext?.appointment && !conversationContext?.customer_complaint && conversationHistory.length > 2 && (
                      <div className="text-sm text-blue-600">
                        • Considera definir más mensajes personalizados para mejorar la experiencia del cliente.
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Instructions */}
      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-800">
        <h4 className="font-medium mb-1">Cómo usar el simulador:</h4>
        <ul className="list-disc pl-5 space-y-1">
          <li>Selecciona un escenario para simular diferentes tipos de llamadas</li>
          <li>Escribe mensajes como si fueras un cliente llamando</li>
          <li>Usa los botones de sugerencia para respuestas rápidas</li>
          <li>Haz clic en el botón de reproducción para escuchar la voz del asistente</li>
          <li>Usa este simulador para probar cómo responderá tu asistente a diferentes situaciones</li>
          <li><strong>Analiza los resultados</strong> para mejorar continuamente las respuestas de tu asistente</li>
        </ul>
      </div>
      
      {/* History Modal */}
      <SimulationHistoryModal isOpen={showStatsModal} onClose={() => setShowStatsModal(false)} />
    </div>
  );
}

import React from "react";
import { TranslationProvider, useComponentTranslation } from './TranslationProvider';

interface StepProps {
  number: number;
  title: string;
  description: string;
}

function Step({ number, title, description }: StepProps) {
  return (
    <div className="flex flex-col md:flex-row items-start md:items-center gap-6 mb-12">
      <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center text-white font-bold text-xl">
        {number}
      </div>
      <div>
        <h3 className="text-xl font-bold mb-2 text-gray-800">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
}

function HowItWorksSectionContent() {
  const { translate } = useComponentTranslation();
  
  const steps = [
    {
      number: 1,
      title: translate('steps.0.title'),
      description: translate('steps.0.description')
    },
    {
      number: 2,
      title: translate('steps.1.title'),
      description: translate('steps.1.description')
    },
    {
      number: 3,
      title: translate('steps.2.title'),
      description: translate('steps.2.description')
    },
    {
      number: 4,
      title: translate('steps.3.title'),
      description: translate('steps.3.description')
    }
  ];

  return (
    <div className="w-full py-16 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-900 mx-auto max-w-3xl">
          {translate('title')}
        </h2>
        <div className="mt-12">
          {steps.map((step) => (
            <Step
              key={step.number}
              number={step.number}
              title={step.title}
              description={step.description}
            />
          ))}
        </div>
        <div className="mt-10 text-center">
          <span className="inline-block px-6 py-3 bg-amber-100 rounded-full text-orange-600 font-medium">
            {translate('footer')}
          </span>
        </div>
      </div>
    </div>
  );
}

export function HowItWorksSection() {
  return (
    <TranslationProvider namespace="components.howItWorksSection">
      <HowItWorksSectionContent />
    </TranslationProvider>
  );
}

import React, { useState } from 'react';
import { createUserWithEmailAndPassword, fetchSignInMethodsForEmail } from 'firebase/auth';
import { firebaseAuth } from 'app';
import { FiMail, FiLock, FiAlertCircle } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';

interface Props {
  onSuccess?: () => void;
  initialEmail?: string;
}

export function DirectRegistrationForm({ onSuccess, initialEmail = '' }: Props) {
  const navigate = useNavigate();
  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const checkEmailExists = async (email: string): Promise<boolean> => {
    try {
      const methods = await fetchSignInMethodsForEmail(firebaseAuth, email);
      console.log('DirectRegistrationForm: Sign in methods for email:', methods);
      return methods.length > 0;
    } catch (error) {
      console.error('DirectRegistrationForm: Error checking email existence:', error);
      return false;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    console.log('DirectRegistrationForm: Registration attempt with email:', email);
    
    // Form validation
    if (!email || !password) {
      setError('Por favor, completa todos los campos');
      return;
    }
    
    if (password !== confirmPassword) {
      setError('Las contraseñas no coinciden');
      return;
    }
    
    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres');
      return;
    }
    
    try {
      setLoading(true);
      
      // Add a small delay to ensure network stability
      await new Promise(resolve => setTimeout(resolve, 500));
      
      try {
        // Check if email already exists
        const emailExists = await checkEmailExists(email);
        if (emailExists) {
          console.log('DirectRegistrationForm: Email already exists:', email);
          setError('Este correo electrónico ya está registrado. Por favor, inicia sesión.');
          setLoading(false);
          return;
        }
      } catch (checkErr) {
        console.error('DirectRegistrationForm: Error checking email:', checkErr);
        // Continue with registration attempt even if email check fails
      }
      
      console.log('DirectRegistrationForm: Creating new user account for:', email);
      // Create user with email and password
      const userCredential = await createUserWithEmailAndPassword(firebaseAuth, email, password);
      console.log('DirectRegistrationForm: User created successfully:', userCredential.user.uid);
      
      // Add a small delay to ensure Firebase auth state is updated
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Call the success callback if provided
      if (onSuccess) {
        onSuccess();
      } else {
        // Redirect to dashboard profile setup
        console.log('DirectRegistrationForm: Redirecting to dashboard');
        navigate('/dashboard');
      }
    } catch (err: any) {
      console.error('DirectRegistrationForm: Error during registration:', err);
      console.log('DirectRegistrationForm: Error code:', err.code, 'Error message:', err.message || 'No message');
      
      // Network related errors
      if (err.code === 'auth/network-request-failed') {
        setError('Error de conexión. Por favor, verifica tu conexión a internet e inténtalo de nuevo.');
      }
      // Translate Firebase errors to user-friendly Spanish messages
      else if (err.code === 'auth/email-already-in-use') {
        setError('Este correo electrónico ya está registrado. Por favor, inicia sesión.');
      } else if (err.code === 'auth/invalid-email') {
        setError('El correo electrónico no es válido.');
      } else if (err.code === 'auth/weak-password') {
        setError('La contraseña es demasiado débil. Usa al menos 6 caracteres.');

      } else {
        setError(`Error al crear la cuenta: ${err.message || 'Desconocido'}. Por favor, inténtalo de nuevo.`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4 mb-4 flex items-start">
          <FiAlertCircle className="flex-shrink-0 mr-2 mt-0.5" />
          <p>{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
            Correo Electrónico
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FiMail className="text-gray-400" />
            </div>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
              placeholder="tu@email.com"
              required
            />
          </div>
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
            Contraseña
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FiLock className="text-gray-400" />
            </div>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-10 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
              placeholder="Contraseña (mínimo 6 caracteres)"
              required
              minLength={6}
            />
          </div>
        </div>

        <div>
          <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
            Confirmar Contraseña
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FiLock className="text-gray-400" />
            </div>
            <input
              id="confirmPassword"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="pl-10 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
              placeholder="Repite tu contraseña"
              required
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50"
        >
          {loading ? 'Creando cuenta...' : 'Crear cuenta'}
        </button>
        
        <p className="text-xs text-center text-gray-500 mt-4">
          Al crear una cuenta, aceptas nuestros <a href="#" className="text-orange-600 hover:text-orange-800">Términos de Servicio</a> y <a href="#" className="text-orange-600 hover:text-orange-800">Política de Privacidad</a>
        </p>
      </form>
    </div>
  );
}


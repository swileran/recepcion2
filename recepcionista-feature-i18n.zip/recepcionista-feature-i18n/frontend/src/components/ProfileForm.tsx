import { useState, useEffect } from "react";
import { useCurrentUser } from "app";
import { useProfileStore } from "utils/profileStore";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useTranslation } from 'react-i18next';

export default function ProfileForm() {
  const { t } = useTranslation();
  const { user } = useCurrentUser();
  const { profile, updateProfile, isLoading } = useProfileStore();
  
  const [formData, setFormData] = useState({
    businessName: "",
    businessDescription: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    postalCode: "",
    country: "",
    industry: ""
  });
  
  useEffect(() => {
    if (profile) {
      setFormData({
        businessName: profile.businessName || "",
        businessDescription: profile.businessDescription || "",
        phone: profile.phone || "",
        email: profile.email || "",
        address: profile.address || "",
        city: profile.city || "",
        postalCode: profile.postalCode || "",
        country: profile.country || "",
        industry: profile.industry || ""
      });
    }
  }, [profile]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error("Debe iniciar sesión para actualizar su perfil");
      return;
    }
    
    // Basic validation
    if (!formData.businessName.trim()) {
      toast.error("El nombre del negocio es obligatorio");
      return;
    }
    
    // Email validation
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      toast.error("El formato del email no es válido");
      return;
    }
    
    // Phone validation - just ensure it's mostly numbers with optional formatting
    if (formData.phone && !/^[+]?[0-9 ()-]{6,20}$/.test(formData.phone.trim())) {
      toast.error("El formato del teléfono no es válido");
      return;
    }
    
    // Prepare simple object with only the fields we need
    const updateData = {
      businessName: formData.businessName.trim() || "Mi Negocio",
      businessDescription: formData.businessDescription?.trim() || "",
      industry: formData.industry || "otro",
      phone: formData.phone?.trim() || "",
      email: formData.email?.trim() || "",
      address: formData.address?.trim() || "",
      city: formData.city?.trim() || "",
      postalCode: formData.postalCode?.trim() || "",
      country: formData.country || "espana"
    };
    
    try {
      console.log("Submitting simplified profile data:", updateData);
      await updateProfile(user.uid, updateData);
      toast.success("Perfil actualizado correctamente");
    } catch (error) {
      console.error("Form submission error:", error);
      toast.error("Error al actualizar el perfil. Por favor intenta nuevamente.");
    }
  };
  
  return (
    <Card>
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="businessName">{t('components.profileForm.businessName')}</Label>
              <Input
                id="businessName"
                name="businessName"
                value={formData.businessName}
                onChange={handleChange}
                placeholder={t('components.profileForm.businessName')}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="industry">{t('components.profileForm.industry')}</Label>
              <Select
                value={formData.industry}
                onValueChange={(value) => handleSelectChange("industry", value)}
              >
                <SelectTrigger id="industry">
                  <SelectValue placeholder={t('components.profileForm.selectIndustry')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional_services">{t('components.profileForm.industries.professional_services')}</SelectItem>
                  <SelectItem value="health_wellness">{t('components.profileForm.industries.health_wellness')}</SelectItem>
                  <SelectItem value="construction">{t('components.profileForm.industries.construction')}</SelectItem>
                  <SelectItem value="hospitality">{t('components.profileForm.industries.hospitality')}</SelectItem>
                  <SelectItem value="retail">{t('components.profileForm.industries.retail')}</SelectItem>
                  <SelectItem value="technology">{t('components.profileForm.industries.technology')}</SelectItem>
                  <SelectItem value="education">{t('components.profileForm.industries.education')}</SelectItem>
                  <SelectItem value="real_estate">{t('components.profileForm.industries.real_estate')}</SelectItem>
                  <SelectItem value="legal">{t('components.profileForm.industries.legal')}</SelectItem>
                  <SelectItem value="other">{t('components.profileForm.industries.other')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="businessDescription">{t('components.profileForm.businessDescription')}</Label>
              <Textarea
                id="businessDescription"
                name="businessDescription"
                value={formData.businessDescription}
                onChange={handleChange}
                placeholder={t('components.profileForm.businessDescription')}
                rows={4}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">{t('components.profileForm.phone')}</Label>
              <Input
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder={t('components.profileForm.phone')}
                maxLength={20}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">{t('components.profileForm.email')}</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder={t('components.profileForm.email')}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="address">{t('components.profileForm.address')}</Label>
              <Input
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder={t('components.profileForm.address')}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="city">{t('components.profileForm.city')}</Label>
              <Input
                id="city"
                name="city"
                value={formData.city}
                onChange={handleChange}
                placeholder={t('components.profileForm.city')}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="postalCode">{t('components.profileForm.postalCode')}</Label>
              <Input
                id="postalCode"
                name="postalCode"
                value={formData.postalCode}
                onChange={handleChange}
                placeholder={t('components.profileForm.postalCode')}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="country">{t('components.profileForm.country')}</Label>
              <Select
                value={formData.country}
                onValueChange={(value) => handleSelectChange("country", value)}
              >
                <SelectTrigger id="country">
                  <SelectValue placeholder={t('components.profileForm.selectCountry')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="espana">{t('components.profileForm.countries.espana')}</SelectItem>
                  <SelectItem value="mexico">{t('components.profileForm.countries.mexico')}</SelectItem>
                  <SelectItem value="argentina">{t('components.profileForm.countries.argentina')}</SelectItem>
                  <SelectItem value="colombia">{t('components.profileForm.countries.colombia')}</SelectItem>
                  <SelectItem value="chile">{t('components.profileForm.countries.chile')}</SelectItem>
                  <SelectItem value="peru">{t('components.profileForm.countries.peru')}</SelectItem>
                  <SelectItem value="venezuela">{t('components.profileForm.countries.venezuela')}</SelectItem>
                  <SelectItem value="ecuador">{t('components.profileForm.countries.ecuador')}</SelectItem>
                  <SelectItem value="otro">{t('components.profileForm.countries.otro')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Button 
            type="submit" 
            className="w-full bg-orange-500 hover:bg-orange-600"
            disabled={isLoading}
          >
            {isLoading ? (
              <span className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {t('components.profileForm.saving')}
              </span>
            ) : (
              t('components.profileForm.saveChanges')
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

import { useState } from "react";
import { CardElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { toast } from "sonner";
import { useSubscriptionStore, PriceOption } from "utils/subscriptionStore";
import { useProfileStore } from "utils/profileStore";
import { useCurrentUser } from "app";
import { Button } from "@/components/ui/button";
import { stripeConfig } from "utils/stripeConfig";

interface CheckoutFormProps {
  price: PriceOption;
  isDemo?: boolean;
}

export function CheckoutForm({ price, isDemo = false }: CheckoutFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const { user } = useCurrentUser();
  const { profile } = useProfileStore();
  const { createCheckoutSession } = useSubscriptionStore();
  const [isProcessing, setIsProcessing] = useState(false);
  
  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    
    if (!user) {
      toast.error("Debe iniciar sesión para suscribirse");
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // For demo mode
      if (isDemo) {
        // Store the selected plan name for demo mode
        localStorage.setItem('selectedPlanName', price.name);
        
        // Simulate a successful redirect
        setTimeout(() => {
          window.location.href = `${window.location.origin}/dashboard?tab=suscripcion&status=success`;
        }, 1500);
        return;
      }
      
      // Construct full URLs for success and cancel using stripeConfig.baseUrl
      const { baseUrl } = stripeConfig;
      const successUrl = `${baseUrl}/dashboard?tab=suscripcion&status=success`;
      const cancelUrl = `${baseUrl}/dashboard?tab=suscripcion&status=canceled`;
      
      console.log("Creating checkout session with URLs:", { successUrl, cancelUrl });
      
      // For normal Stripe checkout
      const result = await createCheckoutSession({
        price_id: price.price_id,
        business_id: user.uid,
        business_name: profile?.businessName || "",
        customer_email: user.email || "",
        success_url: successUrl,
        cancel_url: cancelUrl,
      });
      
      console.log("Checkout session created, redirecting to:", result.url);
      
      // Redirect to Stripe Checkout
      window.location.href = result.url;
    } catch (error) {
      console.error("Error creating checkout session:", error);
      toast.error("Error al procesar el pago");
      setIsProcessing(false);
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="p-4 border border-gray-200 rounded-md bg-gray-50">
        {/* Demo mode message */}
        {isDemo && (
          <div className="mb-3 p-2 bg-orange-100 rounded text-sm text-orange-700 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 mr-2">
              <path fillRule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z" clipRule="evenodd" />
            </svg>
            Modo demostración: No se realizará ningún cargo real.
          </div>
        )}
        
        {/* Stripe card element (only shown in non-demo mode) */}
        {!isDemo && stripe && elements && (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Información de tarjeta
            </label>
            <CardElement 
              options={{
                style: {
                  base: {
                    fontSize: '16px',
                    color: '#424770',
                    '::placeholder': {
                      color: '#aab7c4',
                    },
                  },
                  invalid: {
                    color: '#9e2146',
                  },
                },
              }}
            />
          </div>
        )}
        
        <div className="mt-2">
          <p className="text-sm text-gray-600 mb-1">
            Precio: {new Intl.NumberFormat('es-ES', {
              style: 'currency',
              currency: price.currency,
              minimumFractionDigits: 0,
            }).format(price.price / 100)}
            <span className="text-gray-500">
              /{price.interval === 'month' ? 'mes' : 'año'}
            </span>
          </p>
          
          <p className="text-xs text-gray-500">
            {isDemo
              ? "Este es un modo de demostración, no se realizará ningún cargo."
              : `Se le cobrará ${new Intl.NumberFormat('es-ES', {
                style: 'currency',
                currency: price.currency,
                minimumFractionDigits: 0,
              }).format(price.price / 100)} inmediatamente y se renovará cada ${price.interval === 'month' ? 'mes' : 'año'} hasta que cancele.`
            }
          </p>
        </div>
      </div>
      
      <Button 
        type="submit" 
        disabled={(!stripe && !isDemo) || isProcessing} 
        className="w-full bg-orange-500 hover:bg-orange-600"
      >
        {isProcessing ? (
          <span className="flex items-center justify-center">
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Procesando...
          </span>
        ) : (
          'Suscribirse'
        )}
      </Button>
    </form>
  );
}

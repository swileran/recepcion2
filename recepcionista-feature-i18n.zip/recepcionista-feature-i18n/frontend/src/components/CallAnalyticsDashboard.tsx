import React, { useEffect, useState } from "react";
import { useCallAnalyticsStore, CallAnalytics, AnalyticsPeriod, CallRecord } from "../utils/callAnalyticsStore";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DatePicker } from "../components/DatePicker";
import { useCurrentUser } from "app";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import brain from "brain";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Download, FileText } from "lucide-react";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";


export interface CallAnalyticsProps {
  className?: string;
}

// Colors for charts
const COLORS = [
  "#ff9800", // primary orange
  "#ffc107", // amber
  "#ffeb3b", // yellow
  "#cddc39", // lime
  "#8bc34a", // light green
  "#4caf50", // green
  "#009688", // teal
];

export function CallAnalyticsDashboard({ className }: CallAnalyticsProps) {
  const { user } = useCurrentUser();
  const { calls, analytics, isLoading, fetchCalls, calculateAnalytics, dateRange, setDateRange } = useCallAnalyticsStore();
  
  const [period, setPeriod] = useState<AnalyticsPeriod>("month");
  const [startDate, setStartDate] = useState<Date | undefined>(dateRange.startDate);
  const [endDate, setEndDate] = useState<Date | undefined>(dateRange.endDate);
  const [selectedTab, setSelectedTab] = useState("resumen");
  
  useEffect(() => {
    if (user) {
      fetchCalls(user.uid, period, startDate, endDate);
    }
  }, [user, period]);
  
  // Reload data when custom date range changes
  useEffect(() => {
    if (user && period === "custom" && startDate && endDate) {
      fetchCalls(user.uid, "custom", startDate, endDate);
    }
  }, [user, period, startDate, endDate]);
  
  // Helper function to format time duration
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };
  
  // Function to prepare data for outcome distribution pie chart
  const prepareOutcomeData = () => {
    if (!analytics) return [];
    
    return [
      { name: "Citas", value: analytics.outcomeCounts.appointment },
      { name: "Preguntas", value: analytics.outcomeCounts.faq },
      { name: "Quejas", value: analytics.outcomeCounts.complaint },
      { name: "Otros", value: analytics.outcomeCounts.other },
    ];
  };
  
  // Function to export dashboard as PDF
  const exportPDF = async () => {
    try {
      const dashboardElement = document.getElementById('analytics-dashboard');
      if (!dashboardElement) return;
      
      // Show loading state
      const loadingToast = toast.loading('Generando PDF...');
      
      // Create PDF with A4 dimensions
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      // Add header
      pdf.setFontSize(22);
      pdf.setTextColor(241, 90, 34); // Orange color
      pdf.text('Recepcionista AI - Análisis de Llamadas', 15, 20);
      
      // Add date range info
      pdf.setFontSize(12);
      pdf.setTextColor(100, 100, 100);
      let dateInfo = '';
      if (period === 'today') {
        dateInfo = `Hoy, ${format(new Date(), "d 'de' MMMM, yyyy", { locale: es })}`;
      } else if (period === 'week') {
        dateInfo = `Última semana (${format(new Date(new Date().setDate(new Date().getDate() - 7)), "d 'de' MMMM", { locale: es })} - ${format(new Date(), "d 'de' MMMM, yyyy", { locale: es })})`;
      } else if (period === 'month') {
        dateInfo = `Último mes (${format(new Date(new Date().setDate(new Date().getDate() - 30)), "d 'de' MMMM", { locale: es })} - ${format(new Date(), "d 'de' MMMM, yyyy", { locale: es })})`;
      } else if (period === 'custom' && startDate && endDate) {
        dateInfo = `Período: ${format(startDate, "d 'de' MMMM, yyyy", { locale: es })} - ${format(endDate, "d 'de' MMMM, yyyy", { locale: es })}`;
      }
      pdf.text(dateInfo, 15, 30);
      
      // Capture summary cards
      const cardsElement = document.querySelector('.grid.grid-cols-1.md\\:grid-cols-2.lg\\:grid-cols-4');
      if (cardsElement) {
        const cardsCanvas = await html2canvas(cardsElement as HTMLElement, {
          scale: 2,
          useCORS: true,
          logging: false
        });
        const cardsImgData = cardsCanvas.toDataURL('image/png');
        const cardsImgWidth = pdfWidth - 30; // Margins on both sides
        const cardsImgHeight = (cardsCanvas.height * cardsImgWidth) / cardsCanvas.width;
        
        pdf.addImage(cardsImgData, 'PNG', 15, 40, cardsImgWidth, cardsImgHeight);
        
        // Capture the active tab content
        const tabContentElement = document.querySelector(`[data-state="active"][role="tabpanel"]`);
        if (tabContentElement) {
          const tabCanvas = await html2canvas(tabContentElement as HTMLElement, {
            scale: 2,
            useCORS: true,
            logging: false
          });
          const tabImgData = tabCanvas.toDataURL('image/png');
          const tabImgWidth = pdfWidth - 30;
          const tabImgHeight = (tabCanvas.height * tabImgWidth) / tabCanvas.width;
          
          // Check if we need a new page
          if (40 + cardsImgHeight + 10 + tabImgHeight > pdfHeight) {
            pdf.addPage();
            pdf.addImage(tabImgData, 'PNG', 15, 20, tabImgWidth, tabImgHeight);
          } else {
            pdf.addImage(tabImgData, 'PNG', 15, 40 + cardsImgHeight + 10, tabImgWidth, tabImgHeight);
          }
          
          // Add recent calls table on a new page
          pdf.addPage();
          pdf.setFontSize(16);
          pdf.setTextColor(0, 0, 0);
          pdf.text('Llamadas Recientes', 15, 20);
          
          // Add table headers
          pdf.setFontSize(10);
          pdf.setTextColor(100, 100, 100);
          const headers = ['Fecha', 'Duración', 'Resultado', 'Detalles', 'Estado'];
          const colWidth = (pdfWidth - 30) / headers.length;
          
          headers.forEach((header, i) => {
            pdf.text(header, 15 + (i * colWidth), 30);
          });
          
          // Add table rows
          pdf.setTextColor(0, 0, 0);
          calls.slice(0, 10).forEach((call, rowIndex) => {
            const y = 40 + (rowIndex * 10);
            
            // Format date
            pdf.text(format(call.date, "dd/MM/yyyy, HH:mm"), 15, y);
            
            // Duration
            const mins = Math.floor(call.duration / 60);
            const secs = call.duration % 60;
            pdf.text(`${mins}m ${secs}s`, 15 + colWidth, y);
            
            // Outcome type
            let outcome = '';
            if (call.outcome === 'appointment') outcome = 'Cita';
            else if (call.outcome === 'faq') outcome = 'Pregunta';
            else if (call.outcome === 'complaint') outcome = 'Queja';
            else outcome = 'Otro';
            pdf.text(outcome, 15 + (2 * colWidth), y);
            
            // Details
            let details = '';
            if (call.outcome === 'appointment' && call.appointmentDetails) {
              details = `${call.appointmentDetails.service}`;
            } else if (call.outcome === 'faq' && call.faqDetails) {
              details = call.faqDetails.topic;
            } else if (call.outcome === 'complaint' && call.complaintDetails) {
              details = call.complaintDetails.topic;
            }
            pdf.text(details.substring(0, 20), 15 + (3 * colWidth), y);
            
            // Status
            pdf.text(call.successful ? 'Exitosa' : 'No exitosa', 15 + (4 * colWidth), y);
          });
        }
      }
      
      // Footer with timestamp
      const pageCount = pdf.internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        pdf.setPage(i);
        pdf.setFontSize(8);
        pdf.setTextColor(150, 150, 150);
        pdf.text(
          `Informe generado el ${format(new Date(), "d 'de' MMMM, yyyy 'a las' HH:mm", { locale: es })} - Página ${i} de ${pageCount}`,
          15,
          pdfHeight - 10
        );
      }
      
      // Save the PDF
      pdf.save(`recepcionista_analisis_${format(new Date(), 'yyyy-MM-dd')}.pdf`);
      toast.dismiss(loadingToast);
      toast.success('PDF generado correctamente');
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error('Error al generar el PDF');
    }
  };
  
  // Function to export call data as CSV
  const exportCallsCSV = () => {
    if (!calls.length) return;
    
    // Define the CSV headers
    const headers = [
      'Fecha',
      'Duración (seg)',
      'Resultado',
      'Exitosa',
      'Detalles',
      'Resumen'
    ];
    
    // Transform call data to CSV format
    const csvRows = calls.map(call => {
      let details = '';
      if (call.outcome === 'appointment' && call.appointmentDetails) {
        details = `${call.appointmentDetails.service}, ${format(call.appointmentDetails.date, "d 'de' MMMM", { locale: es })}`;
      } else if (call.outcome === 'faq' && call.faqDetails) {
        details = call.faqDetails.topic;
      } else if (call.outcome === 'complaint' && call.complaintDetails) {
        details = `${call.complaintDetails.topic} (${call.complaintDetails.severity === 'high' ? 'Alta' : call.complaintDetails.severity === 'medium' ? 'Media' : 'Baja'})`;
      }
      
      const outcomeMap: Record<string, string> = {
        'appointment': 'Cita',
        'faq': 'Pregunta',
        'complaint': 'Queja',
        'other': 'Otro'
      };
      
      return [
        format(call.date, "yyyy-MM-dd HH:mm:ss"),
        call.duration.toString(),
        outcomeMap[call.outcome] || call.outcome,
        call.successful ? 'Sí' : 'No',
        details,
        call.conversationSummary
      ];
    });
    
    // Combine headers and rows
    const csvContent = [
      headers.join(','),
      ...csvRows.map(row => row.join(','))
    ].join('\n');
    
    // Create a blob and download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `llamadas_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  
  // Function to prepare data for service requests bar chart
  const prepareServicesData = () => {
    if (!analytics) return [];
    
    return Object.entries(analytics.serviceRequestCounts).map(([service, count]) => ({
      name: service,
      value: count,
    }));
  };
  
  // Function to prepare data for conversion rate chart
  const prepareConversionData = () => {
    if (!analytics) return [];
    
    return [
      { name: 'Convertidas', value: analytics.appointmentsBooked },
      { name: 'No Convertidas', value: analytics.totalCalls - analytics.appointmentsBooked }
    ];
  };
  
  // Function to prepare data for call type distribution chart
  const prepareCallTypeData = () => {
    if (!analytics) return [];
    
    return [
      { name: 'Exitosas', value: analytics.totalCalls * (analytics.successRate / 100) },
      { name: 'No Exitosas', value: analytics.totalCalls * (1 - analytics.successRate / 100) }
    ];
  };
  
  // Function to prepare data for calls by date line chart
  const prepareCallsByDateData = () => {
    if (!analytics) return [];
    
    return analytics.callsByDate.map(item => ({
      date: format(new Date(item.date), "dd MMM", { locale: es }),
      llamadas: item.count,
    }));
  };
  
  const handlePeriodChange = (value: string) => {
    setPeriod(value as AnalyticsPeriod);
  };
  
  const handleStartDateChange = (date: Date | undefined) => {
    if (date) {
      setStartDate(date);
      setPeriod("custom");
    }
  };
  
  const handleEndDateChange = (date: Date | undefined) => {
    if (date) {
      setEndDate(date);
      setPeriod("custom");
    }
  };
  
  // Generate sample data for demonstration purposes
  const generateSampleData = async () => {
    if (!user) return;
    
    try {
      const scenarios = [
        {
          scenarioId: "scenario-appointment",
          scenarioName: "Solicitud de cita",
          successful: true,
          conversationSummary: "Cliente solicitó información sobre servicios y agendó una cita",
          appointmentStatus: "confirmed",
          appointmentService: "Corte de cabello",
          outcome: "appointment"
        },
        {
          scenarioId: "scenario-appointment-2",
          scenarioName: "Solicitud de cita - Peluquería",
          successful: true,
          conversationSummary: "Cliente solicitó un turno para servicio de peluquería",
          appointmentStatus: "confirmed",
          appointmentService: "Peluquería",
          outcome: "appointment"
        },
        {
          scenarioId: "scenario-appointment-3",
          scenarioName: "Solicitud de cita - Manicura",
          successful: true,
          conversationSummary: "Cliente agendó una cita para servicio de manicura",
          appointmentStatus: "confirmed",
          appointmentService: "Manicura",
          outcome: "appointment"
        },
        {
          scenarioId: "scenario-faq",
          scenarioName: "Pregunta sobre horarios",
          successful: true,
          conversationSummary: "Cliente preguntó sobre horarios de atención",
          outcome: "faq"
        },
        {
          scenarioId: "scenario-faq-2",
          scenarioName: "Pregunta sobre servicios",
          successful: true,
          conversationSummary: "Cliente preguntó sobre los servicios disponibles",
          outcome: "faq"
        },
        {
          scenarioId: "scenario-complaint",
          scenarioName: "Queja sobre servicio",
          successful: false,
          conversationSummary: "Cliente presentó una queja sobre el servicio recibido",
          outcome: "complaint"
        }
      ];
      
      // Generate dates within the last month
      const now = new Date();
      const pastMonth = new Date();
      pastMonth.setMonth(now.getMonth() - 1);
      
      // Create 15 sample call records with varying dates
      for (let i = 0; i < 15; i++) {
        // Select random scenario
        const scenario = scenarios[Math.floor(Math.random() * scenarios.length)];
        
        // Generate random date within the past month
        const date = new Date(pastMonth.getTime() + Math.random() * (now.getTime() - pastMonth.getTime()));
        
        // Random duration between 1-5 minutes
        const duration = Math.floor(Math.random() * 240) + 60;
        
        // Random success rate (80% success for non-complaints)
        const successful = scenario.outcome === 'complaint' ? false : Math.random() < 0.8;
        
        await brain.convert_simulation_to_call({
          simulationId: `sim-${Date.now()}-${i}`,
          scenarioId: scenario.scenarioId,
          scenarioName: scenario.scenarioName,
          date: date,
          successful: successful,
          conversationSummary: scenario.conversationSummary,
          appointmentStatus: scenario.appointmentStatus || null,
          appointmentService: scenario.appointmentService || null,
          duration: duration,
        });
        
        // Small delay to prevent overlapping timestamps
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      
      // Reload analytics
      fetchCalls(user.uid);
    } catch (error) {
      console.error("Error generating sample data", error);
    }
  };
  
  if (isLoading) {
    return (
      <div className="p-8 animate-pulse">
        <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-32 bg-gray-200 rounded"></div>
          ))}
        </div>
        <div className="h-64 bg-gray-200 rounded mt-6"></div>
      </div>
    );
  }
  
  return (
    <div id="analytics-dashboard" className={className}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Análisis de Llamadas</h2>
        
        <div className="flex space-x-4">
          <Select value={period} onValueChange={handlePeriodChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Seleccionar período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Hoy</SelectItem>
              <SelectItem value="week">Última semana</SelectItem>
              <SelectItem value="month">Último mes</SelectItem>
              <SelectItem value="custom">Personalizado</SelectItem>
            </SelectContent>
          </Select>
          
          {period === "custom" && (
            <div className="flex space-x-2">
              <DatePicker
                date={startDate}
                onDateChange={handleStartDateChange}
                placeholder="Fecha inicial"
              />
              <DatePicker
                date={endDate}
                onDateChange={handleEndDateChange}
                placeholder="Fecha final"
              />
            </div>
          )}
          
          {calls.length > 0 && (
            <div className="flex gap-2">
              <Button 
                onClick={exportCallsCSV} 
                variant="outline" 
                className="flex items-center gap-2"
              >
                <Download size={16} />
                <span>CSV</span>
              </Button>
              <Button 
                onClick={exportPDF} 
                variant="outline" 
                className="flex items-center gap-2"
              >
                <FileText size={16} />
                <span>PDF</span>
              </Button>
            </div>
          )}
        </div>
      </div>
      
      {calls.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <h3 className="text-lg font-medium mb-4">No hay datos de llamadas disponibles</h3>
          <p className="text-gray-500 mb-6">No se encontraron registros de llamadas en el período seleccionado.</p>
          <button 
            onClick={generateSampleData}
            className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-md flex items-center"
          >
            <span>Generar datos de muestra</span>
            <span className="ml-2 text-xs">(15 llamadas de diferentes tipos)</span>
          </button>
        </div>
      ) : (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Total de Llamadas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-orange-500">{analytics?.totalCalls || 0}</div>
                <p className="text-sm text-gray-500">{period === "today" ? "Hoy" : period === "week" ? "Esta semana" : "Este mes"}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Duración Promedio</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-orange-500">
                  {analytics ? formatDuration(analytics.averageDuration) : "0m 0s"}
                </div>
                <p className="text-sm text-gray-500">Por llamada</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Citas Agendadas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-orange-500">{analytics?.appointmentsBooked || 0}</div>
                <p className="text-sm text-gray-500">
                  Tasa de conversión: <span className="font-semibold text-orange-500">{analytics ? analytics.appointmentsBookedRate.toFixed(1) : 0}%</span>
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Tasa de Éxito</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-orange-500">
                  {analytics ? analytics.successRate.toFixed(1) : 0}%
                </div>
                <p className="text-sm text-gray-500">Llamadas resueltas satisfactoriamente</p>
              </CardContent>
            </Card>
          </div>
          
          {/* Tabs for detailed analytics */}
          <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-4">
            <TabsList className="bg-transparent border-b w-full justify-start p-0 space-x-8">
              <TabsTrigger 
                value="resumen" 
                className="px-0 py-2 font-medium text-gray-600 border-b-2 border-transparent data-[state=active]:text-orange-500 data-[state=active]:border-orange-500 data-[state=active]:shadow-none rounded-none bg-transparent"
              >
                Resumen
              </TabsTrigger>
              <TabsTrigger 
                value="llamadas" 
                className="px-0 py-2 font-medium text-gray-600 border-b-2 border-transparent data-[state=active]:text-orange-500 data-[state=active]:border-orange-500 data-[state=active]:shadow-none rounded-none bg-transparent"
              >
                Llamadas por Día
              </TabsTrigger>
              <TabsTrigger 
                value="tipos" 
                className="px-0 py-2 font-medium text-gray-600 border-b-2 border-transparent data-[state=active]:text-orange-500 data-[state=active]:border-orange-500 data-[state=active]:shadow-none rounded-none bg-transparent"
              >
                Tipos de Llamadas
              </TabsTrigger>
              <TabsTrigger 
                value="servicios" 
                className="px-0 py-2 font-medium text-gray-600 border-b-2 border-transparent data-[state=active]:text-orange-500 data-[state=active]:border-orange-500 data-[state=active]:shadow-none rounded-none bg-transparent"
              >
                Servicios Solicitados
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="resumen" className="pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Distribución por Tipo</CardTitle>
                    <CardDescription>Distribución de llamadas por tipo de resultado</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={prepareOutcomeData()}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={100}
                            fill="#8884d8"
                            paddingAngle={5}
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {prepareOutcomeData().map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value: any) => [`${value} llamadas`, "Cantidad"]} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Servicios Más Solicitados</CardTitle>
                    <CardDescription>Distribución por tipo de servicio solicitado</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={prepareServicesData()}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip formatter={(value: any) => [`${value} solicitudes`, "Cantidad"]} />
                          <Bar dataKey="value" fill="#ff9800" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Add a section for common questions/FAQs */}
              {analytics && analytics.faqsAnswered > 0 && (
                <Card className="mt-8">
                  <CardHeader>
                    <CardTitle>Preguntas Frecuentes</CardTitle>
                    <CardDescription>Preguntas más comunes de los clientes ({analytics.faqsAnswered} preguntas respondidas)</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {analytics.outcomeCounts.faq > 0 ? (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {/* Sample FAQ items - in a real app, these would come from the database */}
                          {[
                            { question: "¿Cuáles son sus horarios de atención?", count: Math.floor(analytics.outcomeCounts.faq * 0.3) },
                            { question: "¿Qué servicios ofrecen?", count: Math.floor(analytics.outcomeCounts.faq * 0.25) },
                            { question: "¿Cuáles son sus precios?", count: Math.floor(analytics.outcomeCounts.faq * 0.2) },
                            { question: "¿Se puede cancelar una cita?", count: Math.floor(analytics.outcomeCounts.faq * 0.15) },
                            { question: "¿Necesito hacer cita previa?", count: Math.floor(analytics.outcomeCounts.faq * 0.1) }
                          ].map((faq, index) => (
                            <div key={index} className="bg-gray-50 rounded-lg p-4 border border-gray-100">
                              <div className="flex justify-between items-start">
                                <p className="font-medium text-gray-800">{faq.question}</p>
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                  {faq.count} veces
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="mt-4 text-sm text-center text-gray-500">
                          <p>Estas son las preguntas más frecuentes detectadas por el sistema.</p>
                          <p>Considere agregar esta información a su sitio web para reducir llamadas innecesarias.</p>
                        </div>
                      </div>
                    ) : (
                      <p className="text-center text-gray-500 italic">No hay suficientes datos para mostrar preguntas frecuentes.</p>
                    )}
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            <TabsContent value="llamadas" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Llamadas por Día</CardTitle>
                  <CardDescription>Tendencia de volumen de llamadas</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-96">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={prepareCallsByDateData()}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip formatter={(value: any) => [`${value} llamadas`, "Cantidad"]} />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="llamadas" 
                          stroke="#ff9800" 
                          activeDot={{ r: 8 }} 
                          strokeWidth={2}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="tipos" className="pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Distribución por Tipo de Llamada</CardTitle>
                    <CardDescription>Desglose detallado por tipo y resultado</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={prepareOutcomeData()}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip formatter={(value: any) => [`${value} llamadas`, "Cantidad"]} />
                          <Bar dataKey="value" fill="#ff9800" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Tasa de Éxito de Llamadas</CardTitle>
                    <CardDescription>Proporción de llamadas exitosas vs no exitosas</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={prepareCallTypeData()}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={100}
                            fill="#8884d8"
                            paddingAngle={5}
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {prepareCallTypeData().map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={index === 0 ? "#4caf50" : "#f44336"} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value: any) => [`${Math.round(value)} llamadas`, "Cantidad"]} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Tasa de Conversión de Citas</CardTitle>
                  <CardDescription>Proporción de llamadas que resultaron en citas agendadas</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={prepareConversionData()}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          fill="#8884d8"
                          paddingAngle={5}
                          dataKey="value"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {prepareConversionData().map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={index === 0 ? "#ff9800" : "#e0e0e0"} />
                          ))}
                        </Pie>
                        <Legend />
                        <Tooltip formatter={(value: any) => [`${Math.round(value)} llamadas`, "Cantidad"]} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="mt-4 text-center">
                    <p className="text-lg font-medium">Tasa de Conversión: <span className="text-orange-500 font-bold">{analytics ? analytics.appointmentsBookedRate.toFixed(1) : 0}%</span></p>
                    <p className="text-sm text-gray-500">De {analytics?.totalCalls || 0} llamadas, {analytics?.appointmentsBooked || 0} resultaron en citas confirmadas</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="servicios" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Servicios Solicitados</CardTitle>
                  <CardDescription>Análisis detallado de servicios</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-96">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={prepareServicesData()}
                          cx="50%"
                          cy="50%"
                          outerRadius={120}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {prepareServicesData().map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value: any) => [`${value} solicitudes`, "Cantidad"]} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          
          {/* Recent Call List */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Llamadas Recientes</CardTitle>
              <CardDescription>Últimas llamadas recibidas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="pb-2 font-medium">Fecha</th>
                      <th className="pb-2 font-medium">Duración</th>
                      <th className="pb-2 font-medium">Resultado</th>
                      <th className="pb-2 font-medium">Detalles</th>
                      <th className="pb-2 font-medium">Estado</th>
                    </tr>
                  </thead>
                  <tbody>
                    {calls.slice(0, 5).map((call, index) => (
                      <tr key={call.id || index} className={index % 2 === 0 ? 'bg-gray-50' : ''}>
                        <td className="py-3">{format(call.date, "d 'de' MMMM, HH:mm", { locale: es })}</td>
                        <td className="py-3">{formatDuration(call.duration)}</td>
                        <td className="py-3">
                          {call.outcome === 'appointment' && 'Cita'}
                          {call.outcome === 'faq' && 'Pregunta'}
                          {call.outcome === 'complaint' && 'Queja'}
                          {call.outcome === 'other' && 'Otro'}
                        </td>
                        <td className="py-3">
                          {call.outcome === 'appointment' && call.appointmentDetails && 
                            `${call.appointmentDetails.service}, ${format(call.appointmentDetails.date, "d 'de' MMMM", { locale: es })}`}
                          {call.outcome === 'faq' && call.faqDetails && 
                            call.faqDetails.topic}
                          {call.outcome === 'complaint' && call.complaintDetails && 
                            `${call.complaintDetails.topic} (${call.complaintDetails.severity === 'high' ? 'Alta' : call.complaintDetails.severity === 'medium' ? 'Media' : 'Baja'})`}
                        </td>
                        <td className="py-3">
                          {call.successful ? (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              Exitosa
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                              No exitosa
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

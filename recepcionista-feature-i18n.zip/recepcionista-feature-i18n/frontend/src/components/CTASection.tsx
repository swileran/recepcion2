import React from "react";
import { useNavigate } from "react-router-dom";
import { APP_BASE_PATH } from "app";
import { useTranslation } from 'react-i18next';

interface Props {
  title: string;
  subtitle: string;
  ctaText: string;
  onCtaClick: () => void;
}

export function CTASection({ title, subtitle, ctaText, onCtaClick }: Props) {
  const navigate = useNavigate();
  const { t } = useTranslation();

  const handleCtaClick = () => {
    navigate(`/login?signup=true`);
  };
  
  return (
    <div className="w-full py-16 bg-gradient-to-r from-orange-500 to-red-500">
      <div className="max-w-4xl mx-auto text-center px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
          {t('home.cta.title')}
        </h2>
        <p className="text-xl text-white text-opacity-90 mb-10 max-w-2xl mx-auto leading-relaxed">
          {t('home.cta.subtitle')}
        </p>
        <a
          href={`/login?signup=true`}
          className="inline-block px-8 py-3 bg-white text-orange-600 text-lg font-medium rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
        >
          {t('home.cta.button')}
        </a>
      </div>
    </div>
  );
}

import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { firebaseApp } from "app";
import { getFirestore, doc, setDoc } from "firebase/firestore";
import { useCurrentUser } from "app";
import { toast } from "sonner";

// Initialize Firestore
const db = getFirestore(firebaseApp);

export interface Props {
  currentIntegration?: "twilio" | "meta" | null;
  onSelectIntegration: (integration: "twilio" | "meta") => void;
}

export const WhatsAppIntegrationSelector: React.FC<Props> = ({ 
  currentIntegration, 
  onSelectIntegration 
}) => {
  const [selectedIntegration, setSelectedIntegration] = useState<"twilio" | "meta">(currentIntegration || "meta");
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useCurrentUser();

  const handleSaveSelection = async () => {
    if (!user) {
      toast.error("Debes iniciar sesión para guardar la configuración");
      return;
    }

    setIsLoading(true);

    try {
      // Save selection to Firestore
      await setDoc(doc(db, `users/${user.uid}/config/whatsapp_integration`), {
        provider: selectedIntegration,
        updatedAt: new Date()
      }, { merge: true });

      // Call the callback with the selected integration
      onSelectIntegration(selectedIntegration);
      
      toast.success("Integración seleccionada correctamente");
    } catch (error) {
      console.error("Error saving WhatsApp integration selection:", error);
      toast.error("Error al guardar la selección");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Seleccionar Integración de WhatsApp</CardTitle>
        <CardDescription>
          Elige el proveedor de integración de WhatsApp que prefieras usar
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <RadioGroup 
          value={selectedIntegration} 
          onValueChange={(value) => setSelectedIntegration(value as "twilio" | "meta")}
          className="space-y-4"
        >
          <div className="flex items-start space-x-3 p-3 border rounded-md transition-all hover:border-orange-200 hover:bg-orange-50">
            <RadioGroupItem value="meta" id="meta" className="mt-1" />
            <div className="space-y-1">
              <Label htmlFor="meta" className="font-medium">Meta WhatsApp Cloud API (Recomendado)</Label>
              <p className="text-sm text-muted-foreground">
                Integración directa con Meta, más fácil de configurar y sin intermediarios. Recomendado para la mayoría de usuarios.
              </p>
              <div className="text-sm mt-1">
                <span className="inline-block bg-green-100 text-green-800 px-2 py-0.5 rounded-md text-xs font-medium">Más simple</span>
                <span className="inline-block ml-2 bg-green-100 text-green-800 px-2 py-0.5 rounded-md text-xs font-medium">Sin intermediarios</span>
                <span className="inline-block ml-2 bg-green-100 text-green-800 px-2 py-0.5 rounded-md text-xs font-medium">Integración directa</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-3 border rounded-md transition-all hover:border-orange-200 hover:bg-orange-50">
            <RadioGroupItem value="twilio" id="twilio" className="mt-1" />
            <div className="space-y-1">
              <Label htmlFor="twilio" className="font-medium">Twilio WhatsApp API (Avanzado)</Label>
              <p className="text-sm text-muted-foreground">
                Integración a través de Twilio. Opciones avanzadas pero requiere un proceso de configuración más complejo.
              </p>
              <div className="text-sm mt-1">
                <span className="inline-block bg-blue-100 text-blue-800 px-2 py-0.5 rounded-md text-xs font-medium">Funciones avanzadas</span>
                <span className="inline-block ml-2 bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded-md text-xs font-medium">Configuración compleja</span>
              </div>
            </div>
          </div>
        </RadioGroup>
      </CardContent>
      
      <CardFooter>
        <Button 
          onClick={handleSaveSelection} 
          disabled={isLoading}
          className="w-full bg-orange-500 hover:bg-orange-600"
        >
          {isLoading ? "Guardando..." : "Continuar con esta integración"}
        </Button>
      </CardFooter>
    </Card>
  );
};

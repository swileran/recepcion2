import React, { useState, useEffect } from "react";
import { useCurrentUser } from "app";
import { useMetaWhatsAppStore } from "utils/metaWhatsappStore";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Loader2, Send, RefreshCw, CheckCircle2, XCircle, Clock } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

export interface Props {
  onMessageSent?: (to: string, message: string) => void;
}

export const MetaWhatsAppInterface: React.FC<Props> = ({ onMessageSent }) => {
  const { user } = useCurrentUser();
  const [phoneNumber, setPhoneNumber] = useState("");
  const [message, setMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  
  // Get store functions and state
  const { 
    messages,
    activePhone,
    isLoading,
    error,
    setUser,
    setActivePhone,
    sendMessage,
    fetchConversations
  } = useMetaWhatsAppStore();
  
  // Set the user in the store when it changes
  useEffect(() => {
    setUser(user);
  }, [user, setUser]);
  
  // Fetch conversations when the component mounts
  useEffect(() => {
    let unsubscribe = () => {};
    
    if (user) {
      fetchConversations().then((unsub) => {
        unsubscribe = unsub;
      });
    }
    
    return () => {
      unsubscribe();
    };
  }, [user, fetchConversations]);
  
  // Active conversation
  const activeConversation = activePhone ? messages[activePhone] || [] : [];
  
  // Get unique phone numbers (conversations)
  const conversations = Object.keys(messages);
  
  // Handle sending a message
  const handleSendMessage = async () => {
    if (!phoneNumber && !activePhone) {
      toast.error("Por favor, ingresa un número de teléfono");
      return;
    }
    
    if (!message.trim()) {
      toast.error("Por favor, ingresa un mensaje");
      return;
    }
    
    const targetPhone = activePhone || phoneNumber;
    
    setIsSending(true);
    try {
      await sendMessage(targetPhone, message);
      setMessage(""); // Clear message after sending
      
      if (onMessageSent) {
        onMessageSent(targetPhone, message);
      }
      
      // If this is a new conversation, set it as active
      if (!activePhone && phoneNumber) {
        setActivePhone(phoneNumber);
        setPhoneNumber(""); // Clear the phone input
      }
    } catch (error) {
      console.error("Error sending message:", error);
    } finally {
      setIsSending(false);
    }
  };
  
  // Format the timestamp for display
  const formatTime = (date: Date) => {
    return formatDistanceToNow(date, { addSuffix: true, locale: es });
  };
  
  // Get status icon based on message status
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "delivered":
        return <CheckCircle2 className="h-4 w-4 text-blue-500" />;
      case "read":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };
  
  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>WhatsApp Business Cloud API</CardTitle>
        <CardDescription>
          Envía y recibe mensajes de WhatsApp utilizando la API oficial de Meta.
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="chat" className="w-full">
          <TabsList className="w-full mb-4">
            <TabsTrigger value="chat" className="flex-1">Chat</TabsTrigger>
            <TabsTrigger value="conversations" className="flex-1">Conversaciones</TabsTrigger>
          </TabsList>
          
          <TabsContent value="chat" className="space-y-4">
            {activePhone ? (
              <div className="mb-4">
                <div className="flex items-center justify-between bg-orange-50 p-3 rounded-md">
                  <div>
                    <span className="font-medium">Conversación con:</span>
                    <Badge variant="outline" className="ml-2">{activePhone}</Badge>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setActivePhone(null)}
                  >
                    Nueva conversación
                  </Button>
                </div>
              </div>
            ) : (
              <div className="mb-4">
                <Label htmlFor="phone-number">Número de teléfono (con código de país)</Label>
                <Input
                  id="phone-number"
                  placeholder="+34600000000"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Ingresa el número con código de país, por ejemplo: +34600000000
                </p>
              </div>
            )}
            
            {activePhone && (
              <ScrollArea className="h-[300px] border rounded-md p-4">
                <div className="space-y-4">
                  {activeConversation.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-muted-foreground">
                      No hay mensajes aún. Envía un mensaje para comenzar.
                    </div>
                  ) : (
                    activeConversation.map((msg) => (
                      <div 
                        key={msg.id}
                        className={`flex ${msg.sender === 'business' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div 
                          className={`max-w-[70%] p-3 rounded-lg ${msg.sender === 'business' 
                            ? 'bg-orange-100 text-orange-900 ml-auto' 
                            : 'bg-gray-100 text-gray-900 mr-auto'}`}
                        >
                          <div className="text-sm">{msg.body}</div>
                          <div className="flex items-center justify-end space-x-1 mt-1">
                            <span className="text-xs text-muted-foreground">
                              {formatTime(msg.timestamp)}
                            </span>
                            {msg.sender === 'business' && getStatusIcon(msg.status)}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="message">Mensaje</Label>
              <Textarea
                id="message"
                placeholder="Escribe tu mensaje..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={3}
              />
            </div>
          </TabsContent>
          
          <TabsContent value="conversations">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : conversations.length > 0 ? (
              <ScrollArea className="h-[400px]">
                <div className="space-y-2">
                  {conversations.map((phone) => {
                    const conversation = messages[phone] || [];
                    const lastMessage = conversation[conversation.length - 1];
                    
                    return (
                      <div key={phone}>
                        <div 
                          className={`p-3 rounded-md hover:bg-muted cursor-pointer transition-colors ${activePhone === phone ? 'bg-orange-50 border border-orange-200' : ''}`}
                          onClick={() => setActivePhone(phone)}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium">{phone}</h4>
                              {lastMessage && (
                                <p className="text-sm text-muted-foreground truncate max-w-[250px]">
                                  {lastMessage.body}
                                </p>
                              )}
                            </div>
                            {lastMessage && (
                              <span className="text-xs text-muted-foreground">
                                {formatTime(lastMessage.timestamp)}
                              </span>
                            )}
                          </div>
                        </div>
                        <Separator className="my-2" />
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <p>No hay conversaciones aún</p>
                <Button 
                  variant="outline" 
                  className="mt-4" 
                  onClick={() => setActivePhone(null)}
                >
                  Iniciar nueva conversación
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      
      <CardFooter>
        <div className="flex w-full justify-between items-center">
          <Button 
            variant="outline" 
            onClick={() => fetchConversations()}
            disabled={isLoading || isSending}
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Actualizar
          </Button>
          
          <Button 
            className="bg-orange-500 hover:bg-orange-600"
            onClick={handleSendMessage}
            disabled={isLoading || isSending || !message.trim() || (!phoneNumber && !activePhone)}
          >
            {isSending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Enviando...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Enviar mensaje
              </>
            )}
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

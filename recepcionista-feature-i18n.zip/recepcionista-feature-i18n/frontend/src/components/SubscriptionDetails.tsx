import { useState, useEffect } from "react";
import { useCurrentUser } from "app";
import { useProfileStore } from "utils/profileStore";
import { useSubscriptionStore } from "utils/subscriptionStore";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export function SubscriptionDetails() {
  const { user } = useCurrentUser();
  const { profile } = useProfileStore();
  const { getCustomerSubscription, createPortalSession } = useSubscriptionStore();
  const [subscription, setSubscription] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isManaging, setIsManaging] = useState(false);

  // Determine if we're in demo mode (for placeholder subscriptions)
  const isDemoMode = window.location.search.includes('status=success') && !subscription;

  const fetchSubscription = async () => {
    if (!user || !profile) return;
    
    setIsLoading(true);
    try {
      // Demo placeholder for now
      if (isDemoMode) {
        // Create a placeholder subscription for demo purposes
        setTimeout(() => {
          const demoSubscription = {
            id: "sub_demo",
            status: "active",
            current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).getTime() / 1000,
            items: {
              data: [
                {
                  id: "si_demo",
                  price: {
                    id: "price_demo",
                    product: {
                      name: localStorage.getItem('selectedPlanName') || "Plan Profesional"
                    },
                    unit_amount: 4900,
                    currency: "eur",
                    recurring: {
                      interval: "month"
                    }
                  }
                }
              ]
            },
            cancel_at_period_end: false
          };
          setSubscription(demoSubscription);
          setIsLoading(false);
        }, 1000);
        return;
      }
      
      // For real subscriptions
      const customerId = profile.stripeCustomerId || user.uid;
      const result = await getCustomerSubscription(customerId);
      
      if (result) {
        setSubscription(result);
      }
    } catch (error) {
      console.error("Error fetching subscription:", error);
      toast.error("No pudimos cargar la información de su suscripción");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchSubscription();
  }, [user, profile]);

  const handleManageSubscription = async () => {
    if (!user || !profile) return;
    
    setIsManaging(true);
    try {
      // Demo mode handling
      if (isDemoMode || (subscription && subscription.id === "sub_demo")) {
        toast.info("Modo de demostración: En producción, serías redirigido al portal de gestión de Stripe");
        setTimeout(() => {
          setIsManaging(false);
        }, 1500);
        return;
      }
      
      // For real subscriptions
      const customerId = profile.stripeCustomerId || user.uid;
      const result = await createPortalSession({
        customer_id: customerId,
        return_url: window.location.origin + "/dashboard?tab=suscripcion"
      });
      
      // Redirect to Stripe portal
      window.location.href = result.url;
    } catch (error) {
      console.error("Error creating portal session:", error);
      toast.error("No pudimos abrir el portal de gestión de suscripción");
      setIsManaging(false);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleDateString('es-ES', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const formatPrice = (amount: number, currency: string) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0
    }).format(amount / 100);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Activa</Badge>;
      case "canceled":
        return <Badge className="bg-gray-500">Cancelada</Badge>;
      case "past_due":
        return <Badge className="bg-yellow-500">Pago pendiente</Badge>;
      case "unpaid":
        return <Badge className="bg-red-500">Impago</Badge>;
      default:
        return <Badge className="bg-blue-500">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-4 w-1/2 mt-2" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        </CardContent>
        <CardFooter>
          <Skeleton className="h-10 w-full" />
        </CardFooter>
      </Card>
    );
  }

  if (!subscription && !isDemoMode) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Sin suscripción activa</CardTitle>
          <CardDescription>Actualmente no tiene ninguna suscripción activa.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">
            Para aprovechar todas las funciones de Recepcionista.ai, seleccione uno de nuestros planes de suscripción.
          </p>
        </CardContent>
        <CardFooter>
          <Button
            onClick={() => window.location.href = "/suscripcion"}
            className="w-full bg-orange-500 hover:bg-orange-600"
          >
            Ver planes
          </Button>
        </CardFooter>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>Detalles de Suscripción</CardTitle>
            <CardDescription>Gestione su plan y facturación</CardDescription>
          </div>
          {subscription && getStatusBadge(subscription.status)}
        </div>
      </CardHeader>
      <CardContent>
        {subscription && (
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-semibold text-gray-500">Plan Actual</h4>
              <p className="text-lg font-medium">{subscription.items.data[0]?.price.product.name || "Plan Personalizado"}</p>
            </div>
            
            <div>
              <h4 className="text-sm font-semibold text-gray-500">Precio</h4>
              <p className="text-lg font-medium">
                {formatPrice(
                  subscription.items.data[0]?.price.unit_amount || 0,
                  subscription.items.data[0]?.price.currency || "eur"
                )}
                <span className="text-sm text-gray-500 ml-1">
                  /{subscription.items.data[0]?.price.recurring.interval === "month" ? "mes" : "año"}
                </span>
              </p>
            </div>
            
            <div>
              <h4 className="text-sm font-semibold text-gray-500">Próxima facturación</h4>
              <p className="text-base">{formatDate(subscription.current_period_end)}</p>
              {subscription.cancel_at_period_end && (
                <p className="text-sm text-orange-500 mt-1">
                  Su suscripción finalizará al final de este período
                </p>
              )}
            </div>

            {(isDemoMode || subscription.id === "sub_demo") && (
              <div className="rounded-md bg-orange-100 p-3">
                <p className="text-sm text-orange-600 font-medium">
                  Modo demostración: Esta es una suscripción de muestra para fines de demostración.
                </p>
              </div>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button
          onClick={handleManageSubscription}
          disabled={isManaging}
          className="w-full bg-orange-500 hover:bg-orange-600"
        >
          {isManaging ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Procesando...
            </span>
          ) : (
            'Gestionar suscripción'
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}

import React from "react";
import { FiClock, FiCalendar, FiDollarSign, FiMessageCircle, FiSmartphone } from "react-icons/fi";
import { useTranslation } from 'react-i18next';

interface BenefitItemProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

function BenefitItem({ icon, title, description }: BenefitItemProps) {
  return (
    <div className="flex flex-col items-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 border-t-4 border-orange-400">
      <div className="mb-4 text-orange-500 p-3 bg-orange-100 rounded-full">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3 text-gray-800">{title}</h3>
      <p className="text-gray-600 text-center">{description}</p>
    </div>
  );
}

export function BenefitsSection() {
  const { t } = useTranslation();
  
  const benefits = [
    {
      icon: <FiClock size={24} />,
      title: t('components.benefitsSection.items.0.title'),
      description: t('components.benefitsSection.items.0.description')
    },
    {
      icon: <FiCalendar size={24} />,
      title: t('components.benefitsSection.items.1.title'),
      description: t('components.benefitsSection.items.1.description')
    },
    {
      icon: <FiSmartphone size={24} />,
      title: t('components.benefitsSection.items.2.title'),
      description: t('components.benefitsSection.items.2.description')
    },
    {
      icon: <FiDollarSign size={24} />,
      title: t('components.benefitsSection.items.3.title'),
      description: t('components.benefitsSection.items.3.description')
    },
    {
      icon: <FiMessageCircle size={24} />,
      title: t('components.benefitsSection.items.4.title'),
      description: t('components.benefitsSection.items.4.description')
    }
  ];

  return (
    <div className="w-full py-16 bg-amber-50">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-900 mx-auto max-w-3xl">
          {t('components.benefitsSection.title')}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {benefits.map((benefit, index) => (
            <BenefitItem
              key={index}
              icon={benefit.icon}
              title={benefit.title}
              description={benefit.description}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

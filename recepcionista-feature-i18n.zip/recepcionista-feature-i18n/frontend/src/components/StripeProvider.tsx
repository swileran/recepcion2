import { ReactNode, useEffect, useState } from "react";
import { loadStripe, Stripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import { stripeConfig } from "../utils/stripeConfig";

interface StripeProviderProps {
  children: ReactNode;
}

export function StripeProvider({ children }: StripeProviderProps) {
  const [stripePromise, setStripePromise] = useState<Promise<Stripe | null> | null>(null);

  useEffect(() => {
    if (!stripePromise) {
      setStripePromise(loadStripe(stripeConfig.publishableKey));
    }
  }, [stripePromise]);

  if (!stripePromise) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  return <Elements stripe={stripePromise}>{children}</Elements>;
}

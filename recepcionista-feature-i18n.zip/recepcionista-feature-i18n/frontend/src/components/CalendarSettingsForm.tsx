import { useState, useEffect } from "react";
import { useCurrentUser } from "app";
import { useProfileStore } from "../utils/store";
import { FiSave, FiX } from "react-icons/fi";

interface FormErrors {
  appointmentDuration?: string;
  bufferTime?: string;
  maxAdvanceBookingDays?: string;
}

export function CalendarSettingsForm() {
  const { user, loading: userLoading } = useCurrentUser();
  const { profile, updateProfile, isLoading, error } = useProfileStore();
  
  const [formErrors, setFormErrors] = useState<FormErrors>({});
  const [formSuccess, setFormSuccess] = useState("");
  
  // Form state (ensure they're explicitly typed as numbers with default values)
  const [appointmentDuration, setAppointmentDuration] = useState<number>(30); // Default: 30 minutes
  const [bufferTime, setBufferTime] = useState<number>(5); // Default: 5 minutes
  const [maxAdvanceBookingDays, setMaxAdvanceBookingDays] = useState<number>(30); // Default: 30 days
  const [googleCalendarIntegrated, setGoogleCalendarIntegrated] = useState<boolean>(false);
  const [googleCalendarId, setGoogleCalendarId] = useState<string>("");
  
  useEffect(() => {
    // Clear any validation errors initially
    setFormErrors({});
    
    // Check if user is authenticated
    if (!userLoading && !user) {
      setFormErrors({
        appointmentDuration: "No autenticado. Por favor, inicia sesión para acceder a esta funcionalidad."
      });
      return;
    }
    
    // Make sure numeric values are explicitly cast to numbers
    if (profile?.calendarSettings) {
      setAppointmentDuration(Number(profile.calendarSettings.appointmentDuration) || 30);
      setBufferTime(Number(profile.calendarSettings.bufferTime) || 5);
      setMaxAdvanceBookingDays(Number(profile.calendarSettings.maxAdvanceBookingDays) || 30);
      setGoogleCalendarIntegrated(!!profile.calendarSettings.googleCalendarIntegrated);
      setGoogleCalendarId(profile.calendarSettings.googleCalendarId || "");
    }
  }, [profile]);
  
  // Form validation - ensure numbers are in reasonable ranges
  const validateForm = (): boolean => {
    const errors: FormErrors = {};
    
    // Validate appointment duration (15min - 4hrs)
    if (appointmentDuration < 15 || appointmentDuration > 240) {
      errors.appointmentDuration = "La duración de la cita debe estar entre 15 minutos y 4 horas";
    }
    
    // Validate buffer time (0min - 60min)
    if (bufferTime < 0 || bufferTime > 60) {
      errors.bufferTime = "El tiempo entre citas debe estar entre 0 y 60 minutos";
    }
    
    // Validate advance booking days (1 day - 180 days)
    if (maxAdvanceBookingDays < 1 || maxAdvanceBookingDays > 180) {
      errors.maxAdvanceBookingDays = "Los días de anticipación deben estar entre 1 y 180 días";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  // Deep clean an object to remove undefined values (Firestore doesn't accept undefined)
  const deepClean = (obj: Record<string, any>): Record<string, any> => {
    if (obj === null || typeof obj !== 'object') {
      return obj;
    }
    
    if (Array.isArray(obj)) {
      return obj.map(item => deepClean(item)).filter(item => item !== undefined);
    }
    
    const cleaned: Record<string, any> = {};
    
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        const value = obj[key];
        
        // Process based on value type
        if (value === undefined) {
          // Skip undefined values completely
          continue;
        } else if (value === null) {
          // Keep null values as-is
          cleaned[key] = null;
        } else if (typeof value === 'object') {
          // Recursively clean objects and arrays
          const cleanedValue = deepClean(value);
          // Only add if the cleaned object/array is not empty
          if (Array.isArray(cleanedValue) ? cleanedValue.length > 0 : Object.keys(cleanedValue).length > 0) {
            cleaned[key] = cleanedValue;
          }
        } else {
          // For primitives, add them directly
          cleaned[key] = value;
        }
      }
    }
    
    return cleaned;
  };
  
  // Handle form submission and save calendar settings
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSuccess("");
    
    if (!validateForm()) {
      return;
    }
    
    if (!profile?.id || !user) {
      return;
    }
    
    try {
      // Prepare calendar settings data with proper typing - ensure valid integer values
      const calendarSettings: Record<string, any> = {
        appointmentDuration: Number(appointmentDuration),
        bufferTime: Number(bufferTime),
        maxAdvanceBookingDays: Number(maxAdvanceBookingDays),
        googleCalendarIntegrated: googleCalendarIntegrated // Already boolean
      };
      
      // Only add googleCalendarId if it's integrated and has a value
      if (googleCalendarIntegrated && selectedCalendarId) {
        calendarSettings.googleCalendarId = selectedCalendarId;
      } else if (googleCalendarIntegrated && googleCalendarId) {
        // If already connected but no new calendar selected, keep existing ID
        calendarSettings.googleCalendarId = googleCalendarId;
      } else {
        // Explicitly set to null (not undefined) when not integrated
        calendarSettings.googleCalendarId = null;
      }
      
      console.log('Raw calendar settings before cleaning:', JSON.stringify(calendarSettings));
      
      // Clean the data to remove any undefined values that would cause Firestore errors
      const cleanedCalendarSettings = deepClean(calendarSettings);
      console.log('Cleaned calendar settings for Firestore:', JSON.stringify(cleanedCalendarSettings));
      
      // Update profile with calendar settings
      await updateProfile(profile.id, {
        calendarSettings: cleanedCalendarSettings
      });
      
      // Show success message with more details
      const hasCalendarId = googleCalendarIntegrated && (selectedCalendarId || googleCalendarId);
      setFormSuccess(
        `¡Configuración de calendario guardada con éxito! ${googleCalendarIntegrated 
          ? (hasCalendarId 
             ? 'Tus citas se sincronizarán con Google Calendar.' 
             : 'La integración con Google Calendar está habilitada pero no hay calendario seleccionado.')
          : 'Los ajustes se aplicarán a todas las nuevas citas.'}`
      );
      
      console.log('Calendar settings saved. Integration:', 
                   googleCalendarIntegrated, 
                   'CalendarId:', 
                   hasCalendarId ? (selectedCalendarId || googleCalendarId) : 'none');
      
      // Reset calendar settings from profile to ensure consistency with latest data
      if (profile?.calendarSettings) {
        setAppointmentDuration(Number(profile.calendarSettings.appointmentDuration) || 30);
        setBufferTime(Number(profile.calendarSettings.bufferTime) || 5);
        setMaxAdvanceBookingDays(Number(profile.calendarSettings.maxAdvanceBookingDays) || 30);
        setGoogleCalendarIntegrated(!!profile.calendarSettings.googleCalendarIntegrated);
        setGoogleCalendarId(profile.calendarSettings.googleCalendarId || "");
      }
      
      // Clear errors on success
      setFormErrors({});
      
      // Auto-dismiss success message after 5 seconds
      setTimeout(() => setFormSuccess(""), 5000);
      
    } catch (error) {
      console.error("Error saving calendar settings:", error);
      const errorMessage = error instanceof Error ? error.message : "Error al guardar la configuración. Inténtalo de nuevo.";
      setFormErrors({ ...formErrors, appointmentDuration: errorMessage });
    }
  };

  // Google Calendar OAuth integration
  const handleConnectGoogleCalendar = async () => {
    try {
      setFormErrors({});
      setFormSuccess("");
      
      // Always attempt connection, but show appropriate feedback based on auth state
      if (!user) {
        console.log("User not authenticated, showing warning but attempting connection");
        // Show warning but don't prevent trying
        setFormErrors({
          appointmentDuration: "Advertencia: No has iniciado sesión. La integración puede fallar. Inicia sesión primero para mejores resultados."
        });
        // Continue with the attempt - backend will handle the unauthenticated state
      }
      
      console.log("Requesting Google Calendar auth URL...");
      
      // Determine if we're in production or development
      const isProduction = window.location.hostname === "recepcionistaai.com" || 
                         window.location.hostname.includes("databutton.com");
      console.log("Environment detection:", isProduction ? "PRODUCTION" : "DEVELOPMENT", 
                 "Current URL:", window.location.href);
      
      // Pre-check if Google API credentials are configured
      const testResponse = await fetch('/api/google-calendar/auth-url');
      if (!testResponse.ok) {
        const errorData = await testResponse.json();
        console.error('Error connecting to Google Calendar:', errorData);
        
        if (errorData.detail && errorData.detail.includes('Google Client ID not configured')) {
          setFormErrors({ 
            appointmentDuration: 'Error: API de Google Calendar no configurada. Contacta al administrador.'
          });
          return;
        }
        
        throw new Error(errorData.detail || 'Error al conectar con Google Calendar');
      }
      
      // Get the auth URL from our backend
      const data = await testResponse.json();
      console.log("Received auth URL:", data.auth_url);
      
      // Add a message telling the user to choose the same Google account they used for login
      if (user) {
        setFormSuccess("IMPORTANTE: Selecciona la MISMA cuenta de Google que usaste para iniciar sesión en esta aplicación para evitar problemas de autenticación.");
        // Auto-dismiss after 10 seconds
        setTimeout(() => setFormSuccess(""), 15000);
      }
      
      // Open the OAuth consent screen in a popup
      const width = 600;
      const height = 700;
      const left = window.innerWidth / 2 - width / 2;
      const top = window.innerHeight / 2 - height / 2;
      const popup = window.open(
        data.auth_url,
        'google-oauth',
        `width=${width},height=${height},left=${left},top=${top}`
      );
      
      // Monitor the popup for completion
      if (popup) {
        const checkPopup = setInterval(() => {
          if (!popup || popup.closed) {
            clearInterval(checkPopup);
            // Check connection status after popup is closed
            console.log("OAuth popup closed, checking connection status...");
            
            // Add a success message to guide the user
            setFormSuccess("Ventana cerrada. Verificando la conexión con Google Calendar...");
            
            // Wait longer before checking to allow token exchange to complete
            setTimeout(() => {
              checkGoogleCalendarConnection();
            }, 2000);
          }
        }, 500);
      } else {
        console.error("Pop-up window was blocked");
        setFormErrors({ 
          appointmentDuration: 'Error: El navegador bloqueó la ventana. Por favor, permite ventanas emergentes para este sitio.'
        });
      }
    } catch (error) {
      console.error('Error starting Google Calendar OAuth:', error);
      setFormErrors({ 
        appointmentDuration: error instanceof Error ? error.message : 'Error al conectar con Google Calendar'
      });
    }
  };
  
  // Check if the user has connected their Google Calendar
  const checkGoogleCalendarConnection = async () => {
    try {
      // Always attempt connection check, but log appropriate info
      if (!user) {
        console.log("User not authenticated, attempting Google Calendar connection check anyway");
        // Continue with the attempt, backend is now designed to handle unauthenticated requests
      } else {
        console.log("Authenticated user, checking Google Calendar connection status");
      }
      
      console.log("Checking Google Calendar connection status...");
      const response = await fetch('/api/google-calendar/connection-status');
      
      if (!response.ok) {
        console.log("Google Calendar connection check failed:", response.status);
        // Don't change UI state on error, just log
        console.error(`Connection check failed: ${response.status}`);
        
        // Only clear state if we're sure we need to
        if (response.status === 401) {
          setGoogleCalendarIntegrated(false);
          setGoogleCalendarId('');
          
          // Notify user with a helpful message
          setFormErrors({
            appointmentDuration: "No se pudo conectar con Google Calendar. Es posible que necesites volver a autenticarte."
          });
        }
        return;
      }
      
      const data = await response.json();
      console.log("Google Calendar connection status:", data);
      
      if (data.connected) {
        // Clear any previous errors
        setFormErrors({});
        setFormSuccess("Conexión con Google Calendar verificada correctamente!");
        setTimeout(() => setFormSuccess(""), 3000);
        
        setGoogleCalendarIntegrated(true);
        setGoogleCalendarId(data.email || 'Cuenta conectada');
        
        // Fetch calendars
        fetchGoogleCalendars();
      } else {
        console.log("Google Calendar is not connected according to API");
        
        // If the profile has calendar integration enabled but API says not connected
        if (profile?.calendarSettings?.googleCalendarIntegrated) {
          setFormErrors({
            appointmentDuration: "La integración con Google Calendar está activada pero no tienes una conexión activa. Por favor, vuelve a conectar tu cuenta."
          });
        }
        
        setGoogleCalendarIntegrated(false);
        setGoogleCalendarId('');
      }
    } catch (error) {
      console.error('Error checking Google Calendar connection:', error);
      // Don't change state on error, just log
      // Don't set form errors here as it would be displayed under form fields
    }
  };
  
  // Fetch user's Google Calendars
  const [calendars, setCalendars] = useState<Array<{id: string, summary: string}>>([]);
  const [selectedCalendarId, setSelectedCalendarId] = useState('');
  
  const fetchGoogleCalendars = async () => {
    try {
      // Always attempt to fetch calendars, with appropriate logging
      if (!user) {
        console.log("User not authenticated, attempting to fetch Google Calendars anyway");
        // Continue with the attempt, backend is designed to handle unauthenticated requests
      } else {
        console.log("Authenticated user, fetching Google Calendars");
      }
      
      console.log("Fetching Google Calendars...");
      const response = await fetch('/api/google-calendar/calendars');
      
      if (!response.ok) {
        console.error("Failed to fetch Google Calendars:", response.status);
        
        // Handle specific error cases
        if (response.status === 401) {
          setFormErrors({
            appointmentDuration: "No se pudo acceder a tus calendarios. Es posible que necesites volver a conectar tu cuenta de Google."
          });
          // Keep the integration enabled but clear selected calendar
          setSelectedCalendarId("");
        }
        return;
      }
      
      // Clear any errors since fetching succeeded
      if (formErrors.appointmentDuration?.includes("No se pudo acceder a tus calendarios")) {
        setFormErrors({});
      }
      
      const data = await response.json();
      console.log("Fetched calendars:", data.calendars);
      setCalendars(data.calendars);
      
      // Select calendar: first try to match existing ID, then primary, then first in list
      if (profile?.calendarSettings?.googleCalendarId && 
          data.calendars.some((cal: any) => cal.id === profile.calendarSettings.googleCalendarId)) {
        console.log("Using calendar ID from profile:", profile.calendarSettings.googleCalendarId);
        setSelectedCalendarId(profile.calendarSettings.googleCalendarId);
      } else {
        const primaryCalendar = data.calendars.find((cal: any) => cal.primary);
        if (primaryCalendar) {
          console.log("Setting primary calendar:", primaryCalendar.id);
          setSelectedCalendarId(primaryCalendar.id);
        } else if (data.calendars.length > 0) {
          console.log("Setting first calendar:", data.calendars[0].id);
          setSelectedCalendarId(data.calendars[0].id);
        }
      }
      
      setFormSuccess("Calendarios cargados correctamente");
      setTimeout(() => setFormSuccess(""), 2000);
    } catch (error) {
      console.error('Error fetching Google Calendars:', error);
      // Don't change any state on error, but log clearly
      console.log('Encountered error fetching calendars, but continuing normal operation');
    }
  };
  
  // Check connection status on component mount when integration is enabled in profile,
  // regardless of authentication status
  useEffect(() => {
    if (!userLoading && profile?.calendarSettings?.googleCalendarIntegrated) {
      console.log("Checking Google Calendar connection on mount - auth status:", user ? "authenticated" : "not authenticated");
      // Add a slight delay to ensure auth state is settled
      const timer = setTimeout(() => {
        checkGoogleCalendarConnection();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [profile, user, userLoading]);
  

  return (
    <div className="max-w-4xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Success message */}
        {formSuccess && (
          <div className="bg-green-50 border border-green-200 text-green-800 rounded-md p-4 flex justify-between items-center">
            <p>{formSuccess}</p>
            <button 
              type="button" 
              onClick={() => setFormSuccess("")}
              className="text-green-600 hover:text-green-800"
            >
              <FiX size={20} />
            </button>
          </div>
        )}
        
        {/* Error message from store */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4">
            <p>{error.message}</p>
          </div>
        )}
        
        {/* Appointment Duration */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Configuración de Citas</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="appointmentDuration" className="block text-sm font-medium text-gray-700 mb-1">
                Duración predeterminada de citas (minutos)
              </label>
              <select
                id="appointmentDuration"
                value={appointmentDuration.toString()}
                onChange={(e) => {
                  // Reset form errors when changing values
                  if (formErrors.appointmentDuration) {
                    setFormErrors({...formErrors, appointmentDuration: undefined});
                  }
                  
                  // Convert string to number explicitly
                  const val = Number(e.target.value);
                  if (!isNaN(val)) {
                    setAppointmentDuration(val);
                  }
                }}
                className={`w-full px-3 py-2 border ${formErrors.appointmentDuration ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
              >
                <option value="15">15 minutos</option>
                <option value="30">30 minutos</option>
                <option value="45">45 minutos</option>
                <option value="60">1 hora</option>
                <option value="90">1.5 horas</option>
                <option value="120">2 horas</option>
              </select>
              <p className="mt-1 text-xs text-gray-500">Duración estándar de una cita (por ejemplo, 30 minutos)</p>
              {formErrors.appointmentDuration && (
                <p className="mt-1 text-sm text-red-600">{formErrors.appointmentDuration}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="bufferTime" className="block text-sm font-medium text-gray-700 mb-1">
                Tiempo entre citas (minutos)
              </label>
              <select
                id="bufferTime"
                value={bufferTime.toString()}
                onChange={(e) => {
                  // Reset form errors when changing values
                  if (formErrors.bufferTime) {
                    setFormErrors({...formErrors, bufferTime: undefined});
                  }
                  
                  // Convert string to number explicitly
                  const val = Number(e.target.value);
                  if (!isNaN(val)) {
                    setBufferTime(val);
                  }
                }}
                className={`w-full px-3 py-2 border ${formErrors.bufferTime ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
              >
                <option value="0">0 minutos</option>
                <option value="5">5 minutos</option>
                <option value="10">10 minutos</option>
                <option value="15">15 minutos</option>
                <option value="30">30 minutos</option>
              </select>
              <p className="mt-1 text-xs text-gray-500">Tiempo de preparación entre citas (por ejemplo, 5 minutos)</p>
              {formErrors.bufferTime && (
                <p className="mt-1 text-sm text-red-600">{formErrors.bufferTime}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="maxAdvanceBookingDays" className="block text-sm font-medium text-gray-700 mb-1">
                Días máximos de anticipación para reservas
              </label>
              <select
                id="maxAdvanceBookingDays"
                value={maxAdvanceBookingDays.toString()}
                onChange={(e) => {
                  // Reset form errors when changing values
                  if (formErrors.maxAdvanceBookingDays) {
                    setFormErrors({...formErrors, maxAdvanceBookingDays: undefined});
                  }
                  
                  // Convert string to number explicitly
                  const val = Number(e.target.value);
                  if (!isNaN(val)) {
                    setMaxAdvanceBookingDays(val);
                  }
                }}
                className={`w-full px-3 py-2 border ${formErrors.maxAdvanceBookingDays ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500`}
              >
                <option value="1">1 día</option>
                <option value="2">2 días</option>
                <option value="3">3 días</option>
                <option value="7">1 semana</option>
                <option value="14">2 semanas</option>
                <option value="30">1 mes</option>
                <option value="90">3 meses</option>
              </select>
              <p className="mt-1 text-xs text-gray-500">Cuántos días por adelantado pueden reservar los clientes (por ejemplo, 30 días)</p>
              {formErrors.maxAdvanceBookingDays && (
                <p className="mt-1 text-sm text-red-600">{formErrors.maxAdvanceBookingDays}</p>
              )}
            </div>
          </div>
        </div>
        
        {/* Google Calendar Integration */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Integración con Google Calendar</h3>
          
          <div className="flex items-start mb-4">
            <div className="flex items-center h-5">
              <input
                id="googleCalendarIntegrated"
                type="checkbox"
                checked={googleCalendarIntegrated}
                onChange={(e) => {
                  // Clear any form errors when toggling
                  setFormErrors({});
                  
                  // Store the new state in a variable to use throughout this function
                  const newCheckedState = e.target.checked;
                  console.log(`Toggling Google Calendar integration to: ${newCheckedState ? 'ON' : 'OFF'}`);
                  
                  // Always update the toggle state regardless of auth status
                  setGoogleCalendarIntegrated(newCheckedState);
                  
                  // If toggling on, check authentication but don't block
                  if (newCheckedState) {
                    if (!user) {
                      // Show warning but don't prevent the action
                      setFormErrors({
                        appointmentDuration: "Advertencia: No has iniciado sesión. La integración funcionará mejor si inicias sesión primero."
                      });
                      console.log("User attempting to enable Google Calendar without authentication");
                    }
                    
                    // Always check connection regardless of auth status
                    // Delay slightly to ensure state update has happened
                    setTimeout(() => {
                      checkGoogleCalendarConnection();
                    }, 100);
                  }
                  
                  // When unchecking, clear the calendar ID
                  if (!newCheckedState) {
                    setGoogleCalendarId("");
                    setSelectedCalendarId("");
                    
                    // Also update in Firestore if we have a profile
                    if (profile?.id) {
                      try {
                        console.log("Disabling Google Calendar integration");
                        // When disabling, make sure we explicitly set googleCalendarId to null
                        // not undefined which causes Firestore validation errors
                        updateProfile(profile.id, {
                          calendarSettings: {
                            ...profile.calendarSettings,
                            googleCalendarIntegrated: false,
                            googleCalendarId: null // Explicitly use null
                          }
                        });
                        
                        // Show success notification
                        setFormSuccess("Integración con Google Calendar desactivada correctamente");
                        
                        // Auto-dismiss success message after 5 seconds
                        setTimeout(() => setFormSuccess(""), 5000);
                      } catch (error) {
                        console.error("Error updating calendar integration setting:", error);
                        const errorMessage = error instanceof Error ? error.message : "Error al desactivar la integración. Inténtalo de nuevo.";
                        setFormErrors({ appointmentDuration: errorMessage });
                      }
                    }
                  } else {
                    // If toggling on, verify Google Calendar auth
                    // Delay to ensure state update has occurred
                    setTimeout(() => {
                      checkGoogleCalendarConnection();
                    }, 100);
                  }
                }}
                className="focus:ring-orange-500 h-4 w-4 text-orange-600 border-gray-300 rounded"
              />
            </div>
            <div className="ml-3 text-sm">
              <label htmlFor="googleCalendarIntegrated" className="font-medium text-gray-700">Sincronizar con Google Calendar</label>
              <p className="text-gray-500">Las citas se sincronizarán automáticamente con tu Google Calendar</p>
            </div>
          </div>
          
          {googleCalendarIntegrated && (
            <div className="mt-4 border border-gray-200 rounded-md p-4 bg-gray-50">
              <p className="text-sm font-medium text-gray-700 mb-3">Conecta tu cuenta de Google Calendar</p>
              
              {googleCalendarId ? (
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Cuenta conectada</span>
                    <button
                      type="button"
                      onClick={() => {
                        setGoogleCalendarId("");
                        setGoogleCalendarIntegrated(false);
                      }}
                      className="text-sm text-red-600 hover:text-red-800"
                    >
                      Desconectar
                    </button>
                  </div>
                  <p className="mt-1 text-xs text-gray-500">{googleCalendarId}</p>
                  
                  {/* Clear warning message telling users how to set up Google Calendar */}
              <div className="mt-4 border border-yellow-200 bg-yellow-50 p-4 rounded-md">
                <p className="font-medium text-sm text-yellow-800">Importante: La integración con Google Calendar requiere configurar credenciales de Google.</p>
                <p className="mt-2 text-sm text-yellow-700">Para activar esta funcionalidad, debes agregar las siguientes claves en la configuración:</p>
                <ul className="mt-2 ml-5 list-disc text-sm text-yellow-700">
                  <li>GOOGLE_CLIENT_ID</li>
                  <li>GOOGLE_CLIENT_SECRET</li>
                </ul>
                <p className="mt-2 text-sm text-yellow-700">Estas claves se obtienen creando un proyecto en la <a href="https://console.cloud.google.com" target="_blank" className="underline hover:text-yellow-900">Consola de Google Cloud</a>.</p>
                <p className="mt-2 text-sm text-yellow-700">Asegúrate de añadir estas URLs de redirección en la configuración de OAuth de tu proyecto de Google Cloud:</p>
                <ul className="mt-2 ml-5 list-disc text-sm text-yellow-700 font-mono text-xs">
                  <li>http://localhost:3000/dashboard</li>
                  <li>https://app.databutton.com/redirect/google</li>
                  <li>https://recepcionistaai.com/api/google-calendar/auth-callback</li>
                  <li>https://recepcionistaai.com/dashboard</li>
                </ul>
              </div>
                  {calendars.length > 0 && (
                    <div className="mt-4">
                      <label htmlFor="calendarId" className="block text-sm font-medium text-gray-700 mb-1">
                        Selecciona el calendario para las citas
                      </label>
                      <select
                        id="calendarId"
                        value={selectedCalendarId}
                        onChange={(e) => setSelectedCalendarId(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500 text-sm"
                      >
                        {calendars.map((calendar) => (
                          <option key={calendar.id} value={calendar.id}>
                            {calendar.summary}
                          </option>
                        ))}
                      </select>
                      <div className="mt-2 flex items-center">
                        <button
                          type="button"
                          onClick={() => {
                            // Save the selected calendar ID when the user clicks "Guardar"
                            if (profile?.id) {
                              try {
                                // Important: Only set googleCalendarId if we have a value and integration is enabled
                                if (googleCalendarIntegrated && selectedCalendarId) {
                                  updateProfile(profile.id, {
                                    calendarSettings: {
                                      ...profile.calendarSettings,
                                      googleCalendarIntegrated: true,
                                      googleCalendarId: selectedCalendarId
                                    }
                                  });
                                  setFormSuccess("¡Calendario seleccionado correctamente! Las citas se sincronizarán con Google Calendar.");
                                  
                                  // Auto-dismiss success message after 5 seconds
                                  setTimeout(() => setFormSuccess(""), 5000);
                                } else {
                                  setFormErrors({ 
                                    appointmentDuration: "Error: Debe seleccionar un calendario válido."
                                  });
                                }
                              } catch (error) {
                                console.error("Error saving calendar selection:", error);
                                const errorMessage = error instanceof Error ? error.message : "Error al guardar la selección de calendario. Inténtalo de nuevo.";
                                setFormErrors({ appointmentDuration: errorMessage });
                              }
                            }
                          }}
                          className="px-3 py-1 bg-orange-600 text-white text-sm rounded-md hover:bg-orange-700"
                        >
                          Guardar
                        </button>
                        <button
                          type="button"
                          onClick={fetchGoogleCalendars}
                          className="ml-2 px-3 py-1 border border-gray-300 text-gray-700 text-sm rounded-md hover:bg-gray-50"
                        >
                          Actualizar
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div>
                  <button
                    type="button"
                    onClick={handleConnectGoogleCalendar}
                    className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
                  >
                    Conectar con Google Calendar
                  </button>
                  
                  <p className="mt-3 text-xs text-gray-500">
                    Al conectar tu cuenta de Google Calendar, todas las citas se crearán automáticamente en tu calendario.
                  </p>
                  
                  {/* Display a notice about configuration */}
                  <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-md">
                    <p className="text-sm text-amber-800">
                      <strong>Importante:</strong> La integración con Google Calendar requiere configurar credenciales de Google.
                    </p>
                    <p className="mt-1 text-xs text-amber-800">
                      Para activar esta funcionalidad, debes agregar las siguientes claves en la configuración:
                    </p>
                    <ul className="mt-1 text-xs text-amber-800 list-disc pl-5">
                      <li>GOOGLE_CLIENT_ID</li>
                      <li>GOOGLE_CLIENT_SECRET</li>
                    </ul>
                    <p className="mt-1 text-xs text-amber-800">
                      Estas claves se obtienen creando un proyecto en la <a href="https://console.cloud.google.com/" target="_blank" rel="noopener noreferrer" className="underline">Consola de Google Cloud</a>.
                    </p>
                    <p className="mt-1 text-xs text-amber-800">
                      Asegúrate de añadir estas URLs de redirección en la configuración de OAuth de tu proyecto de Google Cloud:
                    </p>
                    <ul className="mt-1 text-xs text-amber-800 list-disc pl-5">
                      <li>http://localhost:3000/dashboard</li>
                      <li>https://app.databutton.com/redirect/google</li>
                      <li>https://recepcionistaai.com/api/google-calendar/auth-callback</li>
                      <li>https://recepcionistaai.com/dashboard</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        
        {/* Submit Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isLoading}
            className="px-6 py-3 bg-orange-600 text-white font-medium rounded-md shadow hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 flex items-center disabled:bg-gray-400"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Guardando...
              </>
            ) : (
              <>
                <FiSave className="mr-2" size={18} />
                Guardar configuración
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}

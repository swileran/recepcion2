import { SimulationStats, useSimulationStats, getSimulationHistory, clearSimulationHistory } from "../utils/simulationHistory";
import { useState, useEffect } from "react";

interface SimulationHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SimulationHistoryModal({ isOpen, onClose }: SimulationHistoryModalProps) {
  const { stats, refreshStats } = useSimulationStats();
  const [history, setHistory] = useState(getSimulationHistory());
  
  useEffect(() => {
    if (isOpen) {
      setHistory(getSimulationHistory());
    }
  }, [isOpen]);
  
  const handleClearHistory = () => {
    if (window.confirm('¿Estás seguro de que quieres borrar todo el historial de simulaciones? Esta acción no se puede deshacer.')) {
      clearSimulationHistory();
      setHistory([]);
      refreshStats();
    }
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-black/50 flex justify-center items-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="flex justify-between items-center border-b p-4">
          <h2 className="text-xl font-semibold text-gray-900">Historial de Simulaciones</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <span className="sr-only">Cerrar</span>
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="p-4 overflow-y-auto flex-grow">
          {/* Statistics Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-orange-50 p-3 rounded-lg text-center">
              <div className="text-3xl font-bold text-orange-600 mb-1">{stats.totalSimulations}</div>
              <div className="text-xs text-gray-600">Total de Simulaciones</div>
            </div>
            <div className="bg-green-50 p-3 rounded-lg text-center">
              <div className="text-3xl font-bold text-green-600 mb-1">{stats.appointmentsBooked}</div>
              <div className="text-xs text-gray-600">Citas Confirmadas</div>
            </div>
            <div className="bg-blue-50 p-3 rounded-lg text-center">
              <div className="text-3xl font-bold text-blue-600 mb-1">{stats.faqsAnswered}</div>
              <div className="text-xs text-gray-600">Preguntas Respondidas</div>
            </div>
            <div className="bg-purple-50 p-3 rounded-lg text-center">
              <div className="text-3xl font-bold text-purple-600 mb-1">
                {Math.round((stats.successfulSimulations / Math.max(stats.totalSimulations, 1)) * 100)}%
              </div>
              <div className="text-xs text-gray-600">Tasa de Éxito</div>
            </div>
          </div>
          
          {history.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>No hay simulaciones registradas aún.</p>
              <p className="text-sm mt-1">Completa algunas simulaciones para ver su historial aquí.</p>
            </div>
          ) : (
            <div className="border rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Escenario</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Resultado</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Resumen</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {history.map((result) => (
                    <tr key={result.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(result.date).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {result.scenarioName}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${result.successful ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                          {result.successful ? 'Exitoso' : 'Incompleto'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500 max-w-sm truncate" title={result.conversationSummary}>
                        {result.conversationSummary}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          
          {/* Additional Analysis Charts - Show only if we have data */}
          {stats.scenarioBreakdown && stats.scenarioBreakdown.length > 0 && (
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Most Common Scenarios */}
              <div className="border rounded-lg p-4">
                <h3 className="text-sm font-medium text-gray-700 mb-3">Escenarios Más Probados</h3>
                <div className="space-y-2">
                  {stats.scenarioBreakdown.map((scenario, index) => (
                    <div key={index} className="flex items-center">
                      <div 
                        className="w-1 h-6 mr-2 rounded" 
                        style={{ backgroundColor: `hsl(${index * 60}, 70%, 60%)` }}
                      ></div>
                      <div className="flex-grow text-sm">{scenario.name}</div>
                      <div className="text-sm font-medium text-gray-700">{scenario.count}</div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Most Requested Services - Only show if we have service data */}
              {stats.servicesRequested && stats.servicesRequested.length > 0 && (
                <div className="border rounded-lg p-4">
                  <h3 className="text-sm font-medium text-gray-700 mb-3">Servicios Más Solicitados</h3>
                  <div className="space-y-2">
                    {stats.servicesRequested.map((service, index) => (
                      <div key={index} className="flex items-center">
                        <div 
                          className="w-1 h-6 mr-2 rounded" 
                          style={{ backgroundColor: `hsl(${index * 40 + 120}, 70%, 60%)` }}
                        ></div>
                        <div className="flex-grow text-sm capitalize">{service.service}</div>
                        <div className="text-sm font-medium text-gray-700">{service.count}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        
        <div className="border-t p-4 flex justify-between items-center bg-gray-50">
          <button
            onClick={handleClearHistory}
            className="px-4 py-2 border border-red-300 text-red-700 rounded-md hover:bg-red-50"
            disabled={history.length === 0}
          >
            Borrar historial
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
}
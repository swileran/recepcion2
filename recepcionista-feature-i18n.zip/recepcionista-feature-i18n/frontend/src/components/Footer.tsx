import React from 'react';
import { useTranslation } from 'react-i18next';

export function Footer() {
  const { t } = useTranslation();
  
  return (
    <footer className="bg-gray-900 text-white py-12 mt-auto">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <h2 className="text-2xl font-bold text-orange-500">{t('brand.name')}</h2>
            <p className="mt-2 text-gray-400">{t('brand.tagline')}</p>
          </div>
          
          <div className="flex space-x-8">
            <a href="/privacy" className="text-gray-400 hover:text-white transition-colors">
              {t('footer.links.privacy')}
            </a>
            <a href="/terms" className="text-gray-400 hover:text-white transition-colors">
              {t('footer.links.terms')}
            </a>
            <a href="/contact" className="text-gray-400 hover:text-white transition-colors">
              {t('footer.links.contact')}
            </a>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500">
          {t('footer.copyright')}
        </div>
      </div>
    </footer>
  );
} 
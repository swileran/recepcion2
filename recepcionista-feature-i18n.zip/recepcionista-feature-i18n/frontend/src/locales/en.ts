export const en = {
  nav: {
    benefits: "Benefits",
    howItWorks: "How It Works",
    pricing: "Pricing",
    myAccount: "My Account",
    login: "Login",
    loading: "Loading...",
    startNow: "Start Now"
  },
  brand: {
    name: "receptionist ai",
    tagline: "Your virtual reception assistant"
  },
  home: {
    hero: {
      title: "Automate Your Reception with AI",
      subtitle: "Welcome your customers 24/7 with an intelligent virtual assistant",
      cta: "Start Now"
    },
    benefits: {
      title: "Benefits",
      subtitle: "Why choose receptionist ai?",
      items: [
        {
          title: "Available 24/7",
          description: "Serve your customers anytime, without breaks or vacations"
        },
        {
          title: "Cost Savings",
          description: "Reduce staffing costs while maintaining quality service"
        },
        {
          title: "Easy Integration",
          description: "Integrates with your current system in minutes, hassle-free"
        }
      ]
    },
    howItWorks: {
      title: "How It Works",
      steps: [
        {
          title: "Sign Up",
          description: "Create your account in minutes and set your preferences"
        },
        {
          title: "Customize",
          description: "Adapt your virtual receptionist to your brand and needs"
        },
        {
          title: "Ready!",
          description: "Your virtual receptionist is ready to serve your customers"
        }
      ]
    },
    pricing: {
      title: "Pricing",
      subtitle: "Plans that adapt to your business",
      monthly: "Monthly",
      yearly: "Yearly",
      saveText: "Save 20%",
      plans: [
        {
          name: "Basic",
          price: "$29",
          period: "/month",
          description: "Ideal for small businesses",
          features: [
            "Up to 100 conversations/month",
            "Basic customization",
            "Email support"
          ],
          cta: "Get Started"
        },
        {
          name: "Professional",
          price: "$79",
          period: "/month",
          description: "For growing businesses",
          features: [
            "Up to 500 conversations/month",
            "Advanced customization",
            "Priority support",
            "Conversation analytics"
          ],
          cta: "Get Started",
          popular: "Most Popular"
        },
        {
          name: "Enterprise",
          price: "$199",
          period: "/month",
          description: "For large companies",
          features: [
            "Unlimited conversations",
            "Complete customization",
            "24/7 support",
            "Advanced analytics",
            "Custom API"
          ],
          cta: "Contact Us"
        }
      ]
    },
    cta: {
      title: "Ready to Transform Your Customer Service?",
      subtitle: "Join businesses that are saving time and improving customer satisfaction with our AI receptionist",
      button: "Get Started"
    }
  },
  footer: {
    links: {
      privacy: "Privacy Policy",
      terms: "Terms of Service",
      contact: "Contact"
    },
    companyDescription: "Revolutionizing customer service for Hispanic businesses with AI voice technology.",
    quickLinks: {
      title: "Quick Links",
      home: "Home",
      benefits: "Benefits",
      howItWorks: "How It Works",
      pricing: "Pricing"
    },
    legal: {
      title: "Legal",
      terms: "Terms of Service",
      privacy: "Privacy Policy",
      cookies: "Cookies"
    },
    contact: {
      title: "Contact",
      phone: "+34 612 345 678",
      email: "info@receptionistai.com",
      address: "Barcelona\nSpain"
    },
    copyright: "© {{year}} receptionist ai. All rights reserved."
  },
  auth: {
    login: {
      title: "Welcome Back",
      email: "Email",
      emailPlaceholder: "your@email.com",
      password: "Password",
      passwordPlaceholder: "Your password",
      confirmPassword: "Confirm Password",
      confirmPasswordPlaceholder: "Repeat your password",
      forgotPassword: "Forgot your password?",
      submit: "Sign In",
      submitting: "Signing in...",
      noAccount: "Don't have an account?",
      signUp: "Sign up",
      backToHome: "Back to home",
      errors: {
        required: "Please complete all fields",
        invalidEmail: "Invalid email address",
        passwordMismatch: "Passwords don't match",
        passwordLength: "Password must be at least 6 characters",
        userNotFound: "No account exists with this email. Would you like to register?",
        wrongPassword: "Incorrect email or password. Please try again.",
        tooManyRequests: "Too many failed attempts. Please try again later.",
        networkError: "Connection error. Please check your internet connection.",
        accountExists: "An account already exists with this email but with a different sign-in method. Try signing in with the original method.",
        default: "Error signing in. Please try again."
      }
    },
    signup: {
      title: "Create Your Account",
      name: "Name",
      namePlaceholder: "Your name",
      email: "Email",
      emailPlaceholder: "your@email.com",
      password: "Password",
      passwordPlaceholder: "Password (minimum 6 characters)",
      confirmPassword: "Confirm Password",
      confirmPasswordPlaceholder: "Repeat your password",
      submit: "Create Account",
      submitting: "Creating account...",
      hasAccount: "Already have an account?",
      login: "Sign in",
      errors: {
        required: "Please complete all fields",
        invalidEmail: "Invalid email address",
        passwordMismatch: "Passwords don't match",
        passwordLength: "Password must be at least 6 characters",
        emailExists: "This email is already registered. Please sign in.",
        default: "Error creating account. Please try again."
      }
    },
    social: {
      continueWithGoogle: "Continue with Google",
      or: "Or"
    },
    terms: {
      agreement: "By continuing, you agree to our",
      termsOfService: "Terms of Service",
      and: "and",
      privacyPolicy: "Privacy Policy"
    }
  },
  dashboard: {
    welcome: "Welcome to your dashboard",
    stats: {
      title: "Statistics",
      conversations: "Conversations",
      avgDuration: "Average Duration",
      satisfaction: "Satisfaction"
    },
    recentActivity: "Recent Activity",
    settings: "Settings"
  },
  common: {
    loading: "Loading...",
    error: "An error has occurred",
    retry: "Retry",
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    view: "View",
    search: "Search",
    noResults: "No results found",
    back: "Back",
    notFound: {
      title: "Page Not Found",
      message: "The page you are looking for doesn't exist or has been moved.",
      backHome: "Back to Home"
    }
  },
  components: {
    benefitsSection: {
      title: "Benefits for Your Business",
      items: [
        {
          title: "24/7 Attention",
          description: "Never miss a call. Our virtual receptionist is available at all hours, every day."
        },
        {
          title: "Automatic Scheduling",
          description: "Schedule appointments effortlessly. Sync with your calendar to avoid scheduling conflicts."
        },
        {
          title: "WhatsApp Integration",
          description: "Handle inquiries and schedule appointments via WhatsApp. Unified communication by voice and message."
        },
        {
          title: "Cost Savings",
          description: "Reduce staffing costs and improve efficiency with our affordable and scalable solution."
        },
        {
          title: "Personalized Experience",
          description: "Natural voice with regional accent that provides warm and professional attention to your customers."
        }
      ]
    },
    howItWorksSection: {
      title: "How It Works",
      steps: [
        {
          title: "Sign up and set up your profile",
          description: "Create an account and enter your business information, hours of operation, and services offered."
        },
        {
          title: "Customize your virtual assistant",
          description: "Choose the voice, configure automatic responses for calls and WhatsApp messages that represent your business."
        },
        {
          title: "Integrate your communication channels",
          description: "Connect your phone number and WhatsApp Business to start receiving calls and messages."
        },
        {
          title: "Start serving customers automatically",
          description: "Your virtual assistant will answer calls, respond to messages, and automatically schedule appointments in your calendar."
        }
      ],
      footer: "Simple setup · No long-term contracts · Spanish support · Voice and WhatsApp integrated"
    },
    profileForm: {
      title: "Business Profile",
      businessName: "Business Name",
      businessDescription: "Business Description",
      businessDescriptionPlaceholder: "Brief description of your business and services",
      industry: "Industry",
      selectIndustry: "Select an industry",
      industries: {
        professional_services: "Professional Services",
        health_wellness: "Health and Wellness",
        construction: "Construction",
        hospitality: "Hospitality and Restaurants",
        retail: "Retail",
        technology: "Technology and IT",
        education: "Education and Training",
        real_estate: "Real Estate",
        legal: "Legal Services",
        other: "Other"
      },
      phone: "Phone",
      email: "Email",
      address: "Address",
      addressPlaceholder: "Street, number, etc.",
      city: "City",
      postalCode: "Postal Code",
      country: "Country",
      selectCountry: "Select a country",
      countries: {
        spain: "Spain",
        mexico: "Mexico",
        argentina: "Argentina",
        colombia: "Colombia",
        chile: "Chile",
        peru: "Peru",
        venezuela: "Venezuela",
        ecuador: "Ecuador",
        other: "Other"
      },
      saveChanges: "Save Changes",
      saving: "Saving..."
    },
    appointmentForm: {
      newAppointment: "New Appointment",
      editAppointment: "Edit Appointment",
      clientInfo: "Client Information",
      clientName: "Client name",
      clientNamePlaceholder: "Full name",
      phone: "Phone",
      phonePlaceholder: "+34 XXX XXX XXX",
      email: "Email (optional)",
      emailPlaceholder: "example@email.com",
      appointmentDetails: "Appointment Details",
      service: "Service",
      selectService: "Select a service",
      date: "Date",
      startTime: "Start time",
      endTime: "End time",
      notes: "Notes (optional)",
      notesPlaceholder: "Additional information or special requests",
      delete: "Delete",
      cancel: "Cancel",
      createAppointment: "Create Appointment",
      saveChanges: "Save Changes",
      saving: "Saving...",
      deleteConfirm: "Are you sure you want to delete this appointment? This action cannot be undone."
    }
  }
};

export default en; 
import en from './en';
import es from './es';

export const locales = {
  en,
  es
};

export type LocaleKey = keyof typeof locales;
export type Locale = typeof en | typeof es;

export { en, es }; 
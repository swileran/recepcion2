export const es = {
  nav: {
    benefits: "Beneficios",
    howItWorks: "Cómo Funciona",
    pricing: "Precios",
    myAccount: "Mi Cuenta",
    login: "Iniciar Sesión",
    loading: "Cargando...",
    startNow: "Comenzar Ahora"
  },
  brand: {
    name: "recepcionista ai",
    tagline: "Tu asistente virtual de recepción"
  },
  home: {
    hero: {
      title: "Automatiza tu recepción con IA",
      subtitle: "Recibe a tus clientes 24/7 con un asistente virtual inteligente",
      cta: "Comenzar Ahora"
    },
    benefits: {
      title: "Beneficios",
      subtitle: "¿Por qué elegir recepcionista ai?",
      items: [
        {
          title: "Disponible 24/7",
          description: "Atiende a tus clientes en cualquier momento, sin descansos ni vacaciones"
        },
        {
          title: "Ahorra Costos",
          description: "Reduce gastos de personal mientras mantienes un servicio de calidad"
        },
        {
          title: "Fácil Integración",
          description: "Se integra con tu sistema actual en minutos, sin complicaciones"
        }
      ]
    },
    howItWorks: {
      title: "Cómo Funciona",
      steps: [
        {
          title: "Regístrate",
          description: "Crea tu cuenta en minutos y configura tus preferencias"
        },
        {
          title: "Personaliza",
          description: "Adapta tu recepcionista virtual a tu marca y necesidades"
        },
        {
          title: "¡Listo!",
          description: "Tu recepcionista virtual está listo para atender a tus clientes"
        }
      ]
    },
    pricing: {
      title: "Precios",
      subtitle: "Planes que se adaptan a tu negocio",
      monthly: "Mensual",
      yearly: "Anual",
      saveText: "Ahorra 20%",
      plans: [
        {
          name: "Básico",
          price: "29€",
          period: "/mes",
          description: "Ideal para pequeños negocios",
          features: [
            "Hasta 100 conversaciones/mes",
            "Personalización básica",
            "Soporte por email"
          ],
          cta: "Comenzar"
        },
        {
          name: "Profesional",
          price: "79€",
          period: "/mes",
          description: "Para negocios en crecimiento",
          features: [
            "Hasta 500 conversaciones/mes",
            "Personalización avanzada",
            "Soporte prioritario",
            "Análisis de conversaciones"
          ],
          cta: "Comenzar",
          popular: "Más Popular"
        },
        {
          name: "Empresarial",
          price: "199€",
          period: "/mes",
          description: "Para grandes empresas",
          features: [
            "Conversaciones ilimitadas",
            "Personalización completa",
            "Soporte 24/7",
            "Análisis avanzados",
            "API personalizada"
          ],
          cta: "Contactar"
        }
      ]
    },
    cta: {
      title: "¿Listo para transformar tu servicio al cliente?",
      subtitle: "Únete a los negocios que están ahorrando tiempo y mejorando la satisfacción del cliente con nuestro recepcionista IA",
      button: "Comenzar"
    }
  },
  footer: {
    links: {
      privacy: "Política de Privacidad",
      terms: "Términos de Servicio",
      contact: "Contacto"
    },
    companyDescription: "Revolucionando la atención al cliente para negocios hispanos con tecnología de voz AI.",
    quickLinks: {
      title: "Enlaces Rápidos",
      home: "Inicio",
      benefits: "Beneficios",
      howItWorks: "Cómo Funciona",
      pricing: "Precios"
    },
    legal: {
      title: "Legal",
      terms: "Términos de Servicio",
      privacy: "Política de Privacidad",
      cookies: "Cookies"
    },
    contact: {
      title: "Contacto",
      phone: "+34 612 345 678",
      email: "info@recepcionistaai.com",
      address: "Barcelona\nEspaña"
    },
    copyright: "© {{year}} recepcionista ai. Todos los derechos reservados."
  },
  auth: {
    login: {
      title: "Bienvenido de Nuevo",
      email: "Correo Electrónico",
      emailPlaceholder: "tu@email.com",
      password: "Contraseña",
      passwordPlaceholder: "Tu contraseña",
      confirmPassword: "Confirmar Contraseña",
      confirmPasswordPlaceholder: "Repite tu contraseña",
      forgotPassword: "¿Olvidaste tu contraseña?",
      submit: "Iniciar sesión",
      submitting: "Iniciando sesión...",
      noAccount: "¿No tienes una cuenta?",
      signUp: "Regístrate",
      backToHome: "Volver al inicio",
      errors: {
        required: "Por favor, completa todos los campos",
        invalidEmail: "Dirección de correo electrónico no válida",
        passwordMismatch: "Las contraseñas no coinciden",
        passwordLength: "La contraseña debe tener al menos 6 caracteres",
        userNotFound: "No existe una cuenta con este correo. ¿Deseas registrarte?",
        wrongPassword: "Correo electrónico o contraseña incorrectos. Por favor, inténtalo de nuevo.",
        tooManyRequests: "Demasiados intentos fallidos. Por favor, inténtalo más tarde.",
        networkError: "Error de conexión. Por favor, verifica tu conexión a internet.",
        accountExists: "Ya existe una cuenta con este correo pero con otro método de inicio de sesión. Intenta iniciar sesión con su método original.",
        default: "Error al iniciar sesión. Por favor, inténtalo de nuevo."
      }
    },
    signup: {
      title: "Crea tu Cuenta",
      name: "Nombre",
      namePlaceholder: "Tu nombre",
      email: "Correo Electrónico",
      emailPlaceholder: "tu@email.com",
      password: "Contraseña",
      passwordPlaceholder: "Contraseña (mínimo 6 caracteres)",
      confirmPassword: "Confirmar Contraseña",
      confirmPasswordPlaceholder: "Repite tu contraseña",
      submit: "Crear cuenta",
      submitting: "Creando cuenta...",
      hasAccount: "¿Ya tienes una cuenta?",
      login: "Inicia sesión",
      errors: {
        required: "Por favor, completa todos los campos",
        invalidEmail: "Dirección de correo electrónico no válida",
        passwordMismatch: "Las contraseñas no coinciden",
        passwordLength: "La contraseña debe tener al menos 6 caracteres",
        emailExists: "Este correo electrónico ya está registrado. Por favor, inicia sesión.",
        default: "Error al crear la cuenta. Por favor, inténtalo de nuevo."
      }
    },
    social: {
      continueWithGoogle: "Continuar con Google",
      or: "O"
    },
    terms: {
      agreement: "Al continuar, aceptas nuestros",
      termsOfService: "Términos de servicio",
      and: "y",
      privacyPolicy: "Política de privacidad"
    }
  },
  dashboard: {
    welcome: "Bienvenido a tu panel",
    stats: {
      title: "Estadísticas",
      conversations: "Conversaciones",
      avgDuration: "Duración promedio",
      satisfaction: "Satisfacción"
    },
    recentActivity: "Actividad Reciente",
    settings: "Configuración"
  },
  common: {
    loading: "Cargando...",
    error: "Ha ocurrido un error",
    retry: "Reintentar",
    save: "Guardar",
    cancel: "Cancelar",
    delete: "Eliminar",
    edit: "Editar",
    view: "Ver",
    search: "Buscar",
    noResults: "No se encontraron resultados",
    back: "Volver",
    notFound: {
      title: "Página No Encontrada",
      message: "La página que estás buscando no existe o ha sido movida.",
      backHome: "Volver al Inicio"
    }
  },
  components: {
    benefitsSection: {
      title: "Beneficios para tu Negocio",
      items: [
        {
          title: "Atención 24/7",
          description: "Nunca pierdas una llamada. Nuestra recepcionista virtual está disponible a todas horas, todos los días."
        },
        {
          title: "Agendamiento Automático",
          description: "Programa citas sin esfuerzo. Sincroniza con tu calendario para evitar conflictos de horarios."
        },
        {
          title: "Integración con WhatsApp",
          description: "Atiende consultas y agenda citas también por WhatsApp. Comunicação unificada por voz y mensaje."
        },
        {
          title: "Ahorro de Costos",
          description: "Reduce gastos de personal y mejora la eficiencia con nuestra solución asequible y escalable."
        },
        {
          title: "Experiencia Personalizada",
          description: "Voz natural con acento regional que brinda una atención cálida y profesional a tus clientes."
        }
      ]
    },
    howItWorksSection: {
      title: "¿Cómo Funciona?",
      steps: [
        {
          title: "Regístrate y configura tu perfil",
          description: "Crea una cuenta e ingresa la información de tu negocio, horarios de atención y servicios que ofreces."
        },
        {
          title: "Personaliza tu asistente virtual",
          description: "Elige la voz, configura respuestas automáticas para llamadas y mensajes de WhatsApp que representen a tu negocio."
        },
        {
          title: "Integra tus canales de comunicación",
          description: "Conecta tu número de teléfono y WhatsApp Business para comenzar a recibir llamadas y mensajes."
        },
        {
          title: "Comienza a atender clientes automáticamente",
          description: "Tu asistente virtual atenderá llamadas, responderá mensajes y agendará citas automáticamente en tu calendario."
        }
      ],
      footer: "Configuración simple · Sin contratos a largo plazo · Soporte en español · Voz y WhatsApp integrados"
    },
    profileForm: {
      title: "Perfil de Negocio",
      businessName: "Nombre del Negocio",
      businessDescription: "Descripción del Negocio",
      businessDescriptionPlaceholder: "Breve descripción de su negocio y servicios",
      industry: "Industria",
      selectIndustry: "Seleccione una industria",
      industries: {
        professional_services: "Servicios Profesionales",
        health_wellness: "Salud y Bienestar",
        construction: "Construcción",
        hospitality: "Hostelería y Restauración",
        retail: "Comercio Minorista",
        technology: "Tecnología e Informática",
        education: "Educación y Formación",
        real_estate: "Inmobiliaria",
        legal: "Servicios Legales",
        other: "Otro"
      },
      phone: "Teléfono",
      email: "Email",
      address: "Dirección",
      addressPlaceholder: "Calle, número, etc.",
      city: "Ciudad",
      postalCode: "Código Postal",
      country: "País",
      selectCountry: "Seleccione un país",
      countries: {
        spain: "España",
        mexico: "México",
        argentina: "Argentina",
        colombia: "Colombia",
        chile: "Chile",
        peru: "Perú",
        venezuela: "Venezuela",
        ecuador: "Ecuador",
        other: "Otro"
      },
      saveChanges: "Guardar Cambios",
      saving: "Guardando..."
    },
    appointmentForm: {
      newAppointment: "Nueva Cita",
      editAppointment: "Editar Cita",
      clientInfo: "Información del Cliente",
      clientName: "Nombre del cliente",
      clientNamePlaceholder: "Nombre completo",
      phone: "Teléfono",
      phonePlaceholder: "+34 XXX XXX XXX",
      email: "Correo electrónico (opcional)",
      emailPlaceholder: "ejemplo@email.com",
      appointmentDetails: "Detalles de la Cita",
      service: "Servicio",
      selectService: "Selecciona un servicio",
      date: "Fecha",
      startTime: "Hora de inicio",
      endTime: "Hora de fin",
      notes: "Notas (opcional)",
      notesPlaceholder: "Información adicional o peticiones especiales",
      delete: "Eliminar",
      cancel: "Cancelar",
      createAppointment: "Crear Cita",
      saveChanges: "Guardar Cambios",
      saving: "Guardando...",
      deleteConfirm: "¿Estás seguro de que deseas eliminar esta cita? Esta acción no se puede deshacer."
    }
  }
};

export default es; 
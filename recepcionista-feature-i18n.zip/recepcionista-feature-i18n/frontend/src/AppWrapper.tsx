import React, { Suspense } from 'react';
import { RouterProvider } from "react-router-dom";
import { DEFAULT_THEME } from "./constants/default-theme";
import { Head } from "./internal-components/Head";
import { ThemeProvider } from "./internal-components/ThemeProvider";
import { OuterErrorBoundary } from "./prod-components/OuterErrorBoundary";
import { router } from "./router";
import { LoadingSpinner } from './components/LoadingSpinner';

export const AppWrapper = () => {
  return (
    <OuterErrorBoundary>
      <ThemeProvider defaultTheme={DEFAULT_THEME}>
        <Suspense fallback={<LoadingSpinner size="large" />}>
          <RouterProvider router={router} />
          <Head />
        </Suspense>
      </ThemeProvider>
    </OuterErrorBoundary>
  );
};

export default AppWrapper;

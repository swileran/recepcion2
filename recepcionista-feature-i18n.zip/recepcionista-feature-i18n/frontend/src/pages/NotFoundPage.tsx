import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export function NotFoundPage() {
  const { t } = useTranslation();
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="max-w-md w-full text-center">
        <h1 className="text-9xl font-bold text-orange-500">404</h1>
        <h2 className="text-3xl font-semibold text-gray-900 mt-4">
          {t('common.notFound.title')}
        </h2>
        <p className="text-gray-600 mt-2">
          {t('common.notFound.message')}
        </p>
        <Link
          to="/"
          className="inline-block mt-8 px-6 py-3 bg-orange-500 text-white font-medium rounded-md hover:bg-orange-600 transition-colors"
        >
          {t('common.notFound.backHome')}
        </Link>
      </div>
    </div>
  );
}

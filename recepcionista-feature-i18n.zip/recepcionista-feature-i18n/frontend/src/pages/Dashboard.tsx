import { useEffect, useState } from "react";
import { useCurrentUser } from "app";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { useProfileStore } from "utils/profileStore";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import ProfileForm from "components/ProfileForm";
import { SubscriptionPlans } from "components/SubscriptionPlans";
import { SubscriptionDetails } from "components/SubscriptionDetails";
import { VoiceAgentConfigForm } from "components/VoiceAgentConfigForm";
import { WhatsAppInterface } from "components/WhatsAppInterface";
import { useWhatsAppStore } from "utils/whatsappStore";
import { WhatsAppConfigForm } from "components/WhatsAppConfigForm";
import { WhatsAppSetupGuide } from "components/WhatsAppSetupGuide";
import { CallAnalyticsDashboard } from "components/CallAnalyticsDashboard";
export default function Dashboard() {
  const { user, loading } = useCurrentUser();
  const navigate = useNavigate();
  const location = useLocation();
  const { profile, fetchProfile } = useProfileStore();
  const [selectedTab, setSelectedTab] = useState(0);
  
  // Check for subscription status in URL params
  const searchParams = new URLSearchParams(location.search);
  const subscriptionTab = searchParams.get("tab") === "suscripcion";
  const subscriptionStatus = searchParams.get("status");
  
  useEffect(() => {
    // If tab param is suscripcion, switch to subscription tab
    if (subscriptionTab) {
      setSelectedTab(1);
    }
    
    // Show toast notifications for subscription status
    if (subscriptionStatus === "success") {
      toast.success("¡Suscripción completada con éxito!");
      // Remove status from URL to prevent showing the toast on refresh
      const newParams = new URLSearchParams(location.search);
      newParams.delete("status");
      navigate({
        pathname: location.pathname,
        search: newParams.toString()
      }, { replace: true });
    } else if (subscriptionStatus === "canceled") {
      toast.info("Proceso de suscripción cancelado");
      // Remove status from URL to prevent showing the toast on refresh
      const newParams = new URLSearchParams(location.search);
      newParams.delete("status");
      navigate({
        pathname: location.pathname,
        search: newParams.toString()
      }, { replace: true });
    }
  }, [location.search]);
  
  useEffect(() => {
    if (user && !loading) {
      fetchProfile(user.uid);
    }
  }, [user, loading]);
  
  // Redirect to login if not authenticated
  if (!loading && !user) {
    navigate("/login", { replace: true });
    return null;
  }
  
  if (loading) {
    return (
      <div className="container py-8 max-w-4xl mx-auto">
        <div className="animate-pulse flex space-x-4">
          <div className="flex-1 space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="h-60 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container py-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Panel de Control</h1>
      
      <Tabs 
        value={String(selectedTab)}
        onValueChange={(value) => setSelectedTab(Number(value))}
        className="bg-white rounded-lg shadow-md"
      >
        <TabsList className="flex w-full border-b rounded-none bg-transparent p-0 space-x-4">
          <TabsTrigger 
            value="0" 
            className="px-6 py-3 font-medium text-gray-600 cursor-pointer border-b-2 border-transparent hover:text-orange-500 hover:border-orange-200 focus:outline-none transition-colors data-[state=active]:text-orange-500 data-[state=active]:border-orange-500 data-[state=active]:border-b-2 data-[state=active]:bg-transparent data-[state=active]:shadow-none rounded-none"
          >
            Perfil
          </TabsTrigger>
          <TabsTrigger 
            value="1"
            className="px-6 py-3 font-medium text-gray-600 cursor-pointer border-b-2 border-transparent hover:text-orange-500 hover:border-orange-200 focus:outline-none transition-colors data-[state=active]:text-orange-500 data-[state=active]:border-orange-500 data-[state=active]:border-b-2 data-[state=active]:bg-transparent data-[state=active]:shadow-none rounded-none"
          >
            Suscripción
          </TabsTrigger>
          <TabsTrigger 
            value="2"
            className="px-6 py-3 font-medium text-gray-600 cursor-pointer border-b-2 border-transparent hover:text-orange-500 hover:border-orange-200 focus:outline-none transition-colors data-[state=active]:text-orange-500 data-[state=active]:border-orange-500 data-[state=active]:border-b-2 data-[state=active]:bg-transparent data-[state=active]:shadow-none rounded-none"
          >
            Recepcionista
          </TabsTrigger>
          <TabsTrigger 
            value="3"
            className="px-6 py-3 font-medium text-gray-600 cursor-pointer border-b-2 border-transparent hover:text-orange-500 hover:border-orange-200 focus:outline-none transition-colors data-[state=active]:text-orange-500 data-[state=active]:border-orange-500 data-[state=active]:border-b-2 data-[state=active]:bg-transparent data-[state=active]:shadow-none rounded-none"
          >
            WhatsApp
          </TabsTrigger>
          <TabsTrigger 
            value="4"
            className="px-6 py-3 font-medium text-gray-600 cursor-pointer border-b-2 border-transparent hover:text-orange-500 hover:border-orange-200 focus:outline-none transition-colors data-[state=active]:text-orange-500 data-[state=active]:border-orange-500 data-[state=active]:border-b-2 data-[state=active]:bg-transparent data-[state=active]:shadow-none rounded-none"
          >
            Analítica
          </TabsTrigger>
          <TabsTrigger 
            value="5"
            className="px-6 py-3 font-medium text-gray-600 cursor-pointer border-b-2 border-transparent hover:text-orange-500 hover:border-orange-200 focus:outline-none transition-colors data-[state=active]:text-orange-500 data-[state=active]:border-orange-500 data-[state=active]:border-b-2 data-[state=active]:bg-transparent data-[state=active]:shadow-none rounded-none"
          >
            Configuración
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="0" className="p-4">
          <h2 className="text-xl font-semibold mb-4">Información de Perfil</h2>
          <p className="text-gray-600 mb-6">Actualice la información de su negocio y sus preferencias.</p>
          
          <ProfileForm />
        </TabsContent>
        
        <TabsContent value="1" className="p-4">
          <h2 className="text-xl font-semibold mb-4">Gestión de Suscripción</h2>
          <p className="text-gray-600 mb-6">Vea detalles de su suscripción actual y gestione sus pagos.</p>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-medium mb-4">Su Suscripción</h3>
              <SubscriptionDetails />
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-4">Cambiar Plan</h3>
              <Card>
                <CardHeader>
                  <CardTitle>Planes disponibles</CardTitle>
                  <CardDescription>Compare y actualice su plan en cualquier momento</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    onClick={() => navigate('/suscripcion')}
                    className="w-full bg-orange-500 hover:bg-orange-600"
                  >
                    Ver todos los planes
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="2" className="p-4">
          <h2 className="text-xl font-semibold mb-4">Configuración de Recepcionista</h2>
          <p className="text-gray-600 mb-6">Configure la voz y comportamiento de su recepcionista virtual.</p>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <VoiceAgentConfigForm />
          </div>
        </TabsContent>
        
        <TabsContent value="3" className="p-4">
          <h2 className="text-xl font-semibold mb-4">Mensajería WhatsApp</h2>
          <p className="text-gray-600 mb-6">Gestione sus conversaciones de WhatsApp y configure respuestas automáticas.</p>
          
          <div className="bg-white rounded-lg shadow-md p-2 h-[600px]">
            <WhatsAppInterface />
          </div>
        </TabsContent>
        
        <TabsContent value="4" className="p-4">
          <h2 className="text-xl font-semibold mb-4">Analítica de Llamadas</h2>
          <p className="text-gray-600 mb-6">Visualice métricas y estadísticas de las llamadas atendidas por su recepcionista virtual.</p>
          
          <CallAnalyticsDashboard />
        </TabsContent>
        
        <TabsContent value="5" className="p-4">
          <h2 className="text-xl font-semibold mb-4">Configuración</h2>
          <p className="text-gray-600 mb-6">Ajuste la configuración de su cuenta y preferencias.</p>
          
          <Card>
            <CardHeader>
              <CardTitle>Configuración de WhatsApp</CardTitle>
              <CardDescription>Configure su cuenta de WhatsApp Business API</CardDescription>
            </CardHeader>
            <CardContent>
              <WhatsAppConfigForm />
            </CardContent>
          </Card>
          
          <div className="mt-6">
            <WhatsAppSetupGuide />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
import React, { useState, useEffect } from "react";
import { useCurrentUser } from "app";
import { getFirestore, doc, getDoc } from "firebase/firestore";
import { firebaseApp } from "app";
import { WhatsAppConfig } from "components/WhatsAppConfig"; 
import { MetaWhatsAppConfig } from "components/MetaWhatsAppConfig";
import { WhatsAppIntegrationSelector } from "components/WhatsAppIntegrationSelector";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const WhatsAppPage = () => {
  const { user } = useCurrentUser();
  const [selectedIntegration, setSelectedIntegration] = useState<"twilio" | "meta" | null>(null);
  const [showSelector, setShowSelector] = useState(true);
  const db = getFirestore(firebaseApp);

  useEffect(() => {
    const loadIntegrationPreference = async () => {
      if (!user) return;

      try {
        const configDoc = await getDoc(doc(db, `users/${user.uid}/config/whatsapp_integration`));
        if (configDoc.exists()) {
          const data = configDoc.data();
          if (data.provider && (data.provider === "twilio" || data.provider === "meta")) {
            setSelectedIntegration(data.provider);
            setShowSelector(false);
          }
        }
      } catch (error) {
        console.error("Error loading WhatsApp integration preference:", error);
      }
    };

    loadIntegrationPreference();
  }, [user, db]);

  const handleSelectIntegration = (integration: "twilio" | "meta") => {
    setSelectedIntegration(integration);
    setShowSelector(false);
  };

  const handleBack = () => {
    setShowSelector(true);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">Configuración de WhatsApp</h1>
      
      {showSelector ? (
        <WhatsAppIntegrationSelector 
          currentIntegration={selectedIntegration}
          onSelectIntegration={handleSelectIntegration}
        />
      ) : (
        <div className="space-y-6">
          <div className="flex items-center mb-6">
            <Button 
              variant="ghost" 
              className="flex items-center text-sm" 
              onClick={handleBack}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver a selección de integración
            </Button>
          </div>
          
          {selectedIntegration === "twilio" && (
            <WhatsAppConfig onConfigured={() => {}} />
          )}
          
          {selectedIntegration === "meta" && (
            <MetaWhatsAppConfig onConfigured={() => {}} />
          )}
        </div>
      )}
    </div>
  );
};

export default WhatsAppPage;

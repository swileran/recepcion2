import { SubscriptionPlans } from "components/SubscriptionPlans";
import { StripeProvider } from "components/StripeProvider";

export default function Subscription() {
  return (
    <div className="container py-8 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold mb-2 text-center">Planes de Suscripción</h1>
      <p className="text-gray-600 mb-8 text-center max-w-2xl mx-auto">
        Elija el plan que mejor se adapte a las necesidades de su negocio.
        Todos los planes incluyen nuestro recepcionista virtual con IA.
      </p>
      
      <div className="elements-wrapper">
        <StripeProvider>
          <SubscriptionPlans />
        </StripeProvider>
      </div>
    </div>
  );
}
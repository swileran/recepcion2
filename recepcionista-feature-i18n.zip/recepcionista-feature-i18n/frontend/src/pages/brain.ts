// Tmp file that makes apps backwards compatible to
// the point before we moved App into pages
import brain from "../brain";

export default brain;

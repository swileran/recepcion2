import React, { useState, useEffect, Suspense } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { firebaseAuth } from 'app';
import { FiMail, FiLock, FiArrowLeft, FiAlertCircle } from 'react-icons/fi';
import { FcGoogle } from 'react-icons/fc';
import { useTranslation } from 'react-i18next';
import { LoadingSpinner } from '../components/LoadingSpinner';

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  // Get signup param from URL
  const [isSignUp, setIsSignUp] = useState(() => {
    // Check if signup query parameter is present
    const params = new URLSearchParams(location.search);
    const isSignup = params.get('signup') === 'true';
    console.log('Signup param detected:', isSignup); // Debug log
    return isSignup;
  });

  // Handle login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password) {
      setError(t('auth.login.errors.required'));
      return;
    }
    
    try {
      setLoading(true);
      console.log('Attempting login for:', email);
      
      // Sign in with email/password
      await signInWithEmailAndPassword(firebaseAuth, email, password);
      navigate('/dashboard');
    } catch (err: any) {
      console.error('Login error:', err);
      console.log('Error code:', err.code, 'Error message:', err.message || 'No message');
      
      if (err.code === 'auth/user-not-found') {
        setError(t('auth.login.errors.userNotFound'));
      } else if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setError(t('auth.login.errors.wrongPassword'));
      } else if (err.code === 'auth/too-many-requests') {
        setError(t('auth.login.errors.tooManyRequests'));
      } else if (err.code === 'auth/network-request-failed') {
        setError(t('auth.login.errors.networkError'));
      } else {
        setError(t('auth.login.errors.default'));
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle registration
  const handleRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password || !confirmPassword) {
      setError(t('auth.signup.errors.required'));
      return;
    }
    
    if (password !== confirmPassword) {
      setError(t('auth.signup.errors.passwordMismatch'));
      return;
    }
    
    if (password.length < 6) {
      setError(t('auth.signup.errors.passwordLength'));
      return;
    }
    
    try {
      setLoading(true);
      console.log('Attempting registration for:', email);
      
      // Create user with email/password
      await createUserWithEmailAndPassword(firebaseAuth, email, password);
      navigate('/dashboard');
    } catch (err: any) {
      console.error('Registration error:', err);
      
      if (err.code === 'auth/email-already-in-use') {
        setError(t('auth.signup.errors.emailExists'));
      } else if (err.code === 'auth/invalid-email') {
        setError(t('auth.signup.errors.invalidEmail'));
      } else if (err.code === 'auth/weak-password') {
        setError(t('auth.signup.errors.passwordLength'));
      } else {
        setError(t('auth.signup.errors.default'));
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle Google sign-in
  const signInWithGoogle = async () => {
    try {
      setLoading(true);
      setError('');
      
      const provider = new GoogleAuthProvider();
      await signInWithPopup(firebaseAuth, provider);
      navigate('/dashboard');
    } catch (err: any) {
      console.error('Error signing in with Google:', err);
      
      // More detailed logging for troubleshooting
      console.log('Error code:', err.code);
      console.log('Error message:', err.message);
      
      // More specific error messages based on error code
      if (err.code === 'auth/popup-closed-by-user') {
        setError(t('auth.login.errors.popupClosed'));
      } else if (err.code === 'auth/popup-blocked') {
        setError(t('auth.login.errors.popupBlocked'));
      } else if (err.code === 'auth/cancelled-popup-request') {
        setError(t('auth.login.errors.popupCancelled'));
      } else if (err.code === 'auth/network-request-failed') {
        setError(t('auth.login.errors.networkError'));
      } else if (err.code === 'auth/account-exists-with-different-credential') {
        setError(t('auth.login.errors.accountExists'));
      } else {
        setError(t('auth.login.errors.default'));
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle toggling between login and signup
  const toggleSignUp = () => {
    // Reset the form when toggling
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setError('');
    
    console.log('Toggling signup state from', isSignUp, 'to', !isSignUp);
    setIsSignUp(!isSignUp);
    
    // Update URL without page reload
    const url = new URL(window.location.href);
    if (!isSignUp) {
      url.searchParams.set('signup', 'true');
    } else {
      url.searchParams.delete('signup');
    }
    window.history.pushState({}, '', url);
  };

  // Check if user is already logged in on mount
  useEffect(() => {
    console.log('Component mounted');
    const checkAuthState = async () => {
      const unsubscribe = firebaseAuth.onAuthStateChanged((user) => {
        console.log('Auth state changed:', user ? `User logged in: ${user.email}` : 'No user');
        if (user) {
          // If user is already logged in, redirect to dashboard
          navigate('/dashboard');
        }
      });
      return () => unsubscribe();
    };
    
    checkAuthState();
  }, [navigate]);

  return (
    <Suspense fallback={<LoadingSpinner size="large" />}>
      <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full bg-white rounded-lg shadow-md p-6 space-y-6">
          <div className="flex items-center">
            <button 
              onClick={() => navigate('/')}
              className="text-gray-500 hover:text-orange-500 transition-colors"
              aria-label={t('auth.login.backToHome')}
            >
              <FiArrowLeft size={20} />
            </button>
            <h1 className="text-2xl font-bold text-center text-gray-900 flex-grow">
              {isSignUp ? t('auth.signup.title') : t('auth.login.title')}
            </h1>
          </div>
          
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4 flex items-start">
              <FiAlertCircle className="flex-shrink-0 mr-2 mt-0.5" />
              <p>{error}</p>
            </div>
          )}
          
          <div>
            {isSignUp ? (
              <form onSubmit={handleRegistration} className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('auth.signup.email')}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiMail className="text-gray-400" />
                    </div>
                    <input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                      placeholder={t('auth.signup.emailPlaceholder')}
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('auth.signup.password')}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiLock className="text-gray-400" />
                    </div>
                    <input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                      placeholder={t('auth.signup.passwordPlaceholder')}
                      required
                      minLength={6}
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('auth.signup.confirmPassword')}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiLock className="text-gray-400" />
                    </div>
                    <input
                      id="confirmPassword"
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="pl-10 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                      placeholder={t('auth.signup.confirmPasswordPlaceholder')}
                      required
                    />
                  </div>
                </div>
                
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50"
                >
                  {loading ? t('auth.signup.submitting') : t('auth.signup.submit')}
                </button>
              </form>
            ) : (
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('auth.login.email')}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiMail className="text-gray-400" />
                    </div>
                    <input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                      placeholder={t('auth.login.emailPlaceholder')}
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('auth.login.password')}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiLock className="text-gray-400" />
                    </div>
                    <input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                      placeholder={t('auth.login.passwordPlaceholder')}
                      required
                    />
                  </div>
                </div>
                
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50"
                >
                  {loading ? t('auth.login.submitting') : t('auth.login.submit')}
                </button>
              </form>
            )}
            
            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">{t('auth.social.or')}</span>
              </div>
            </div>
            
            <button
              type="button"
              onClick={signInWithGoogle}
              disabled={loading}
              className="w-full flex justify-center items-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50"
            >
              <FcGoogle className="mr-2 text-xl" />
              {t('auth.social.continueWithGoogle')}
            </button>
          </div>  
          
          <div className="pt-2 text-center">
            <button 
              onClick={toggleSignUp} 
              className="text-orange-500 hover:text-orange-600 transition-colors text-sm font-medium"
            >
              {isSignUp 
                ? t('auth.signup.hasAccount') + " " + t('auth.signup.login')
                : t('auth.login.noAccount') + " " + t('auth.login.signUp')}
            </button>
          </div>
          
          <div className="border-t border-gray-200 pt-4">
            <p className="text-xs text-gray-500 text-center">
              {t('auth.terms.agreement')} <a href="#" className="text-orange-500 hover:underline">{t('auth.terms.termsOfService')}</a> {t('auth.terms.and')} <a href="#" className="text-orange-500 hover:underline">{t('auth.terms.privacyPolicy')}</a>.
            </p>
          </div>
        </div>
      </div>
    </Suspense>
  );
}
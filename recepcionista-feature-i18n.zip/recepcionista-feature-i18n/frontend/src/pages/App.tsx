import { APP_BASE_PATH, useCurrentUser } from "app";
import { FooterSection } from "../components/FooterSection";
import { HeroSection } from "../components/HeroSection";
import { BenefitsSection } from "../components/BenefitsSection";
import { HowItWorksSection } from "../components/HowItWorksSection";
import { CTASection } from "../components/CTASection";
import { HeaderNav } from "../components/HeaderNav";
import { useNavigate } from "react-router-dom";

export default function App() {
  const navigate = useNavigate();
  const { user } = useCurrentUser();

  return (
    <div className="flex flex-col min-h-screen">
      <HeaderNav onCtaClick={() => {}} />
      
      <main className="flex-grow">
        <section className="py-8 px-4 sm:px-6 lg:px-8 flex justify-center">
          <HeroSection 
            title="Recepcionista Virtual en Español para tu Negocio" 
            subtitle="Nunca pierdas una llamada o cliente. Nuestra IA atiende tus llamadas, agenda citas y responde preguntas en español natural las 24 horas por teléfono y WhatsApp." 
            ctaText="Prueba Gratis por 14 Días"
            onCtaClick={() => {}}
          />
        </section>
        
        <section id="beneficios" className="py-12 w-full">
          <BenefitsSection />
        </section>
        
        <section id="como-funciona" className="py-12 w-full">
          <HowItWorksSection />
        </section>
        
        <section id="precios" className="py-12 w-full">
          <CTASection 
            title="Mejora la Atención al Cliente de tu Negocio Hoy" 
            subtitle="Planes desde €29/mes con 14 días de prueba gratuita. Sin contratos a largo plazo ni equipos complicados." 
            ctaText="Empieza tu Prueba Gratuita"
            onCtaClick={() => {}}
          />
        </section>
      </main>
      
      <FooterSection />
    </div>
  );
}

import { auth } from "app";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Logout() {
  const navigate = useNavigate();

  useEffect(() => {
    const performLogout = async () => {
      await auth.signOut();
      navigate('/');
    };
    
    performLogout();
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-amber-50 p-4">
      <div className="text-center">
        <h2 className="text-xl font-medium text-gray-700 mb-2">Cerrando sesión...</h2>
        <p className="text-gray-500">Redirigiendo a la página principal</p>
      </div>
    </div>
  );
}

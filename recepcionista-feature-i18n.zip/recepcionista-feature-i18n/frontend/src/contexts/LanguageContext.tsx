import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { locales, LocaleKey, Locale } from '../locales';

interface LanguageContextType {
  currentLocale: Locale;
  currentLanguage: LocaleKey;
  setLanguage: (lang: LocaleKey) => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  // Use a key to force re-render of all child components
  const [renderKey, setRenderKey] = useState(0);
  const [currentLanguage, setCurrentLanguage] = useState<LocaleKey>(() => {
    const savedLanguage = localStorage.getItem('language') as LocaleKey;
    return savedLanguage && (savedLanguage === 'en' || savedLanguage === 'es') 
      ? savedLanguage 
      : 'es'; // Default to Spanish
  });

  useEffect(() => {
    localStorage.setItem('language', currentLanguage);
  }, [currentLanguage]);

  const setLanguage = (lang: LocaleKey) => {
    setCurrentLanguage(lang);
    // Force re-render of all components by changing the key
    setRenderKey(prev => prev + 1);
  };

  const value = {
    currentLocale: locales[currentLanguage],
    currentLanguage,
    setLanguage,
  };

  // Use the key to force re-render when language changes
  return (
    <LanguageContext.Provider value={value} key={renderKey}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}; 